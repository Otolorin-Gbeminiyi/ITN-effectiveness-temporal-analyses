# ITN Effectiveness and Temporal Dynamics of Malaria in Ixcán, Guatemala

**R code supporting Chapters 4 and 5 of a thesis based on a cluster-randomised trial of insecticide-treated nets (ITNs).**

This repository presents the overall effectiveness and temporal pattern of ITN effects in a historical trial from Ixcán, Guatemala, a low-transmission Central American setting where *Plasmodium vivax* predominated. **Both chapters are included in ONE continuous R script**, retaining the exact order in the original uploaded file.

> **Status:** Research transparency / archival source. The R script is an **exact, unchanged copy** of the uploaded original, not an independently tested or corrected reproducibility release. Several code issues identified by static review may prevent uninterrupted execution. See [code review notes](docs/CODE_REVIEW_NOTES.md). No participant-level data are included.

## Main script

[`scripts/Chapter_4_and_5_ITN_Effectiveness_and_Temporal_Analyses.R`](scripts/Chapter_4_and_5_ITN_Effectiveness_and_Temporal_Analyses.R)

The script contains two clearly numbered sections (with their original subheadings):

| Chapter | Main content |
| --- | --- |
| **Chapter 4 — Malaria incidence and ITN effectiveness** | Source dataset linkage, variable harmonisation, malaria positivity, crude and adjusted incidence rate ratios, village-clustered Poisson GEE, demographic/transmission-specific estimates, descriptive survey-round incidence. |
| **Chapter 5 — Survival and temporal dynamics** | Kaplan–Meier curves, Cox regression, piecewise Cox, Andersen–Gill recurrent-event models, global Wald tests of time-varying effects, and intervention-by-survey-round Poisson GEE. |

Chapter 5 depends on data objects created in Chapter 4, including `mergeData2` and `CRT_GEE`. Keeping both in a single script makes that analytical dependency explicit.

## Repository structure

```text
ixcan-itn-effectiveness-temporal-analyses/
├── README.md
├── .gitignore
├── CITATION.cff
├── scripts/
│   └── Chapter_4_and_5_ITN_Effectiveness_and_Temporal_Analyses.R
├── data/
│   └── README.md
└── docs/
    ├── CODE_REVIEW_NOTES.md
    └── SOURCE_INTEGRITY.md
```

## Inputs (not included)

The beginning of the script calls `read.csv(file.choose())` three times, expecting authorised local data inputs in this order:

1. `finmerg_deidentified` — laboratory malaria records (`finmerg` in code).
2. `feball_fixed2_deidentified` — field-survey records (`feball` in code).
3. `habitantes_query` — participant biodata (`habitat` in code).

**Do not upload participant-level data or derived CSV exports to this repository.** De-identification alone does not authorise public release. Check the applicable data-use and ethics conditions and obtain approval before sharing locality-to-arm allocation details embedded in the R code. See [data handling guidance](data/README.md).

## Software

The code is written in **R**. The original R and package versions were not provided. Referenced packages include `tidyverse`, `dplyr`, `fuzzyjoin`, `ggplot2`, `viridis`, `sjmisc`, `psych`, `geepack`, `stringr`, `tidyr`, `scales`, `broom`, `lubridate`, `survival`, `survminer`, and `tibble`.

```r
install.packages(c(
  "tidyverse", "dplyr", "fuzzyjoin", "ggplot2", "viridis",
  "sjmisc", "psych", "geepack", "stringr", "tidyr",
  "scales", "broom", "lubridate", "survival", "survminer", "tibble"
))
```

## How to use

1. Review [the known issues](docs/CODE_REVIEW_NOTES.md) before attempting execution.
2. Work from a **local, authorised environment** with access to your private input datasets.
3. Open the single R script in RStudio; the original code requests three data files interactively.
4. Review each chapter's analytical blocks before running them. **Do not assume the script can be sourced from beginning to end**; the supplied original contains potential parsing and runtime blockers.
5. For any corrected code, create a **separately versioned** file and validate final model outputs against the thesis and manuscripts before claiming reproducibility.

The original includes exploratory/repeated analyses with differing episode definitions, survey windows and person-time constructions. Those are preserved intentionally, not endorsed as equivalent alternatives.

## Scientific interpretation

Time-specific point estimates should not be described as a demonstrated strengthening of ITN effectiveness without a supported trend or global heterogeneity test. Clearly distinguish overall effectiveness analyses from temporal comparisons and the S6 baseline from active-surveillance rounds.

## Source integrity, citation and licence

The original source (**9,138 lines**, SHA-256 `ca2890eaf804baac8207bc7ed0540a3843db2506981f6b03df89b9fecfa8aca3`) is preserved exactly; see [the source-integrity record](docs/SOURCE_INTEGRITY.md). Citation metadata are in [`CITATION.cff`](CITATION.cff); update with final publications/DOI when available. No software licence has been assigned. Public sharing of source code and metadata remains subject to research-owner permissions.
