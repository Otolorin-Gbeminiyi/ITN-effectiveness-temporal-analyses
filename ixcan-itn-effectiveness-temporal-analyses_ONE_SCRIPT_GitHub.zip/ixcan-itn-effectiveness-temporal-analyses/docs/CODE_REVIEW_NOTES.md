# Code review notes — Chapters 4 and 5

## What was changed for this repository

The uploaded script has been copied as **one combined Chapter 4 and Chapter 5 R file** (`scripts/Chapter_4_and_5_ITN_Effectiveness_and_Temporal_Analyses.R`). All original R statements, comments, whitespace and numbering are preserved **byte for byte**, including known issues. No analytical commands, modelling formulas or variable names were corrected or rewritten.

**Execution status:** Not tested. A compatible R installation and the private datasets were unavailable for running the analysis. The following are static observations, not an exhaustive run-time error report or a statistical validation.

## Issues to address before labelling the code reproducible

File references below use line numbers in the original uploaded combined file (identical to the single repository script).

| Priority | Original lines | Finding / recommended follow-up |
| --- | --- | --- |
| High | 11 | `options(scipen = n)` uses `n` without an evident numeric definition. Check the intended value (e.g. a numeric scipen option). |
| High | 568 | `.#Distribution ...` begins with a standalone `.` expression, which is not a normal R comment and may fail on evaluation. Check whether it should simply be a comment. |
| High | 1594, 1606, 1668 | `counts_person` was previously summarised with `positives_indiv` and `tested_indiv`, but these blocks refer to columns `persons` and `cases`; review the intended denominator and numerator. |
| High | 1722 | `infection_status` is referenced while building `dat_round_12`, although it is not apparently defined in the selected `df` object at this point. |
| High | 4042–4059 | `total_incidence_summary` is used, but no preceding assignment to this object was found in the provided source. |
| High | 4371 | `dat_survey` is referenced before any apparent definition in the provided source. |
| High | 7878–7890 | The section headed **5.7** begins with orphaned argument fragments (`Lower_95CI = lower, ...`) and closing delimiters. This appears to be incomplete, misplaced code and is a likely **parse blocker**. The complete survey-round GEE workflow follows in section 5.8; do not delete or rearrange section 5.7 without review. |
| High | 5134–5135 | `Locality_code = factor(Locality_code, , levels = c("Male", "Female"))` appears to apply sex categories to locality identifiers; verify the intended clustering variable and covariate coding. |
| High | 4534–4537 | Survey-arm recoding permits `"1"` under both the control and intervention branches. Earlier sections use raw study-arm codes `1/2` and derived codes `0/1`, so check the **meaning of the source variable at each step**. |
| Review | 2490–2492 | Script exports `CRT_GEE2` (participant-level analytic data) to CSV. Confirm permitted handling; the `.gitignore` blocks CSV additions by default but does not erase committed Git history. |
| Review | 817–844 | Chapter 4 includes a hard-coded historical village-to-arm allocation list. Obtain approval to publish the mapping if it falls within restricted data-use obligations. |
| Review | Throughout | Multiple incidence workflows use fixed 14-day surveys, observed intervisit times or approximate person-months; verify the final published person-time and case definitions before reuse. |
| Review | Chapters 4–5 | Some workflows treat S6 as a baseline or initial observation while others include S6 in incidence displays; the active-intervention period is not the same for every model. Label analytic windows explicitly. |
| Review | 4807–4820; 5016–5020; 5615–5618 | Early KM baseline logic and later Cox baseline-negative eligibility logic are not identical. Verify whether the survival analyses use consistent entry rules. |

## Reproducibility work recommended later

After the research team has reviewed the above, a **separate, versioned follow-up release** could: standardise paths via a private data directory or environment variables, remove superseded exploratory attempts with documented provenance, harmonise case and follow-up definitions, add explicit input checks, record package versions, generate deterministic output paths, and validate the published result tables. Such changes should **not** be conflated with this source-preserving archival preparation.

## Data protection check

No participant-level source or output data files are packaged here. Public script content still contains variable names, example locality names and allocations. Verify the right to publish the code and contextual metadata, particularly if the original study has data-use restrictions.
