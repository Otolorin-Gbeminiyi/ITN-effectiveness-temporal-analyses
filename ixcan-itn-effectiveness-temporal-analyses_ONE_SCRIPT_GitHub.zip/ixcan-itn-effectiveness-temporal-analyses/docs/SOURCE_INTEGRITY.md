# Source integrity and preservation record

The combined source in [`scripts/Chapter_4_and_5_ITN_Effectiveness_and_Temporal_Analyses.R`](../scripts/Chapter_4_and_5_ITN_Effectiveness_and_Temporal_Analyses.R) is **byte-for-byte identical** to the user-uploaded original named `Chapters_4_and_5_ CODE.R`.

- Original line count: **9,138**
- Chapter 4: original lines **1–4,733**
- Chapter 5: original lines **4,734–9,138**
- Boundary: `# 5.1 Kaplan–Meier estimation of time to first malaria infection ----`
- No R expressions, comments, headings, statistical formulas, variable names, or whitespace have been changed.

## SHA-256

```text
ca2890eaf804baac8207bc7ed0540a3843db2506981f6b03df89b9fecfa8aca3  Chapter_4_and_5_ITN_Effectiveness_and_Temporal_Analyses.R
```

This comparison verifies preservation of the source bytes. It does **not** verify R parsing, executable correctness, scientific validity, or replication of published outcomes. The original dataset files are not included.
