# 4.1 Input datasets and variable selection ----
# 4.1.1 Load analysis packages ----
library(tidyverse)
library(dplyr)
library(fuzzyjoin)
library(ggplot2)
library(viridis)
library(sjmisc) #frq function
library(psych) #psych package for describe function
library(geepack) #to use geeglm function
options(scipen = n)


# 4.1.2 Import field, laboratory and participant datasets ----

#uploading data set
finmerg <- read.csv(file.choose())    # finmerg_deidentified (CONTAIN KEY LABORATORY DATA )
feball <- read.csv(file.choose()) # feball_fixed2_deidentified (CONTAIN KEY FIELD SURVEY DATA)
habitat <- read.csv(file.choose())  # habitantes_query (CONTAIN KEY BIODATA OF BIODATA)


# 4.1.3 Review FEBALL field-survey variables ----


#The FEBALL dataset functions as the main field survey dataset for this study, 
#encompassing a wide range of individual-level variables essential for analysing the CRCT study. 
#after going through every single variable in the feball dataset, below are the essential variables
#that will used in my analysis


#s/n      VARIABLES            	MEANING                       	VARIABLE UTILIZATION
#1.		DEPTO                	Department_code	                     Essential Variable
#2.		MUNICIPIO	          	Municipality_code	                   Essential Variable
#3.		LOCALIDAD		          Locality_code	                       Essential Variable
#4.		NFEBRIL1		          Survey_Number(6-17)	                 Essential Variable
#5.		encuesta	          	Household_ID	                       Essential Variable
#6.		FECHA		              Date_of_the_survey                   Essential Variable
#7.		ID	                	Individual_ID	                       Essential Variable
#8.		GROUP	              	Survey_Group                       	 Essential Variable
#9.		INTERVENTION	       	Control and intervention survey grroup	Essential Variable
#10.	 TRANSMITIONLVL	    	Transmission_level	                Essential Variables
#11.		numeroid		          Participant_unique_identifier	      Essential Variables
#12.		BAFNOID		            Survey_number_Participant_identifier	Essential Variable
#13.		FIEBRE2SEM	        	Fever_in_past_2wks	                Essential Variable
#14.		FIEBREPALU	        	Fever_perceived_as_malaria        	Essential Variable
#15.		VISITACV		          Visit_to_healthcenter 	            Essential Variable
#16.		AUTOMEDICO	          Self_medication_taken	              Essential Variable
#17.		QUETOMO		            Medication_taken                  	Essential Variable
#18.		DIASTRATAM	        	Days_medicn_taken	                  Essential Variable
#19.		FECHATOMA		          Date_of_sample_collection         	Essential Variable
#20.		FECHADIAGN	        	Diagnosis_date                    	Essential Variable
#21.		RESULTADO		          Malaria_result                     	Essential Variable
#22.		FIEBREDIA		          Fever_on_day_of_visit             	Essential Variable
#23.		RESULTADOD	        	Malaria_result                      Essential Variable
#24.		PABELLOND		          Own_a_mosquito_net                	Essential Variable
#25.		INSECTICI2		        Net_treated_with_insecticide      	Essential Variable
#26.		USADOD		            Do_you_use_the_net	                Essential Variable


# 4.1.4 Identify non-essential field-survey variables ----
#and will be deleted from the data keeping only the essential dataset

#1.		  ACUESTAD	     	time  you go to bed inside mosquito net	
#2.		  OBSERVAD		    Interviewer’s_observations 	
#3.		  encuesta2	      Household_ID	
#4.		  TECNICO1	    	Technician 1	
#5.	  	TECNICO2	    	Technician 2	
#6.		  CDIA1		        Chloroquine treatment/day 1	
#7.		  CDIA2	        	Chloroquine treatment/day 2	
#8.		  CDIA3	      	  Chloroquine treatment/day 3	
#9.	   	CDIA4		        Chloroquine treatment/day 4	
#10.		CDIA5	        	Chloroquine treatment/day 5	
#11.		PDIA1		        primaquine  treatment on days 1	
#12.		PDIA2	        	primaquine  treatment on days 2	
#13		  PDIA3		        primaquine  treatment on days 3	
#14.		PDIA4	        	primaquine  treatment on days 4	
#15.		PDIA5	        	primaquine  treatment on days 5	
#16.		CDIA1D		      Chloroquine treatment/day 1	
#17.		CDIA2D	      	Chloroquine treatment/day 2	
#18.		CDIA3D	      	Chloroquine treatment/day 3	
#19.		CDIA4D		      Chloroquine treatment/day 4	
#20.		CDIA5D		      Chloroquine treatment/day 5	
#21.		PDIA1D		      primaquine  treatment on days 1	
#22.		PDIA2D		      primaquine  treatment on days 2	
#23.		PDIA3D	      	primaquine  treatment on days 3			
#24     PDIA4D	      	primaquine  treatment on days 4	
#25.		PDIA5D		      primaquine  treatment on days 5	
#26.		HORADORMID		  time  you go to bed inside mosquito net	
#27.		ORAL	        	Oral_temperature	
#28.		AXIAL	        	Axial_temperature	
#29.		FRECUENCIA		  Frequency_of_symptoms	
#30.		FRIOS	        	Chills_noticed	
#31.		VISITOCVDI		  Visit_to_healthcenter	
#32.		AUTOMEDIC2		  Self_medication_taken	
#33.		FECHATOMAD		  Date_of_sample_collection 	
#34.		FECHATOM1		    Date_of_sample_collection 	
#35.		FECHADIAGD		  Diagnosis_date	
#36.		QUETOMODIA		  Medication_taken	
#37.		CUANTOSDIA		  How_many_days_medication_taken	
#38.		GG		          Thick_blood_smear_taken	
#39.		ACETAMINOF		  Given_acetaminophen_for_fever	
#40.		PF		          Blood_sample_on _filter_paper	
#41.		ISOCODE	      	Blood_sample_with_the_Isocode	
#42.		RESULTADOx	  	Malaria_result
#43.		INSECTICID		  Net_treated_with_insecticide	
#44.		PABELLON		    Own_a_mosquito_net	

# 4.1.5 Remove selected FEBALL variables ----
vars_to_remove <- c(
  "ACUESTAD", "OBSERVAD", "encuesta2", "nfebril", "TECNICO1", "TECNICO2",
  "CDIA1", "CDIA2", "CDIA3", "CDIA4", "CDIA5",
  "PDIA1", "PDIA2", "PDIA3", "PDIA4", "PDIA5",
  "CDIA1D", "CDIA2D", "CDIA3D", "CDIA4D", "CDIA5D",
  "PDIA1D", "PDIA2D", "PDIA3D", "PDIA4D", "PDIA5D",
  "HORADORMID", "ORAL", "AXIAL", "FRECUENCIA", "FRIOS",
  "VISITOCVDI", "AUTOMEDIC2", "FECHATOMAD", "FECHATOM1",
  "FECHADIAGD", "QUETOMODIA", "CUANTOSDIA", "GG",
  "ACETAMINOF", "PF", "ISOCODE", "RESULTADOx",
  "INSECTICID", "PABELLON"
)

# Remove the variables
feballClean <- feball[ , !(names(feball) %in% vars_to_remove)]



# 4.1.6 Review FINMERG laboratory variables ----

#The FINMERG dataset primarily comprises laboratory diagnostic data and shares 
#several variables with the FEBALL dataset, although it contains fewer observations overall. 
#A thorough assessment and analysis of all variables within FINMERGE have been conducted to 
#identify and extract only those variables unique to this dataset,
#particularly those offering added malaria diagnostic value. 


#s/n	Variables	translation	VARIABLE UTILIZATION

#1.		resultado			          	Malaria result with Plasmodium spp	   Essential Variables
#2.		resultadod			        	Malaria result	                       Essential Variables
#3.		VIVAXA                  	P. vivax asexual parasites detected    Essential Variables
#4.		VIVAXG	                	P. vivax gametocyte parasite detected  Essential Variables
#5.		VIVAXL		                P.vivax parasite density               Essential Variables
#6.		FALCIA		                P. falciparum asexual parasites detected Essential Variables
#7.		FALCIG                  	P.falciparum gametocyte  detected      Essential Variables
#8.		FALCIL	                	P. falciparum parasite density         Essential Variables
#9.		densvivax	              	Density of P. vivax parasites          Essential Variables
#10.		densfalci		            Density of P. falciparum parasites     Essential Variables
#11.		newpos		              malaria diagnostic outcome	           Essential Variables
#12.		posneg		              Result of the blood smear              Essential Variables
#13.		positivo	              Current malaria result                 Essential Variables


# 4.1.7 Identify non-essential FINMERG variables ----

#tecnico1	tecnico2	fecha		fiebre2sem	fiebrepalu	visitacv	automedico	
#quetomo	diastratam	fechatoma	cdia1	cdia2	cdia3	cdia4	
#cdia5	pdia1 pdia2	 pdia3	pdia4	pdia5	fechadiagn		pabellon	
#insecticid	horadormid	fiebredia	oral axial	frecuencia	
#frios	visitocvdi	automedic2	quetomodia	
#cuantosdia	fechatomad	fechatom1	cdia1d	cdia2d	cdia3d	
#cdia4d	cdia5d	pdia1d	pdia2d	pdia3d pdia4d	pdia5d
#fechadiagd	gg	acetaminof	pf	isocode	pabellond	
#insectici2	usadod	acuestad	observad	FUENTE	FECTOMA	
#FECDIAG	TECNICO	BUSCAR	bednet 	prevnfeb	prevpos	prevfech	diff	GRUPO
#depto	nfebril	municipio	localidad	encuesta



# 4.1.8 Remove selected FINMERG variables ----

vars_to_remove_finmerge <- c(
  "tecnico1","depto","nfebril","municipio","localidad","encuesta","numeroid","tecnico2","id", "fecha", "fiebre2sem", "fiebrepalu", "visitacv", "automedico",
  "quetomo", "diastratam", "fechatoma", "cdia1", "cdia2", "cdia3", "cdia4",
  "cdia5", "pdia1", "pdia2", "pdia3", "pdia4", "pdia5", "fechadiagn", "pabellon",
  "insecticid", "horadormid", "fiebredia", "oral", "axial", "frecuencia",
  "frios", "visitocvdi", "automedic2", "quetomodia", "cuantosdia", "fechatomad",
  "fechatom1", "cdia1d", "cdia2d", "cdia3d", "cdia4d", "cdia5d", "pdia1d", "pdia2d",
  "pdia3d", "pdia4d", "pdia5d", "fechadiagd", "gg", "acetaminof", "pf", "isocode",
  "pabellond", "insectici2", "usadod", "acuestad", "observad", "FUENTE", "FECTOMA","numeroid",
  "FECDIAG", "TECNICO", "BUSCAR", "bednet", "prevnfeb", "prevpos", "prevfech",
  "diff", "GRUPO"
)

# Remove the variables from finmerge
finmergeClean <- finmerg[ , !(names(finmerg) %in% vars_to_remove_finmerge)]




# 4.2 Dataset linkage and outcome harmonisation ----


# 4.2.1 Join field-survey and laboratory records ----

#I need to rename the variable bafnoid to BAFNOID(Survey_number_Participant_identifier) in 
#the finmerg dataset to ensure smooth merging,
#as the variable is already named BAFNOID in the feball dataset. 

names(finmergeClean)[names(finmergeClean) == "bafnoid"] <- "BAFNOID"

mergeData1<- feballClean %>%
  left_join(finmergeClean, by = "BAFNOID")




# 4.2.2 Link participant-level biodata ----
#using NUMEROID(Participant_identifier) which is quite unique to both datset

# I need to rename the variable NUMEROID to numeroid in the habitat dataset to ensure smooth merging, 
#as the variable is already named numeroid in the mergeData1.

names(habitat)[names(habitat) == "NUMEROID"] <- "numeroid"


# 4.2.3 Convert age at survey to years ----
habitat$edad_years <- ifelse(
  grepl("m", habitat$EDAD, ignore.case = TRUE), 
  round(as.numeric(sub("m", "", habitat$EDAD, ignore.case = TRUE)) / 12, 2),  # Convert months to years and round to 2 decimal places
  ifelse(grepl("d", habitat$EDAD, ignore.case = TRUE), 
         round(as.numeric(sub("d", "", habitat$EDAD, ignore.case = TRUE)) / 365, 2),  # Convert days to years and round to 2 decimal places
         as.numeric(habitat$EDAD))  # Keep years as they are without rounding
)

# View the updated dataset
head(habitat)

mergeData2 <-left_join (mergeData1, habitat, by = "numeroid")



# 4.2.4 Deduplicate participant-survey records ----



library(dplyr)
library(stringr)

# 4.2.5 Create a backup of merged records ----
mergeData2_backup <- mergeData2

# 4.2.6 Recover the survey-round identifier ----
mergeData2 <- mergeData2 %>%
  mutate(
    BAFNOID_RAW   = str_squish(toupper(as.character(BAFNOID))),
    # Try to parse the round number like "S12..." -> 12; also try any digits if no "S"
    Survey_RoundB = suppressWarnings(
      coalesce(
        as.integer(str_extract(BAFNOID_RAW, "(?i)(?<=S)\\d+")),
        as.integer(str_extract(BAFNOID_RAW, "\\d+"))
      )
    )
  )

# 4.2.7 Prioritise records within participant-round groups ----
# Prefer: positive (NEW_MALARIA_SPP_BIN==1) > negative (==0) > missing (NA)
# Then prefer rows with a non-NA species label
mergeData2 <- mergeData2 %>%
  mutate(
    .pos_rank   = if ("NEW_MALARIA_SPP_BIN" %in% names(.))
      case_when(NEW_MALARIA_SPP_BIN == 1L ~ 0L,
                NEW_MALARIA_SPP_BIN == 0L ~ 1L,
                TRUE                       ~ 2L)
    else 1L,
    .species_rk = if ("NEW_MALARIA_SPP_SPECIES" %in% names(.))
      if_else(is.na(NEW_MALARIA_SPP_SPECIES), 1L, 0L)
    else 1L,
    .row_id     = row_number()
  )

# 4.2.8 Select representative participant-round records ----
# A) Has parsed Survey_RoundB -> dedup by (numeroid, Survey_RoundB)
partA <- mergeData2 %>%
  filter(!is.na(Survey_RoundB)) %>%
  group_by(numeroid, Survey_RoundB) %>%
  arrange(.pos_rank, .species_rk, .row_id, .by_group = TRUE) %>%
  slice(1L) %>%
  ungroup()

# B) No Survey_RoundB but has BAFNOID_RAW -> dedup by (numeroid, BAFNOID_RAW)
partB <- mergeData2 %>%
  filter(is.na(Survey_RoundB), !is.na(BAFNOID_RAW) & BAFNOID_RAW != "") %>%
  group_by(numeroid, BAFNOID_RAW) %>%
  arrange(.pos_rank, .species_rk, .row_id, .by_group = TRUE) %>%
  slice(1L) %>%
  ungroup()

# C) Neither Survey_RoundB nor BAFNOID_RAW -> keep as-is (cannot deduplicate)
partC <- mergeData2 %>%
  filter(is.na(Survey_RoundB) & (is.na(BAFNOID_RAW) | BAFNOID_RAW == ""))

# 4.2.9 Reassemble and audit deduplicated records ----
mergeData2_dedup <- bind_rows(partA, partB, partC) %>%
  select(-.pos_rank, -.species_rk, -.row_id)

# --- 5) Report how many rows were removed, then replace the original ---
removed_n <- nrow(mergeData2) - nrow(mergeData2_dedup)
message(sprintf("Deduplication complete: removed %s duplicate rows; kept %s of %s.",
                removed_n, nrow(mergeData2_dedup), nrow(mergeData2)))

mergeData2 <- mergeData2_dedup
rm(mergeData2_dedup)








# 4.2.10 Standardise malaria species classifications ----


library(dplyr)
library(stringr)



mergeData2 <- mergeData2 %>%
  mutate(
    # Normalize source
    res_std = toupper(str_squish(as.character(resultado))),
    res_std = if_else(res_std %in% c("", "4"), NA_character_, res_std),
    res_std = str_replace_all(res_std, "\\s*/\\s*", "/"),
    res_std = str_replace_all(res_std, "\\s+", " "),
    
    # Map to unified species result
    FINAL_MALARIA_WTH_SPP = case_when(
      is.na(res_std) ~ NA_character_,
      
      # NEGATIVE
      res_std %in% c("0","NEG","NEGATIVE","NEGATIVO","NEGATIVA",
                     "NO PARASITES","SIN PARASITOS","SIN PARÁSITOS") ~ "NEG",
      
      # VIVAX
      res_std %in% c("1","PV","VIVAX","P VIVAX","P. VIVAX","PLASMODIUM VIVAX") ~ "VIVAX",
      
      # FALCIPARUM
      res_std %in% c("2","PF","FALCIPARUM","P FALCIPARUM","P. FALCIPARUM",
                     "PLASMODIUM FALCIPARUM") ~ "FALCIPARUM",
      
      # MIXED (VIVAX/FALCIPARUM)
      res_std %in% c("3","PV/PF","PF/PV","VIVAX/FALCIPARUM","FALCIPARUM/VIVAX",
                     "PV+PF","PF+PV","MIXED","MIXTA","MIXED INFECTION",
                     "ASOCIADA","ASOCIADO") ~ "VIVAX/FALCIPARUM",
      
      # MALARIAE → classify as UNKNOWN (not NEG)
      res_std %in% c("P MALARIAE","P. MALARIAE","MALARIAE","PLASMODIUM MALARIAE") ~ "UNKNOWN",
      
      # anything else → NA
      TRUE ~ NA_character_
    )
  )

print(table(mergeData2$FINAL_SPP_POS1, useNA = "ifany"))









# 4.2.11 Derive binary malaria positivity indicators ----
# Positives (1): "VIVAX", "FALCIPARUM", "VIVAX/FALCIPARUM", "UNKNOWN"
# Negatives (0): everything else; NA stays NA.


library(dplyr)
library(stringr)

# Find the correct column (handles common name variants just in case)
spp_col <- intersect(
  c("FINAL_MALARIA_WTH_SPP", "FINAL_MALARIA_WITH_SPP", "final_malaria_wth_spp"),
  names(mergeData2)
)[1]
stopifnot(!is.null(spp_col))

mergeData2 <- mergeData2 %>%
  mutate(
    SPP_TXT = toupper(str_squish(as.character(.data[[spp_col]]))),
    FINAL_SPP_POS1 = case_when(
      is.na(SPP_TXT) ~ NA_integer_,
      SPP_TXT %in% c("VIVAX","FALCIPARUM","VIVAX/FALCIPARUM","UNKNOWN") ~ 1L,
      TRUE ~ 0L
    ),
    # (optional) readable label
    FINAL_SPP_POS1_LBL = case_when(
      is.na(FINAL_SPP_POS1) ~ NA_character_,
      FINAL_SPP_POS1 == 1L  ~ "Positive",
      TRUE                  ~ "Negative"
    )
  )


# 4.3 Species distribution and repeat-positive survey summaries ----
# 4.3.1 Supplementary Table S1: harmonised malaria outcomes and species ----
#by Plasmodium species and study arm during the intervention period


# 4.3.2 Load laboratory-summary packages ----
library(dplyr)
library(tidyr)

# 4.3.3 Define a binary outcome conversion function ----
# Standardises raw coding:
# 1 = Positive
# 0 = Negative
# NA = Missing
# Option to treat code "2" as 0 or 1 depending on variable definition

to01 <- function(x, treat_two_as_zero = TRUE) {
  x_num <- suppressWarnings(as.numeric(as.character(x)))
  
  if (treat_two_as_zero) {
    case_when(
      x_num == 1 ~ 1L,
      x_num %in% c(0, 2) ~ 0L,
      TRUE ~ NA_integer_
    )
  } else {
    case_when(
      x_num %in% c(1, 2) ~ 1L,
      x_num == 0 ~ 0L,
      TRUE ~ NA_integer_
    )
  }
}

# 4.3.4 Combine laboratory indicators into a malaria outcome ----

mergeData2 <- mergeData2 %>%
  mutate(
    # Clean raw laboratory indicators
    RESULTADOD_CLEAN_lc  = to01(resultadod,  treat_two_as_zero = TRUE),
    RESULTADOD_CLEAN_uc  = to01(RESULTADOD,  treat_two_as_zero = TRUE),
    FINAL_SPP_POS1_CLEAN = to01(FINAL_SPP_POS1, treat_two_as_zero = FALSE),
    
    # Combined malaria indicator (positive if ANY source positive)
    MALARIA_COMBINED3 = case_when(
      RESULTADOD_CLEAN_lc == 1L |
        RESULTADOD_CLEAN_uc == 1L |
        FINAL_SPP_POS1_CLEAN == 1L ~ 1L,
      
      RESULTADOD_CLEAN_lc == 0L &
        RESULTADOD_CLEAN_uc == 0L &
        FINAL_SPP_POS1_CLEAN == 0L ~ 0L,
      
      TRUE ~ NA_integer_
    ),
    
    # Human-readable label
    MALARIA_COMBINED3_LBL = case_when(
      MALARIA_COMBINED3 == 1L ~ "Positive",
      MALARIA_COMBINED3 == 0L ~ "Negative",
      TRUE ~ NA_character_
    ),
    
    # Treatment group label
    GroupLabel = case_when(
      GROUP == 1 ~ "Control",
      GROUP == 2 ~ "Intervention",
      TRUE ~ NA_character_
    ),
    
    # Standardise survey naming
    Survey_Number = NFEBRIL1
  )

# 4.3.5 Count positive results by survey round and study arm ----
# Output: positives and totals per Survey × Group

malaria_counts_long <- mergeData2 %>%
  filter(!is.na(GroupLabel)) %>%
  group_by(Survey_Number, GroupLabel) %>%
  summarise(
    positives = sum(MALARIA_COMBINED3 == 1L, na.rm = TRUE),
    total     = sum(!is.na(MALARIA_COMBINED3)),
    .groups   = "drop"
  ) %>%
  arrange(Survey_Number, GroupLabel)

print(malaria_counts_long)

# 4.3.6 Arrange survey-level results in wide format ----
# Output: one row per survey with Control, Intervention, and Total positives

malaria_counts_wide <- malaria_counts_long %>%
  select(Survey_Number, GroupLabel, positives) %>%
  pivot_wider(
    id_cols     = Survey_Number,
    names_from  = GroupLabel,
    values_from = positives,
    values_fill = 0
  ) %>%
  mutate(
    Total = Control + Intervention
  ) %>%
  arrange(Survey_Number)

print(malaria_counts_wide)

# 4.3.7 Harmonise the recorded Plasmodium species ----

mergeData2 <- mergeData2 %>%
  mutate(
    MALARIA_MAIN = MALARIA_COMBINED3,
    
    SPP_HARMONISED = case_when(
      MALARIA_MAIN == 0L ~ "NEG",
      MALARIA_MAIN == 1L & FINAL_MALARIA_WTH_SPP %in%
        c("FALCIPARUM","VIVAX","VIVAX/FALCIPARUM","UNKNOWN") ~ FINAL_MALARIA_WTH_SPP,
      MALARIA_MAIN == 1L &
        (is.na(FINAL_MALARIA_WTH_SPP) | FINAL_MALARIA_WTH_SPP == "NEG") ~ "POS_NO_SPP"
    )
  )

mergeData2 <- mergeData2 %>%
  mutate(
    MALARIA_MAIN = MALARIA_COMBINED3,
    
    SPP_HARMONISED = case_when(
      MALARIA_MAIN == 0L ~ "NEG",
      
      MALARIA_MAIN == 1L & FINAL_MALARIA_WTH_SPP %in%
        c("FALCIPARUM", "VIVAX", "VIVAX/FALCIPARUM") ~ FINAL_MALARIA_WTH_SPP,
      
      MALARIA_MAIN == 1L & FINAL_MALARIA_WTH_SPP %in%
        c("UNKNOWN", "POS_NO_SPP", "POS NO SPP") ~ "UNKNOWN",
      
      MALARIA_MAIN == 1L &
        (is.na(FINAL_MALARIA_WTH_SPP) | FINAL_MALARIA_WTH_SPP == "NEG") ~ "UNKNOWN",
      
      TRUE ~ NA_character_
    )
  )




# 4.3.8 Summarise Plasmodium species by study arm ----
# Output: count and percentage of species within each group

SPP_TABLE <- mergeData2 %>%
  filter(
    MALARIA_MAIN == 1L,
    !is.na(SPP_HARMONISED),
    !is.na(GroupLabel)
  ) %>%
  count(GroupLabel, SPP_HARMONISED) %>%
  group_by(GroupLabel) %>%
  mutate(
    pct = round(100 * n / sum(n), 1)
  ) %>%
  ungroup() %>%
  arrange(GroupLabel, SPP_HARMONISED)

print(SPP_TABLE)






# 4.3.9 Supplementary Figure S3: participant-level repeated positivity ----

.#Distribution of repeated malaria-positive survey rounds per individual,
#comparing recurrence burden between intervention and control groups.


# 4.3.10 Load repeated-positivity packages ----
library(dplyr)
library(stringr)
library(tidyr)
library(ggplot2)
library(scales)

# 4.3.11 Extract numeric survey rounds ----
# Robust parsing of survey round from multiple possible variables

mergeData2 <- mergeData2 %>%
  mutate(
    GROUP = as.character(GROUP),
    Survey_Round = coalesce(
      suppressWarnings(as.integer(as.character(NFEBRIL1))),
      suppressWarnings(as.integer(str_extract(as.character(NFEBRIL1), "\\d+"))),
      suppressWarnings(as.integer(str_extract(as.character(BAFNOID), "(?i)(?<=S)\\d+")))
    )
  )

# 4.3.12 Summarise tested person-rounds ----
# For each individual in each survey round:
#   - any_mal_pos = 1 if malaria positive at least once in that round
#   - tested = had any malaria result in that round

per_person_round <- mergeData2 %>%
  filter(!is.na(Survey_Round)) %>%
  group_by(numeroid, GROUP, Survey_Round) %>%
  summarise(
    any_mal_pos = as.integer(any(MALARIA_COMBINED3 == 1L, na.rm = TRUE)),
    tested      = as.integer(any(!is.na(MALARIA_COMBINED3))),
    .groups = "drop"
  ) %>%
  filter(tested == 1)

# 4.3.13 Count malaria-positive rounds per participant ----
# Calculates number of rounds each individual tested positive

per_person_counts <- per_person_round %>%
  group_by(numeroid, GROUP) %>%
  summarise(
    n_pos_surveys    = sum(any_mal_pos == 1L, na.rm = TRUE),
    n_surveys_tested = n(),
    .groups = "drop"
  )

print(per_person_counts)

# 4.3.14 Calculate repeat-positive frequency by study arm ----
# Distribution of individuals by number of positive rounds

freq_by_group <- per_person_counts %>%
  count(GROUP, n_pos_surveys, name = "n_individuals") %>%
  group_by(GROUP) %>%
  complete(
    n_pos_surveys = 0:max(n_pos_surveys, na.rm = TRUE),
    fill = list(n_individuals = 0L)
  ) %>%
  mutate(
    share   = n_individuals / sum(n_individuals),
    Percent = percent(share, accuracy = 0.1)
  ) %>%
  ungroup()

# 4.3.15 Prepare the recurrence frequency table ----

freq_table <- freq_by_group %>%
  mutate(GroupLabel = recode(GROUP,
                             "1" = "Control",
                             "2" = "Intervention",
                             .default = GROUP)) %>%
  select(
    Group               = GroupLabel,
    `# positive surveys` = n_pos_surveys,
    `Individuals (n)`   = n_individuals,
    `Individuals (%)`   = Percent
  ) %>%
  arrange(Group, `# positive surveys`)

print(freq_table)

# 4.3.16 Plot malaria-positive survey counts ----

group_cols <- c("Control" = "#1f77b4", "Intervention" = "#d62728")

plot_data <- freq_by_group %>%
  mutate(GroupLabel = recode(GROUP,
                             "1" = "Control",
                             "2" = "Intervention",
                             .default = GROUP)) %>%
  filter(n_pos_surveys > 0)

# Bar Plot
p_bar <- ggplot(plot_data,
                aes(x = factor(n_pos_surveys),
                    y = n_individuals,
                    fill = GroupLabel)) +
  geom_col(position = position_dodge(width = 0.7),
           width = 0.6,
           color = "grey25",
           linewidth = 0.25) +
  geom_text(aes(label = n_individuals),
            position = position_dodge(width = 0.7),
            vjust = -0.35,
            size = 3.4) +
  scale_fill_manual(values = group_cols, name = "Group") +
  labs(
    title = "Individuals by number of malaria-positive survey rounds",
    x     = "Reported malaria episodes per individual",
    y     = "Number of individuals"
  ) +
  theme_classic(base_size = 12)

print(p_bar)

# 4.3.17 Cross-check participant-round positives ----
# Confirms total person-round positives match

chk_lhs <- freq_by_group %>%
  group_by(GROUP) %>%
  summarise(
    total_person_round_positives = sum(n_pos_surveys * n_individuals),
    .groups = "drop"
  )

chk_rhs <- per_person_round %>%
  filter(any_mal_pos == 1L) %>%
  count(GROUP, name = "person_round_positives")

print(chk_lhs)
print(chk_rhs)





# 4.3.18 Supplementary Figure S4: positivity at multiple observation levels ----
## Main indicator: MALARIA_COMBINED3 (0/1)
## Species-based indicator: FINAL_MALARIA_WTH_SPP (0/1)

library(dplyr)
library(stringr)
library(tidyr)
library(ggplot2)
library(scales)

# 4.3.19 Standardise survey identifiers for frequency calculations ----
mergeData2 <- mergeData2 %>%
  mutate(
    GROUP = as.character(GROUP),
    Survey_Round = dplyr::coalesce(
      suppressWarnings(as.integer(as.character(NFEBRIL1))),
      suppressWarnings(as.integer(str_extract(as.character(NFEBRIL1), "\\d+"))),
      suppressWarnings(as.integer(str_extract(as.character(BAFNOID), "(?i)(?<=S)\\d+")))
    )
  )

# 4.3.20 Tabulate infection results by observation ----

# (i) Species-based indicator (FINAL_MALARIA_WTH_SPP)
rowwise_counts_spp <- mergeData2 %>%
  count(FINAL_MALARIA_WTH_SPP) %>%
  mutate(pct = round(100 * n / sum(n), 2))
print(rowwise_counts_spp)

# (ii) Main malaria indicator (MALARIA_COMBINED3)
rowwise_counts_mal <- mergeData2 %>%
  count(MALARIA_COMBINED3) %>%
  mutate(pct = round(100 * n / sum(n), 2))
print(rowwise_counts_mal)

# 4.3.21 Summarise distinct tested person-rounds ----

per_person_round <- mergeData2 %>%
  filter(!is.na(Survey_Round)) %>%
  group_by(numeroid, Survey_Round) %>%
  summarise(
    any_mal_pos = as.integer(any(MALARIA_COMBINED3 == 1L, na.rm = TRUE)),  # 0/1 per round
    tested      = as.integer(any(!is.na(MALARIA_COMBINED3))),              # had any malaria result
    .groups = "drop"
  ) %>%
  filter(tested == 1)

person_round_counts <- tibble(
  metric = c("person_round_positives","person_round_tested"),
  n = c(sum(per_person_round$any_mal_pos, na.rm = TRUE),
        nrow(per_person_round))
)
print(person_round_counts)

# 4.3.22 Count positive survey rounds per participant ----

per_person_counts <- per_person_round %>%
  group_by(numeroid) %>%
  summarise(
    n_pos_rounds    = sum(any_mal_pos == 1L, na.rm = TRUE),
    n_rounds_tested = n(),
    .groups = "drop"
  )

freq_indiv <- per_person_counts %>%
  count(n_pos_rounds, name = "n_individuals") %>%
  arrange(n_pos_rounds)
print(freq_indiv)

# 4.3.23 Cross-check positive counts ----
lhs <- freq_indiv %>%
  summarise(total = sum(n_pos_rounds * n_individuals)) %>%
  pull(total)
rhs <- person_round_counts %>%
  filter(metric == "person_round_positives") %>%
  pull(n)
message(sprintf("Check: sum(bin * n_individuals) = %s; person-round positives = %s", lhs, rhs))

# 4.3.24 Tabulate overall malaria positivity and study-arm frequency ----

frequency_table_mal <- mergeData2 %>%
  count(MALARIA_COMBINED3) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))
print(frequency_table_mal)

frequency_table_group <- mergeData2 %>%
  count(GROUP) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))
print(frequency_table_group)




# 4.4 Locality-level malaria positivity and incidence ----
# 4.4.1 Locality-level malaria positivity ----
## Using MALARIA_COMBINED3 (0/1)

library(dplyr)
library(tidyr)
library(ggplot2)
library(scales)

# 4.4.2 Standardise study-arm labels ----
mergeData2 <- mergeData2 %>%
  mutate(GROUP = as.character(GROUP))

# 4.4.3 Create the locality-to-arm lookup ----
loc_lu <- tibble::tribble(
  ~LOCALIDAD, ~Localidad_group, ~Localidad_name,
  1, "Intervention", "Monterrey",
  2, "Control",      "Sonora",
  3, "Control",      "La Caoba",
  5, "Control",      "Carolina",
  6, "Control",      "Atenas",
  7, "Intervention", "El Penon",
  8, "Control",      "Esija",
  9, "Intervention", "San Francisco",
  10, "Intervention", "Lorena",
  11, "Control",      "San Pablo",
  12, "Control",      "El Milagro",
  13, "Intervention", "San Jose la Viente",
  14, "Intervention", "Aldea Efrata",
  15, "Intervention", "Virginia",
  16, "Intervention", "San Juan la Quince",
  17, "Control",      "San Alfonso",
  18, "Intervention", "El Eden",
  20, "Intervention", "Santa Rosa",
  21, "Intervention", "Nuevas Ilusiones",
  22, "Control",      "Punto Chico",
  23, "Control",      "El Quetzal",
  24, "Intervention", "Santa Ana",
  25, "Control",      "El Afan",
  26, "Intervention", "Margaritas Dos",
  27, "Control",      "El Horizonte"
)

# 4.4.4 Join locality names and allocation ----
if (!all(c("Localidad_group","Localidad_name") %in% names(mergeData2))) {
  
  key_col <- c("LOCALIDAD","Localidad","Locality_code","Localidad_code")
  key_col <- key_col[key_col %in% names(mergeData2)][1]
  
  if (is.na(key_col)) {
    stop("No locality ID column (LOCALIDAD / Localidad / Locality_code / Localidad_code) found in mergeData2.")
  }
  
  mergeData2 <- mergeData2 %>%
    mutate(LOCALIDAD_key = as.integer(.data[[key_col]])) %>%
    left_join(loc_lu, by = c("LOCALIDAD_key" = "LOCALIDAD")) %>%
    select(-LOCALIDAD_key)
}

# 4.4.5 Estimate positivity by locality and study arm ----
loc_mal_summary <- mergeData2 %>%
  filter(!is.na(Localidad_name), !is.na(Localidad_group)) %>%
  group_by(Localidad_group, Localidad_name) %>%
  summarise(
    tested_n    = sum(!is.na(MALARIA_COMBINED3)),
    positive_n  = sum(MALARIA_COMBINED3 == 1L, na.rm = TRUE),
    negative_n  = sum(MALARIA_COMBINED3 == 0L, na.rm = TRUE),
    pos_rate    = ifelse(tested_n > 0,
                         round(100 * positive_n / tested_n, 2),
                         NA_real_),
    .groups = "drop"
  ) %>%
  arrange(Localidad_group, desc(pos_rate))

print(loc_mal_summary)
# This is your main "positivity per locality" table.

# 4.4.6 Summarise positivity by locality across study arms ----
loc_mal_overall <- mergeData2 %>%
  filter(!is.na(Localidad_name)) %>%
  group_by(Localidad_name) %>%
  summarise(
    tested_n    = sum(!is.na(MALARIA_COMBINED3)),
    positive_n  = sum(MALARIA_COMBINED3 == 1L, na.rm = TRUE),
    negative_n  = sum(MALARIA_COMBINED3 == 0L, na.rm = TRUE),
    pos_rate    = ifelse(tested_n > 0,
                         round(100 * positive_n / tested_n, 2),
                         NA_real_),
    .groups = "drop"
  ) %>%
  arrange(desc(pos_rate))

print(loc_mal_overall)


# 4.4.7 Locality-level incidence per 1,000 person-years ----
## Malaria incidence per 1,000 person-years by locality
## (bi-weekly person-rounds → person-years)

library(dplyr)
library(stringr)
library(ggplot2)
library(tidyr)

# 4.4.8 Identify participant ID fields ----
id_col <- intersect(
  c("Participant_unique_identifier", "numeroid", "Individual_ID"),
  names(mergeData2)
)[1]

if (is.na(id_col)) {
  stop("No person ID column found (Participant_unique_identifier / numeroid / Individual_ID).")
}

# 4.4.9 Prepare locality-specific incidence records ----
df_loc <- mergeData2 %>%
  mutate(
    person_id      = as.character(.data[[id_col]]),
    Survey_Group   = as.character(GROUP),    # "1" = Control, "2" = Intervention
    Localidad_group = as.character(Localidad_group),
    
    # Extract numeric survey round from Survey_Number(6-17)
    Survey_Number = suppressWarnings(
      as.integer(str_extract(as.character(NFEBRIL1), "\\d+"))
    ),
    
    # Clean malaria outcome from MALARIA_COMBINED3 (0/1/NA)
    malaria_pos = case_when(
      MALARIA_COMBINED3 %in% c(1L, 1, "1") ~ 1L,
      MALARIA_COMBINED3 %in% c(0L, 0, "0") ~ 0L,
      TRUE                                 ~ NA_integer_
    )
  ) %>%
  # keep valid IDs, survey rounds, and locality info within S6–S17
  filter(
    !is.na(person_id),
    !is.na(Survey_Number),
    Survey_Number >= 6, Survey_Number <= 17,
    !is.na(Localidad_name),
    !is.na(Localidad_group)
  )

# 4.4.10 Summarise tested person-rounds by locality ----
person_round_loc <- df_loc %>%
  group_by(Localidad_group, Localidad_name, person_id, Survey_Number) %>%
  summarise(
    tested  = as.integer(any(!is.na(malaria_pos))),              # had a result in that round
    any_pos = as.integer(any(malaria_pos == 1L, na.rm = TRUE)),  # ≥1 positive in that round
    .groups = "drop"
  ) %>%
  filter(tested == 1)   # only retain rounds where the person was actually tested

# 4.4.11 Calculate person-time and malaria incidence ----
interval_days <- 14  # each bi-weekly survey ~14 days of observation

incidence_loc_py <- person_round_loc %>%
  group_by(Localidad_group, Localidad_name) %>%
  summarise(
    n_person_rounds   = n(),                        # number of tested person-rounds
    events            = sum(any_pos, na.rm = TRUE), # malaria-positive rounds
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,           # cases per 1,000 person-years
      NA_real_
    ),
    .groups = "drop"
  ) %>%
  arrange(Localidad_group, desc(inc_per_1000_py)) %>%
  mutate(
    # nice labels for arms
    Survey_group = dplyr::recode(
      Localidad_group,
      "1" = "Control",
      "2" = "Intervention",
      .default = Localidad_group
    )
  )

print(incidence_loc_py)

# 4.4.12 Plot village-level incidence by study arm ----
ggplot(
  incidence_loc_py,
  aes(
    x    = inc_per_1000_py,
    y    = reorder(Localidad_name, inc_per_1000_py),
    fill = Survey_group
  )
) +
  geom_col(width = 0.7) +
  geom_text(
    aes(label = sprintf("%.1f", inc_per_1000_py)),
    hjust = -0.1, size = 3.0
  ) +
  facet_wrap(~ Survey_group, ncol = 2, scales = "free_y") +
  scale_x_continuous(
    expand = expansion(mult = c(0, 0.10))
  ) +
  scale_fill_manual(
    values = c("Control" = "#d62728",
               "Intervention" = "#1f77b4")
  ) +
  labs(
    title = "Malaria incidence per 1,000 person-years by village",
    x     = "Incidence (cases per 1,000 person-years)",
    y     = "Village",
    fill  = "Study arm"
  ) +
  theme_classic(base_size = 12) +
  theme(
    strip.text      = element_text(face = "bold"),
    legend.position = "top"
  )


# 4.4.13 Inspect the El Milagro incidence estimate ----
incidence_loc_py %>%
  filter(Localidad_name == "El Milagro") %>%
  select(
    Localidad_name,
    n_person_rounds,
    events,
    person_time_years,
    inc_per_1000_py
  )






# 4.5 Clinical and intervention covariate recoding ----
# ---------------------------------------------------------- #


# 4.5.1 Recode fever in the preceding two weeks ----


# Recode FIEBRE2SEM (FEVER IN PAST TWO WEEKS) into a new variable FIEBRE2SEM_NEW
# 1 = yes
# 2 = no
# 0, 3, and 23 are also treated as "no" (2)
# Anything else becomes NA

# Create a new variable 'FIEBRE2SEM_NEW' based on the code modification above

mergeData2$FIEBRE2SEM_NEW <- ifelse(mergeData2$FIEBRE2SEM == 1, 1, 2)

#check new varaible 
frequency_table <- mergeData2 %>%
  count(FIEBRE2SEM_NEW) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))

print(frequency_table)




# 4.5.2 Recode fever perceived as malaria ----


# Recode FIEBREPALU into FIEBREPALU2
# 2 and 3 → 0
# All other values remain the same

mergeData2 <- mergeData2 %>%
  mutate(FIEBREPALU2 = case_when(
    FIEBREPALU %in% c(2, 3) ~ 0,        # merge 2 and 3 into 0
    TRUE ~ FIEBREPALU                  # keep other responses as is
  ))


frequency_table <- mergeData2 %>%
  count(FIEBREPALU2) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))

# Show the table
print(frequency_table)



# 4.5.3 Recode self-medication ----
#(Prefared response,1= yes, 2= no) 
#( am  merging 2,3,7 and 11 to equate 0= no).

mergeData2$AUTOMEDICO_NEW <- ifelse(mergeData2$AUTOMEDICO %in% c(0, 2, 3, 7, 11), 0,
                                    mergeData2$AUTOMEDICO)




# 4.5.4 Classify medicines by chloroquine use ----

#The variable has the following ((responses=0,1,2,3,4,5,6,7,9,11,12) 

# # 1-Aralen (Chloroquine medication), 2-Paludol(Chloroquine medication),

#3-Resochin(Chloroquine medication), 4-Chloroquine (Chloroquine medication),

#5-Bimalar(Chloroquine medication)

#6-Aspirin, 7-Acetaminophen, 8-Paracetamol, 9-Ibuprofen,10-tetracycline,

#11-amoxirine, 12-trimethoprim-sulfa

# i coded 1-5 as chloroquine treatment

# i coded 0,6-12 as non-chloroquine treatment 

# (i want my prefared response to be:  no chloroquine treatement = 0, chloroquine treatment =1 )

# create a new code QUETOMO_NEW

# Recoding QUETOMO directly in the merge_data dataset using the code below to


# Create new variable 'quetomo_new' for chloroquine treatment coding
mergeData2$QUETOMO_NEW <- ifelse(mergeData2$QUETOMO %in% 1:5, 1,
                                 ifelse(mergeData2$QUETOMO %in% c(0, 6:12), 0, NA))
#check new varaible quetomo_new
frequency_table <- mergeData2 %>%
  count(QUETOMO_NEW) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))

print(frequency_table)




# 4.5.5 Recode duration of medication ----

#The variable has the following ((reponses 0,1,5,3,2,4,8,40,10,14)) 

#(I want Prefared response to be  - (0= 0day, 1= 1day, 2 = 2days, 3 = 3days, 4= 4days, 5= 5days).

#hence  i am making the values 8, 40, 14, equate to 0 and all other values remain unchanged,

# Recoding  DIASTRATAMdirectly in the merge_data dataset using the code below to
#create a new code diastratam_new

# Create new variable  DIASTRATAM_NEW, recoding 8, 40, 14, and 10 to 0; all others unchanged

mergeData2$DIASTRATAM_NEW <- ifelse( mergeData2$ DIASTRATAM %in% c(8, 40, 14, 10), 0, 
                                     mergeData2$ DIASTRATAM)



# 4.5.6 Recode insecticide treatment of bed nets ----

#The variable has the following responses 0, NA,1,2,3

#edit code  so that  "0","NA","2","3" → 0 : All other code remain same

#Recoding INSECTICI2 directly in the merged dataset using the code below to
#create a new code INSECTICI2_NEW


mergeData2$INSECTICI2_NEW <- ifelse(
  is.na(mergeData2$INSECTICI2) | mergeData2$INSECTICI2 %in% c(0, 2, 3),
  0,
  mergeData2$INSECTICI2
)

#check new variable INSECTICI2_NEW

frequency_table <- mergeData2 %>%
  count(INSECTICI2_NEW) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))

print(frequency_table)





# 4.5.7 Recode bed-net use ----

#The variable has the following responses 0, NA,1,2,3

#edit code  so that  "0","NA","2","3" → 0 : All other code remain same

#Recoding USADOD directly in the merged dataset using the code below to
#create a new code USADOD_NEW


mergeData2$USADOD_NEW <- ifelse(
  is.na(mergeData2$USADOD) | mergeData2$USADOD %in% c(0, 2, 3),
  0,
  mergeData2$USADOD
)




# 4.5.8 Rename variables for analytical datasets ----

mergeData2 <- mergeData2 %>%
  rename(
    Participant_unique_identifier = numeroid,
    Department_code = DEPTO,
    Municipality_code = MUNICIPIO,
    Locality_code = LOCALIDAD,
    `Survey_Number(6-17)` = NFEBRIL1,
    Household_ID = encuesta,
    Date_of_the_survey = FECHA,
    Individual_ID = ID.x,
    Survey_Group = GROUP,
    Transmission_level = TRANSMITIONLVL,
    Survey_number_Participant_identifier = BAFNOID,
    Fever_in_past_2wks = FIEBRE2SEM_NEW,
    Visit_to_healthcenter = VISITACV,
    Self_medication_taken = AUTOMEDICO_NEW,
    Medication_taken = QUETOMO_NEW,
    Days_medicn_taken = DIASTRATAM_NEW,
    Date_of_sample_collection = FECHATOMA,
    Diagnosis_date = FECHADIAGN,
    Fever_on_day_of_visit = FIEBREDIA,
    Fever_perceived_as_malaria = FIEBREPALU2,
    Own_a_mosquito_net = PABELLOND,
    Net_treated_with_insecticide = INSECTICI2_NEW,
    Do_you_use_the_net = USADOD_NEW,
    Age = edad_years,
    SEX = SEXO
  )


# 4.5.9 Specify excluded analysis variables ----

library(dplyr)

cols_to_remove <- c(
  "VIVAXA", "VIVAXG", "VIVAXL", "densvivax", "densfalci",
  "FALCIA", "FALCIG", "FALCIL", "ID.y", "RESULTADO", "resultadod",
  "resultado", "posneg", "positivo", "newpos", "EDAD",
  "Plasmodium.vivax", "Plasmodium.falciparum", "resultado_clean",
  "Combine_Mal_infn_with_spp", "RESULTADO_CLEAN", "MALARIA_INFC",
  "FIEBRE2SEM","QUETOMO","AUTOMEDICO","DIASTRATAM","RESULTADOD","USADOD",
  "Codigo","INTERVENTION","INSECTICI2","FIEBREPALU"
)

# 4.5.10 Further recoding of model covariates ----








# 4.5.11 Standardise health-centre visit indicators ----


# Recoding Visit_to_healthcenter variable Recode 2 to 0 
# in the Visit_to_healthcenter variable in mergeData2

mergeData2$Visit_to_healthcenter[mergeData2$Visit_to_healthcenter == 2] <- 0

frequency_table <- mergeData2 %>%
  count(Visit_to_healthcenter) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))

print(frequency_table)




# 4.5.12 Standardise recent-fever indicators ----


# Recoding Fever_in_past_2wks 0 to 2 and 2 to 0 in the
#Fever_in_past_2wks variable in mergeData2

mergeData2$Fever_in_past_2wks[mergeData2$Fever_in_past_2wks == 0] <- 2
mergeData2$Fever_in_past_2wks[mergeData2$Fever_in_past_2wks == 2] <- 0

frequency_table <- mergeData2 %>%
  count(Fever_in_past_2wks) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))
print(frequency_table)


# 4.5.13 Standardise fever at the survey visit ----

# Recode 0 to 2 and 2 to 0 in the Fever_on_day_of_visit variable in mergeData2


mergeData2 <- mergeData2 %>%
  mutate(
    Fever_on_day_of_visit = as.character(Fever_on_day_of_visit),
    Fever_on_day_of_visit = case_when(
      Fever_on_day_of_visit == "2" ~ "0",
      Fever_on_day_of_visit == "1" ~ "1",
      TRUE ~ Fever_on_day_of_visit
    ),
    Fever_on_day_of_visit = as.integer(Fever_on_day_of_visit)
  )


frequency_table <- mergeData2 %>%
  count(Fever_on_day_of_visit) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))
print(frequency_table)


# 4.5.14 Standardise mosquito-net ownership ----


# Recode 0 to 2 and 2 to 0 in the Own_a_mosquito_net variable in mergeData2
mergeData2 <- mergeData2 %>%
  mutate(
    Own_a_mosquito_net = as.character(Own_a_mosquito_net),
    Own_a_mosquito_net = if_else(Own_a_mosquito_net == "2", "0", Own_a_mosquito_net),
    Own_a_mosquito_net = as.integer(Own_a_mosquito_net)
  )
frequency_table <- mergeData2 %>%
  count(Own_a_mosquito_net) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))
print(frequency_table)


# 4.5.15 Define categorical age groups ----

library(dplyr)

library(dplyr)

mergeData2 <- mergeData2 %>%
  mutate(
    # (1) Rebuild labeled bands (keeps your original logic)
    Age_group = case_when(
      Age < 5                   ~ "<5y",
      Age >= 5 & Age <= 14      ~ "5–14y",
      Age >= 15                 ~ "15+",
      TRUE                      ~ NA_character_
    ),
    Age_group = factor(Age_group, levels = c("<5y","5–14y","15+")),
    
    # (2) Numeric code: 0=<5y, 1=5–14y, 2=15+, 3=NA
    Age_group_code = case_when(
      Age_group == "<5y"   ~ 0L,
      Age_group == "5–14y" ~ 1L,
      Age_group == "15+"   ~ 2L,
      is.na(Age_group)     ~ 3L
    )
  )



# 4.6 Survey-level malaria outcomes and incidence diagnostics ----
# 4.6.1 Malaria positivity by study arm and survey ----
## Indicator: MALARIA_COMBINED3 (0/1/NA)
## Group: Survey_Group (1 = Control, 2 = Intervention)
## Survey rounds: Survey_Number(6-17)

library(dplyr)
library(tidyr)
library(stringr)
library(ggplot2)
library(scales)

# 4.6.2 Prepare survey-round and individual identifiers ----
df <- mergeData2

df <- df %>%
  mutate(
    # Person ID (adjust if your ID column is different)
    person_key   = as.character(Participant_unique_identifier),
    
    # Ensure Survey_Group is character; will recode below
    Survey_Group = as.character(Survey_Group),
    
    # Extract survey number 6–17 from the column `Survey_Number(6-17)`
    Survey_Number = suppressWarnings(
      as.integer(str_extract(as.character(`Survey_Number(6-17)`), "\\d+"))
    ),
    
    # Clean malaria indicator from MALARIA_COMBINED3
    malaria_pos = case_when(
      MALARIA_COMBINED3 %in% c(1L, 1, "1") ~ 1L,
      MALARIA_COMBINED3 %in% c(0L, 0, "0") ~ 0L,
      TRUE                                 ~ NA_integer_
    )
  ) %>%
  filter(!is.na(person_key))   # keep only rows with a valid person ID

# Restrict to survey rounds 6–17
df6_17 <- df %>%
  filter(!is.na(Survey_Number),
         Survey_Number >= 6,
         Survey_Number <= 17)

# 4.6.3 Construct unique tested person-round records ----
# One decision per person per survey: any positive (0/1), and tested (0/1)
person_round <- df6_17 %>%
  group_by(Survey_Group, person_key, Survey_Number) %>%
  summarise(
    any_pos = as.integer(any(malaria_pos == 1L, na.rm = TRUE)),  # 1 if any positive in that round
    tested  = as.integer(any(!is.na(malaria_pos))),              # 1 if they had any malaria result
    .groups = "drop"
  ) %>%
  filter(tested == 1)   # keep only tested person-rounds

# 4.6.4 Summarise positive and tested individuals by round ----
counts_person <- person_round %>%
  group_by(Survey_Group, Survey_Number) %>%
  summarise(
    positives_indiv = sum(any_pos, na.rm = TRUE),                    # unique positive individuals
    tested_indiv    = sum(tested,  na.rm = TRUE),                    # individuals tested
    prev_indiv      = if_else(tested_indiv > 0,
                              positives_indiv / tested_indiv,
                              NA_real_),                             # prevalence as proportion
    .groups = "drop"
  ) %>%
  arrange(Survey_Group, Survey_Number)

print(counts_person)

# 4.6.5 Calculate study-arm totals ----
totals_person <- counts_person %>%
  group_by(Survey_Group) %>%
  summarise(
    positives_indiv_total = sum(positives_indiv),
    tested_indiv_total    = sum(tested_indiv),
    prev_indiv_overall    = if_else(tested_indiv_total > 0,
                                    positives_indiv_total / tested_indiv_total,
                                    NA_real_),
    .groups = "drop"
  )

print(totals_person)

# 4.6.6 Create wide-format round counts ----
counts_person_wide <- counts_person %>%
  select(Survey_Group, Survey_Number, positives_indiv) %>%
  pivot_wider(
    id_cols     = Survey_Group,
    names_from  = Survey_Number,
    values_from = positives_indiv,
    names_prefix = "S",
    values_fill  = 0
  )

print(counts_person_wide)

# 4.6.7 Calculate pooled survey-round totals ----
overall_person <- person_round %>%
  group_by(Survey_Number) %>%
  summarise(
    positives_indiv = sum(any_pos, na.rm = TRUE),
    tested_indiv    = sum(tested,  na.rm = TRUE),
    prev_indiv      = if_else(tested_indiv > 0,
                              positives_indiv / tested_indiv,
                              NA_real_),
    .groups = "drop"
  ) %>%
  mutate(Survey_Group = "Overall") %>%
  select(Survey_Group, everything()) %>%
  arrange(Survey_Number)

counts_person_with_overall <- bind_rows(counts_person, overall_person) %>%
  arrange(Survey_Group, Survey_Number)

print(counts_person_with_overall)

# 4.6.8 Tabulate record-level malaria results ----
counts_rows <- df6_17 %>%
  group_by(Survey_Group, Survey_Number) %>%
  summarise(
    positives_rows = sum(malaria_pos == 1L, na.rm = TRUE),          # positive rows
    tested_rows    = sum(!is.na(malaria_pos)),                      # rows with a malaria result
    prev_rows      = if_else(tested_rows > 0,
                             positives_rows / tested_rows,
                             NA_real_),
    .groups = "drop"
  ) %>%
  arrange(Survey_Group, Survey_Number)

print(counts_rows)

# Totals by group (row-level)
totals_rows <- counts_rows %>%
  group_by(Survey_Group) %>%
  summarise(
    positives_rows_total = sum(positives_rows),
    tested_rows_total    = sum(tested_rows),
    prev_rows_overall    = if_else(tested_rows_total > 0,
                                   positives_rows_total / tested_rows_total,
                                   NA_real_),
    .groups = "drop"
  )

print(totals_rows)

# Wide table: positive rows per survey
counts_rows_wide <- counts_rows %>%
  select(Survey_Group, Survey_Number, positives_rows) %>%
  pivot_wider(
    id_cols     = Survey_Group,
    names_from  = Survey_Number,
    values_from = positives_rows,
    names_prefix = "S",
    values_fill  = 0
  )

print(counts_rows_wide)

# 4.6.9 Prepare individual round-count plotting variables ----
# Recode Survey_Group to readable labels if it is "1"/"2"
counts_person_lab <- counts_person %>%
  mutate(
    Round_Index = Survey_Number - 5,  # 6→1, 7→2, ..., 17→12
    GroupLabel  = dplyr::recode(
      Survey_Group,
      "1" = "Control",
      "2" = "Intervention",
      .default = Survey_Group
    )
  )

round_levels <- sort(unique(counts_person_lab$Round_Index))

round_levels

counts_person_lab <- counts_person %>%
  mutate(
    Survey_Number = as.numeric(as.character(Survey_Number))
  ) %>%
  filter(Survey_Number >= 6, Survey_Number <= 17) %>%
  mutate(
    Round_Index = Survey_Number - 5,  # Survey 6 = Round 1; Survey 17 = Round 12
    
    GroupLabel = case_when(
      as.character(Survey_Group) %in% c("Control", "1") ~ "Control",
      as.character(Survey_Group) %in% c("Intervention", "2") ~ "Intervention",
      TRUE ~ as.character(Survey_Group)
    )
  )

round_levels <- 1:12

print(
  counts_person_lab %>%
    distinct(Survey_Number, Round_Index) %>%
    arrange(Round_Index)
)

print(
  counts_person_lab %>%
    count(GroupLabel, Round_Index)
)





# 4.6.10 Initial 12-round incidence plotting workflow ----

library(dplyr)
library(ggplot2)

# 4.6.11 Calculate round-level person-time and rates ----

counts_person_rate_py_12 <- counts_person %>%
  mutate(
    Survey_Number = as.numeric(as.character(Survey_Number)),
    Round_Index = Survey_Number - 5,
    
    GroupLabel = case_when(
      as.character(Survey_Group) %in% c("Control", "1") ~ "Control",
      as.character(Survey_Group) %in% c("Intervention", "2") ~ "Intervention",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(
    Survey_Number >= 6,
    Survey_Number <= 17,
    Round_Index >= 1,
    Round_Index <= 12,
    !is.na(GroupLabel)
  ) %>%
  mutate(
    # fixed bi-weekly round denominator
    person_years = persons * (14 / 365.25),
    inc_per_1000_py = (cases / person_years) * 1000
  )

# 4.6.12 Verify survey-round indexing ----
counts_person_rate_py_12 %>%
  distinct(Survey_Number, Round_Index) %>%
  arrange(Round_Index) %>%
  print()

# 4.6.13 Inspect computed round-level values ----
counts_person_rate_py_12 %>%
  select(GroupLabel, Survey_Number, Round_Index, cases, persons, person_years, inc_per_1000_py) %>%
  arrange(GroupLabel, Round_Index) %>%
  print(n = Inf)

# 4.6.14 Plot round-specific incidence rates ----
p_rounds_1_12 <- ggplot(
  counts_person_rate_py_12,
  aes(
    x = Round_Index,
    y = inc_per_1000_py,
    color = GroupLabel,
    group = GroupLabel
  )
) +
  geom_line(linewidth = 1) +
  geom_point(size = 2.5) +
  scale_x_continuous(
    breaks = 1:12,
    limits = c(1, 12),
    labels = paste0("R", 1:12)
  ) +
  scale_color_manual(
    values = c(
      "Control" = "#d62728",
      "Intervention" = "#1f77b4"
    )
  ) +
  labs(
    title = "Malaria incidence per 1,000 person-years by intervention round",
    subtitle = "Round 1 = Survey 6; Round 12 = Survey 17",
    x = "Bi-weekly intervention rounds (1–12)",
    y = "Incidence (cases per 1,000 person-years per round)",
    color = "Study arm"
  ) +
  theme_classic(base_size = 12) +
  theme(
    legend.position = "top",
    panel.grid = element_blank()
  )

print(p_rounds_1_12)


# 4.6.15 Repeat checks for the final survey rounds ----
counts_person_rate_py_12 <- counts_person %>%
  mutate(
    Survey_Number = as.numeric(as.character(Survey_Number)),
    Round_Index = Survey_Number - 5,
    GroupLabel = case_when(
      as.character(Survey_Group) %in% c("Control", "1") ~ "Control",
      as.character(Survey_Group) %in% c("Intervention", "2") ~ "Intervention",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(
    Survey_Number >= 6,
    Survey_Number <= 17,
    Round_Index >= 1,
    Round_Index <= 12,
    !is.na(GroupLabel)
  ) %>%
  mutate(
    person_years = persons * (14 / 365.25),
    inc_per_1000_py = (cases / person_years) * 1000
  )

counts_person_rate_py_12 %>%
  filter(Round_Index %in% c(11, 12)) %>%
  select(any_of(c(
    "GroupLabel",
    "Survey_Number",
    "Round_Index",
    "cases",
    "positive",
    "positives",
    "malaria_cases",
    "n_cases",
    "persons",
    "person_years",
    "inc_per_1000_py"
  ))) %>%
  arrange(GroupLabel, Round_Index) %>%
  print(n = Inf)

# 4.6.16 Inspect available outcome and denominator fields ----
names(counts_person)
names(counts_person_rate_py_12)

counts_person %>% 
  filter(Survey_Number %in% c(16, 17)) %>% 
  print(n = Inf)

library(dplyr)
library(ggplot2)

library(dplyr)
library(ggplot2)

# 4.6.17 Rebuild incidence from participant-level data ----
# Rebuild counts correctly from participant-level data
# Round 1 = Survey 6; Round 12 = Survey 17

# Use your participant-level dataset here
# Change df to your actual raw/long dataset name if needed
dat_source <- df

# 4.6.18 Prepare participant-level survey-round data ----

dat_round_12 <- dat_source %>%
  mutate(
    Survey_Number = as.numeric(as.character(Survey_Number)),
    Round_Index = Survey_Number - 5,
    
    # Use the malaria outcome variable available in your dataset
    # If your variable is not infection_status, replace it below
    positive = as.integer(infection_status == 1),
    
    # Survey_Group coding: 1 = Control, 2 = Intervention
    GroupLabel = case_when(
      as.character(Survey_Group) %in% c("1", "Control") ~ "Control",
      as.character(Survey_Group) %in% c("2", "Intervention") ~ "Intervention",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(
    Survey_Number >= 6,
    Survey_Number <= 17,
    Round_Index >= 1,
    Round_Index <= 12,
    !is.na(GroupLabel),
    !is.na(positive)
  )

# 4.6.19 Recalculate cases and persons tested ----

counts_person_rate_py_12 <- dat_round_12 %>%
  group_by(GroupLabel, Survey_Number, Round_Index) %>%
  summarise(
    positives_indiv = sum(positive, na.rm = TRUE),
    
    # This is the correct denominator: all tested/observed people,
    # not only malaria-positive people
    tested_indiv = n_distinct(Participant_unique_identifier),
    
    # Fixed bi-weekly person-time denominator
    person_time_years = tested_indiv * (14 / 365.25),
    
    inc_per_1000_py = if_else(
      person_time_years > 0,
      (positives_indiv / person_time_years) * 1000,
      NA_real_
    ),
    .groups = "drop"
  )

# 4.6.20 Check results for rounds 11 and 12 ----

counts_person_rate_py_12 %>%
  filter(Round_Index %in% c(11, 12)) %>%
  select(
    GroupLabel,
    Survey_Number,
    Round_Index,
    positives_indiv,
    tested_indiv,
    person_time_years,
    inc_per_1000_py
  ) %>%
  arrange(GroupLabel, Round_Index) %>%
  print(n = Inf)

# 4.6.21 Inspect all twelve survey rounds ----

counts_person_rate_py_12 %>%
  select(
    GroupLabel,
    Survey_Number,
    Round_Index,
    positives_indiv,
    tested_indiv,
    person_time_years,
    inc_per_1000_py
  ) %>%
  arrange(GroupLabel, Round_Index) %>%
  print(n = Inf)


library(dplyr)
library(ggplot2)

library(dplyr)
library(ggplot2)

# 4.6.22 Reconstruct tested-person denominators ----
# Uses existing positives_indiv from counts_person
# Recalculates tested_indiv from participant-level data

# 4.6.23 Select an available participant-level dataset ----
# This dataset must contain Participant_unique_identifier, Survey_Group, Survey_Number

if (exists("mergeData2")) {
  raw_data <- mergeData2
} else if (exists("df")) {
  raw_data <- df
} else if (exists("dat")) {
  raw_data <- dat
} else if (exists("CRT_GEE2")) {
  raw_data <- CRT_GEE2
} else {
  stop("No participant-level dataset found. Use the raw dataset with one row per participant per survey.")
}

# 4.6.24 Recalculate persons tested at each survey ----
raw_denominator <- raw_data %>%
  mutate(
    Survey_Number = as.numeric(as.character(Survey_Number)),
    
    GroupLabel = case_when(
      as.character(Survey_Group) %in% c("Control", "1") ~ "Control",
      as.character(Survey_Group) %in% c("Intervention", "2") ~ "Intervention",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(
    Survey_Number >= 6,
    Survey_Number <= 17,
    !is.na(GroupLabel),
    !is.na(Participant_unique_identifier)
  ) %>%
  group_by(GroupLabel, Survey_Number) %>%
  summarise(
    tested_indiv_fixed = n_distinct(Participant_unique_identifier),
    .groups = "drop"
  )

# 4.6.25 Prepare survey-round positive case counts ----
positive_counts <- counts_person %>%
  mutate(
    Survey_Number = as.numeric(as.character(Survey_Number)),
    Round_Index = Survey_Number - 5,
    
    GroupLabel = case_when(
      as.character(Survey_Group) %in% c("Control", "1") ~ "Control",
      as.character(Survey_Group) %in% c("Intervention", "2") ~ "Intervention",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(
    Survey_Number >= 6,
    Survey_Number <= 17,
    Round_Index >= 1,
    Round_Index <= 12,
    !is.na(GroupLabel)
  ) %>%
  group_by(GroupLabel, Survey_Number, Round_Index) %>%
  summarise(
    positives_indiv = sum(positives_indiv, na.rm = TRUE),
    .groups = "drop"
  )

# 4.6.26 Join case counts to the survey denominators ----
counts_person_rate_py_12_fixed <- positive_counts %>%
  left_join(
    raw_denominator,
    by = c("GroupLabel", "Survey_Number")
  ) %>%
  mutate(
    tested_indiv = tested_indiv_fixed,
    person_time_years = tested_indiv * (14 / 365.25),
    inc_per_1000_py = if_else(
      person_time_years > 0,
      (positives_indiv / person_time_years) * 1000,
      NA_real_
    )
  ) %>%
  select(
    GroupLabel,
    Survey_Number,
    Round_Index,
    positives_indiv,
    tested_indiv,
    person_time_years,
    inc_per_1000_py
  )

# 4.6.27 Inspect the final two survey rounds ----
counts_person_rate_py_12_fixed %>%
  filter(Survey_Number %in% c(16, 17)) %>%
  arrange(GroupLabel, Survey_Number) %>%
  print(n = Inf)

# 4.6.28 Review all recalculated rates ----
counts_person_rate_py_12_fixed %>%
  arrange(GroupLabel, Round_Index) %>%
  print(n = Inf)

# 4.6.29 Plot incidence with reconstructed denominators ----
p_rounds_1_12_fixed <- ggplot(
  counts_person_rate_py_12_fixed,
  aes(
    x = Round_Index,
    y = inc_per_1000_py,
    color = GroupLabel,
    group = GroupLabel
  )
) +
  geom_line(linewidth = 1) +
  geom_point(size = 2.5) +
  scale_x_continuous(
    breaks = 1:12,
    labels = paste0("R", 1:12)
  ) +
  scale_color_manual(
    values = c(
      "Control" = "#d62728",
      "Intervention" = "#1f77b4"
    )
  ) +
  labs(
    x = "Bi-weekly intervention rounds (1–12)",
    y = "Incidence per 1,000 person-years",
    color = "Study arm"
  ) +
  theme_classic(base_size = 12) +
  theme(
    legend.position = "top",
    panel.grid = element_blank()
  )

print(p_rounds_1_12_fixed)




# 4.7 Malaria outcome encoding, associations, and GEE preparation ----
# 4.7.1 Create the numeric malaria indicator ----

mergeData2$FINAL_MALARIA_NUM1 <- suppressWarnings(
  as.integer(as.character(mergeData2$MALARIA_COMBINED3))
)



# 4.7.2 Inspect numeric outcome frequencies ----
frequency_table <- mergeData2 %>%
  count(FINAL_MALARIA_NUM1) %>%
  mutate(percentage = round(100 * n / sum(n), 2)) %>%
  arrange(desc(n))

print(frequency_table)




# 4.7.3 Associations of malaria status with fever and bed-net use ----
# Surveys 6–17 = Rounds 1–12
# Outcome: FINAL_MALARIA_NUM1

library(dplyr)
library(stringr)
library(tidyr)
library(ggplot2)

#

# 4.7.4 Load packages for association models ----
library(tidyverse)
library(broom)
library(ggplot2)

# 4.7.5 Prepare fever and malaria variables ----
df_clean <- mergeData2 %>%
  mutate(
    FINAL_MALARIA_NUM1 = as.integer(FINAL_MALARIA_NUM1),     # assume 0/1
    Fever_in_past_2wks = factor(Fever_in_past_2wks,
                                levels = c(0, 1),
                                labels = c("No", "Yes")),
    Survey_Group       = factor(Survey_Group,
                                levels = c(1, 2),
                                labels = c("Control", "Intervention"))
  )

# Quick checks
summary(df_clean$FINAL_MALARIA_NUM1)
table(df_clean$Fever_in_past_2wks, useNA = "ifany")
table(df_clean$Survey_Group, useNA = "ifany")

# 4.7.6 Tabulate fever and malaria outcomes ----
# 2a) Overall 2x2 table: Fever_in_past_2wks vs FINAL_MALARIA_NUM1
tab_overall <- df_clean %>%
  count(Fever_in_past_2wks, FINAL_MALARIA_NUM1) %>%
  group_by(Fever_in_past_2wks) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()
tab_overall

# 2b) Stratified by Survey_Group
tab_by_group <- df_clean %>%
  count(Survey_Group, Fever_in_past_2wks, FINAL_MALARIA_NUM1) %>%
  group_by(Survey_Group, Fever_in_past_2wks) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()
tab_by_group

# 4.7.7 Perform chi-square tests for recent fever ----
chisq.test(table(df_clean$Fever_in_past_2wks, df_clean$FINAL_MALARIA_NUM1))

# Chi-square within each Survey_Group:
by(df_clean, df_clean$Survey_Group, function(d)
  chisq.test(table(d$Fever_in_past_2wks, d$FINAL_MALARIA_NUM1))
)

# 4.7.8 Fit the fever-by-arm logistic interaction ----
# Outcome: FINAL_MALARIA_NUM1
# Predictors: Fever_in_past_2wks, Survey_Group, and their interaction
m1 <- glm(FINAL_MALARIA_NUM1 ~ Fever_in_past_2wks * Survey_Group,
          family = binomial, data = df_clean)

summary(m1)

# Tidy ORs + 95% CI
or_m1 <- broom::tidy(m1, conf.int = TRUE, conf.level = 0.95, exponentiate = TRUE)
or_m1

# 4.7.9 Plot predicted malaria probabilities by fever status ----
newdat <- expand.grid(
  Fever_in_past_2wks = levels(df_clean$Fever_in_past_2wks),
  Survey_Group       = levels(df_clean$Survey_Group)
)

pred <- predict(m1, newdata = newdat, type = "link", se.fit = TRUE)

newdat <- newdat %>%
  mutate(
    linpred = pred$fit,
    se      = pred$se.fit,
    prob    = plogis(linpred),
    lower   = plogis(linpred - 1.96 * se),
    upper   = plogis(linpred + 1.96 * se)
  )

ggplot(newdat, aes(x = Fever_in_past_2wks, y = prob, group = Survey_Group)) +
  geom_point(position = position_dodge(width = 0.2), size = 3) +
  geom_errorbar(aes(ymin = lower, ymax = upper),
                width = 0.1,
                position = position_dodge(width = 0.2)) +
  geom_line(position = position_dodge(width = 0.2)) +
  facet_wrap(~ Survey_Group) +
  labs(
    x = "Reported malaria in past 2 weeks",
    y = "Predicted probability of FINAL_MALARIA_NUM1 = 1",
    title = "Malaria positivity vs. past-2-week malaria status, by survey group"
  ) +
  theme_minimal()

theme_minimal()

# 4.7.10 Preserve optional commented GEE specification ----
# If you have a cluster variable (e.g., village_id or household_id) use it as 'CLUSTER_ID'
# Replace CLUSTER_ID with your actual column if available.
# library(geepack)
# m1_gee <- geeglm(FINAL_MAL_NUM1 ~ MALARIA_PAST2WEEKS * SURVEY_GROUP,
#                  family = binomial,
#                  id = CLUSTER_ID,     # <-- put your cluster variable here
#                  corstr = "independence",  # safe default
#                  data = df_clean)
# summary(m1_gee)

# # Get ORs from GEE
# gee_or <- broom::tidy(m1_gee, conf.int = TRUE, conf.level = 0.95, exponentiate = TRUE)
# gee_or

# 4.7.11 Prepare covariates for perceived-fever and net-use models ----
library(tidyverse)
library(broom)
library(ggplot2)

# ---- 1) Tidy / recode (IN-PLACE on your exact names) ----
df_clean <- mergeData2 %>%
  mutate(
    FINAL_MALARIA_NUM1       = as.integer(FINAL_MALARIA_NUM1),     # assume 0/1
    Fever_in_past_2wks       = factor(Fever_in_past_2wks, levels = c(0, 1), labels = c("No", "Yes")),
    Survey_Group             = factor(Survey_Group,   levels = c(1, 2), labels = c("Control", "Intervention")),
    Fever_perceived_as_malaria = factor(Fever_perceived_as_malaria, levels = c(0, 1), labels = c("No", "Yes")),
    Do_you_use_the_net         = factor(Do_you_use_the_net,         levels = c(0, 1), labels = c("No", "Yes"))
  )

# Quick checks
summary(df_clean$FINAL_MALARIA_NUM1)
table(df_clean$Fever_perceived_as_malaria, useNA = "ifany")
table(df_clean$Do_you_use_the_net, useNA = "ifany")
table(df_clean$Survey_Group, useNA = "ifany")

# 4.7.12 Perceived malaria: association with test positivity ----

# 4.7.13 Tabulate perceived-malaria status and outcome ----
# Overall table
tab_overall_fpm <- df_clean %>%
  count(Fever_perceived_as_malaria, FINAL_MALARIA_NUM1) %>%
  group_by(Fever_perceived_as_malaria) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()
tab_overall_fpm

# Stratified by Survey_Group
tab_by_group_fpm <- df_clean %>%
  count(Survey_Group, Fever_perceived_as_malaria, FINAL_MALARIA_NUM1) %>%
  group_by(Survey_Group, Fever_perceived_as_malaria) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()
tab_by_group_fpm

# 4.7.14 Test associations for perceived malaria ----
chisq.test(table(df_clean$Fever_perceived_as_malaria, df_clean$FINAL_MALARIA_NUM1))

by(df_clean, df_clean$Survey_Group, function(d)
  chisq.test(table(d$Fever_perceived_as_malaria, d$FINAL_MALARIA_NUM1))
)

# 4.7.15 Fit the perceived-malaria logistic interaction ----
m_fpm <- glm(FINAL_MALARIA_NUM1 ~ Fever_perceived_as_malaria * Survey_Group,
             family = binomial, data = df_clean)

summary(m_fpm)

or_fpm <- broom::tidy(m_fpm, conf.int = TRUE, conf.level = 0.95, exponentiate = TRUE)
or_fpm

# 4.7.16 Plot predicted probabilities by perceived-malaria response ----
newdat_fpm <- expand.grid(
  Fever_perceived_as_malaria = levels(df_clean$Fever_perceived_as_malaria),
  Survey_Group               = levels(df_clean$Survey_Group)
)

pred_fpm <- predict(m_fpm, newdata = newdat_fpm, type = "link", se.fit = TRUE)

newdat_fpm <- newdat_fpm %>%
  mutate(
    linpred = pred_fpm$fit,
    se      = pred_fpm$se.fit,
    prob    = plogis(linpred),
    lower   = plogis(linpred - 1.96 * se),
    upper   = plogis(linpred + 1.96 * se)
  )

ggplot(newdat_fpm, aes(x = Fever_perceived_as_malaria, y = prob, group = Survey_Group)) +
  geom_point(position = position_dodge(width = 0.2), size = 3) +
  geom_errorbar(aes(ymin = lower, ymax = upper),
                width = 0.1,
                position = position_dodge(width = 0.2)) +
  geom_line(position = position_dodge(width = 0.2)) +
  facet_wrap(~ Survey_Group) +
  labs(
    x = "Fever perceived as malaria",
    y = "Predicted probability of FINAL_MALARIA_NUM1 = 1",
    title = "Malaria positivity vs. fever perceived as malaria, by survey group"
  ) +
  theme_minimal()

# 4.7.17 Bed-net use: association with malaria positivity ----

# 4.7.18 Tabulate malaria outcomes by net-use status ----
# Overall table
tab_overall_net <- df_clean %>%
  count(Do_you_use_the_net, FINAL_MALARIA_NUM1) %>%
  group_by(Do_you_use_the_net) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()
tab_overall_net

# Stratified by Survey_Group
tab_by_group_net <- df_clean %>%
  count(Survey_Group, Do_you_use_the_net, FINAL_MALARIA_NUM1) %>%
  group_by(Survey_Group, Do_you_use_the_net) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()
tab_by_group_net

# 4.7.19 Test associations for bed-net use ----
chisq.test(table(df_clean$Do_you_use_the_net, df_clean$FINAL_MALARIA_NUM1))

by(df_clean, df_clean$Survey_Group, function(d)
  chisq.test(table(d$Do_you_use_the_net, d$FINAL_MALARIA_NUM1))
)

# 4.7.20 Fit the bed-net-use logistic interaction ----
m_net <- glm(FINAL_MALARIA_NUM1 ~ Do_you_use_the_net * Survey_Group,
             family = binomial, data = df_clean)

summary(m_net)

or_net <- broom::tidy(m_net, conf.int = TRUE, conf.level = 0.95, exponentiate = TRUE)
or_net

# 4.7.21 Plot predicted probabilities by net-use status ----
newdat_net <- expand.grid(
  Do_you_use_the_net = levels(df_clean$Do_you_use_the_net),
  Survey_Group       = levels(df_clean$Survey_Group)
)

pred_net <- predict(m_net, newdata = newdat_net, type = "link", se.fit = TRUE)

newdat_net <- newdat_net %>%
  mutate(
    linpred = pred_net$fit,
    se      = pred_net$se.fit,
    prob    = plogis(linpred),
    lower   = plogis(linpred - 1.96 * se),
    upper   = plogis(linpred + 1.96 * se)
  )

ggplot(newdat_net, aes(x = Do_you_use_the_net, y = prob, group = Survey_Group)) +
  geom_point(position = position_dodge(width = 0.2), size = 3) +
  geom_errorbar(aes(ymin = lower, ymax = upper),
                width = 0.1,
                position = position_dodge(width = 0.2)) +
  geom_line(position = position_dodge(width = 0.2)) +
  facet_wrap(~ Survey_Group) +
  labs(
    x = "Do you use the net?",
    y = "Predicted probability of FINAL_MALARIA_NUM1 = 1",
    title = "Malaria positivity vs. net use, by survey group"
  ) +
  theme_minimal()




# 4.7.22 Classify covariate roles for GEE ----

#Variable                           	Type
#Department_code	             Cluster/Identifier
#Municipality_code             	Cluster/Identifier
#Locality_code                 	Cluster/Identifier
#Survey_Number(6-17)	            Identifier
#Household_ID                  	Cluster
#Date_of_the_survey            	time/adjustment variables
#Individual_ID	                  Identifier
#Survey_Group                  	Predictor
#Transmission_level            	Predictor
#Participant_unique_identifier	        cluster variable/Identifier
#Survey_number_Participant_identifier	cluster variable/Identifier
#Visit_to_healthcenter	          Predictor
#Date_of_sample_collection	      time/adjustment variables
#Diagnosis_date	                time/adjustment variables
#Fever_on_day_of_visit         	Predictor
#Own_a_mosquito_net	            Predictor
#SEX	                            Predictor
#Age	                            Predictor
#FINAL_MALARIA_WTH_SPP	          Outcome
#FINAL_MALARIA	                  Outcome
#Fever_in_past_2wks            	Predictor
#Fever_perceived_as_malaria	    Predictor
#Self_medication_taken	          Predictor
#Medication_taken	              Predictor
#Days_medicn_taken	              Predictor
#Net_treated_with_insecticide   	Predictor
#Do_you_use_the_net	            Predictor


# 4.7.23 Construct the GEE analysis dataset ----

# 4.7.24 Inspect malaria, age and sex distributions ----

describe(mergeData2[c("FINAL_MALARIA_NUM1","SEX","Age")])

frq(mergeData2[c("FINAL_MALARIA_NUM1","SEX","Age")])

# 4.7.25 Encode transmission categories ----

library(dplyr)

library(stringr)


mergeData2 <- mergeData2 %>%
  
  mutate(
    
    
    TL_num = suppressWarnings(as.integer(str_trim(as.character(Transmission_level)))),
    
    
    
    Transmission_level_code = dplyr::case_when(
      TL_num == 1L ~ 0L,
      
      TL_num == 2L ~ 1L,
      
      TL_num == 3L ~ 2L,
      TRUE         ~ NA_integer_
    )
  ) %>%
  select(-TL_num)  

table(mergeData2$Transmission_level_code)

# 4.7.26 Encode the study-arm allocation ----
table(mergeData2$Survey_Group)

library(dplyr)
library(stringr)

mergeData2 <- mergeData2 %>%
  
  mutate(
    SG_num = suppressWarnings(as.integer(str_trim(as.character(Survey_Group)))),
    
    Survey_Group_code = case_when(
      SG_num == 1L ~ 0L,
      
      SG_num == 2L ~ 1L,
      TRUE         ~ NA_integer_
    )
  ) %>%
  select(-SG_num) 
# drop helper

table(mergeData2$Survey_Group_code)

# 4.7.27 Select variables for GEE estimation ----

CRT_GEE <- subset(mergeData2,select=c("Survey_Group_code","Survey_Number(6-17)",	"Transmission_level_code", "Participant_unique_identifier",
                                      "Survey_number_Participant_identifier","Visit_to_healthcenter", "Locality_code","Fever_on_day_of_visit","Own_a_mosquito_net",	"SEX","Age_group","FINAL_MALARIA_WTH_SPP"	
                                      ,"FINAL_MALARIA_NUM1", "Fever_in_past_2wks", "Fever_perceived_as_malaria","Self_medication_taken","Medication_taken",
                                      "Days_medicn_taken","Net_treated_with_insecticide","Do_you_use_the_net","Date_of_the_survey"),drop=FALSE)               	

# 4.7.28 Describe the selected analysis dataset ----




head(CRT_GEE) 	        
describe(CRT_GEE) 	
frq(CRT_GEE$Visit_to_healthcenter)  






# 4.7.29 Inspect missing values in model variables ----



describe(CRT_GEE)

table(CRT_GEE$Transmission_level_code)




# 4.7.30 Convert the outcome and predictors to model types ----
CRT_GEE2 <- CRT_GEE %>%
  mutate(
    # Outcome: force to numeric 0/1 (anything else -> NA)
    FINAL_MALARIA_NUM1 = case_when(
      FINAL_MALARIA_NUM1%in% c(1, "1", "POSITIVE", "Positive", "YES", "Yes", TRUE) ~ 1,
      FINAL_MALARIA_NUM1 %in% c(0, "0", "NEGATIVE", "Negative", "NO", "No", FALSE) ~ 0,
      TRUE ~ NA_real_
    ),
    # ID should be factor with no NA
    Locality_code=as.factor(Locality_code),
    Participant_unique_identifier = as.factor(Participant_unique_identifier),
    # Predictors: factors / numeric as appropriate
    Survey_Group_code = as.factor(Survey_Group_code),
    Fever_on_day_of_visit = as.factor(Fever_on_day_of_visit),
    SEX = as.factor(SEX),
    Age_group = as.factor(Age_group),
    Transmission_level_code = as.factor(Transmission_level_code),
    Fever_in_past_2wks = as.factor(Fever_in_past_2wks),
    Fever_perceived_as_malaria = as.factor(Fever_perceived_as_malaria),
    Do_you_use_the_net = as.factor(Do_you_use_the_net),
  ) %>%
  # Drop rows that will crash GEE (NA in y or id)
  filter(!is.na(FINAL_MALARIA_NUM1), !is.na(Participant_unique_identifier))

summary(CRT_GEE2)  

#

# 4.7.31 Validate outcome frequencies across derived datasets ----
# CHECK FINAL_MALARIA_NUM1 IN mergeData2 AND CRT_GEE2
# Counts rows, non-missing values, positives, negatives, missing,
# and percentages where possible

library(dplyr)

# 4.7.32 Define the malaria-outcome validation function ----

check_final_malaria_num <- function(data, dataset_name) {
  
  if (!"FINAL_MALARIA_NUM1" %in% names(data)) {
    stop(paste("FINAL_MALARIA_NUM1 not found in", dataset_name))
  }
  
  data %>%
    summarise(
      Dataset = dataset_name,
      Total_rows = n(),
      Non_missing = sum(!is.na(FINAL_MALARIA_NUM1)),
      Positive_1 = sum(FINAL_MALARIA_NUM1 == 1, na.rm = TRUE),
      Negative_0 = sum(FINAL_MALARIA_NUM1 == 0, na.rm = TRUE),
      Missing = sum(is.na(FINAL_MALARIA_NUM1)),
      Positive_percent = round(100 * Positive_1 / Non_missing, 1),
      Negative_percent = round(100 * Negative_0 / Non_missing, 1),
      Missing_percent = round(100 * Missing / Total_rows, 1)
    )
}

# 4.7.33 Compare the merged and GEE analysis datasets ----

final_malaria_check <- bind_rows(
  check_final_malaria_num(mergeData2, "mergeData2"),
  check_final_malaria_num(CRT_GEE2, "CRT_GEE2")
)

print(final_malaria_check)

# 4.7.34 Tabulate the merged-dataset outcome ----

cat("\nFrequency table: mergeData2 FINAL_MALARIA_NUM1\n")
print(table(mergeData2$FINAL_MALARIA_NUM1, useNA = "ifany"))

# 4.7.35 Tabulate the GEE-dataset outcome ----

cat("\nFrequency table: CRT_GEE2 FINAL_MALARIA_NUM1\n")
print(table(CRT_GEE2$FINAL_MALARIA_NUM1, useNA = "ifany"))

# 4.7.36 Report malaria outcomes by intervention arm ----

if ("Survey_Group_code" %in% names(CRT_GEE2)) {
  cat("\nCRT_GEE2 positives by Survey_Group_code\n")
  
  print(
    CRT_GEE2 %>%
      group_by(Survey_Group_code) %>%
      summarise(
        Total_rows = n(),
        Positive_1 = sum(FINAL_MALARIA_NUM1 == 1, na.rm = TRUE),
        Negative_0 = sum(FINAL_MALARIA_NUM1 == 0, na.rm = TRUE),
        Missing = sum(is.na(FINAL_MALARIA_NUM1)),
        Positive_percent = round(100 * Positive_1 / sum(!is.na(FINAL_MALARIA_NUM1)), 1),
        .groups = "drop"
      )
  )
}



































# 4.8 Demographic and transmission-stratified analyses ----
# 4.8.1 Export model records and prepare sex-specific summaries ----
write.csv(CRT_GEE2, file.choose(new = TRUE), row.names = FALSE)
# SEX AND RELATION TO MALARIA INFECTION# 
write.csv(CRT_GEE2, "CRT_GEE2.csv", row.names = FALSE)

getwd()
normalizePath("CRT_GEE2.csv")
library(dplyr)
library(tidyr)
library(stringr)

# 4.8.2 Harmonise sex and malaria classifications ----
# Prep: harmonize variables
dat <- mergeData2 %>%
  mutate(
    Survey_Group = as.character(Survey_Group),  # "1"=Control, "2"=Intervention
    
    # Sex labels: 0=Male, 1=Female; anything else -> Unknown
    SEX_lab = case_when(
      str_to_lower(as.character(SEX)) %in% c("0","male","m") ~ "Male",
      str_to_lower(as.character(SEX)) %in% c("1","female","f") ~ "Female",
      TRUE ~ "Unknown"
    ),
    
    # Final malaria (no species): derive from NUM if present; else from text
    FINAL_MAL_STR = str_to_lower(str_trim(as.character(FINAL_MALARIA_NUM1))),
    FinalMal_cat = case_when(
      suppressWarnings(as.numeric(FINAL_MALARIA_NUM1)) == 1 ~ "Positive",
      suppressWarnings(as.numeric(FINAL_MALARIA_NUM1)) == 0 ~ "Negative",
      FINAL_MAL_STR %in% c("positive","pos","yes","1")     ~ "Positive",
      FINAL_MAL_STR %in% c("negative","neg","no","0")      ~ "Negative",
      TRUE                                                 ~ "Missing"
    )
  )

# 4.8.3 Tabulate malaria status by sex ----
Table_Sex_FinalMal_Overall <- dat %>%
  count(SEX_lab, FinalMal_cat, name = "n") %>%
  pivot_wider(names_from = FinalMal_cat, values_from = n, values_fill = 0) %>%
  mutate(`Total n` = Positive + Negative + Missing) %>%
  arrange(SEX_lab)

cat("\n=== Sex × Final malaria (overall counts) ===\n")
print(Table_Sex_FinalMal_Overall, row.names = FALSE)

# 4.8.4 Count malaria-positive observations by sex and arm ----
# 2A) By arm: MALARIA POSITIVES (counts) by Sex
Sex_Pos_ByArm <- dat %>%
  filter(Survey_Group %in% c("1","2"), FinalMal_cat == "Positive") %>%
  count(SEX_lab, Survey_Group, name = "n") %>%
  pivot_wider(names_from = Survey_Group, values_from = n, values_fill = 0) %>%
  rename(Control = `1`, Intervention = `2`) %>%
  mutate(Total = Control + Intervention) %>%
  arrange(SEX_lab)

# Add overall row
Sex_Pos_OverallRow <- Sex_Pos_ByArm %>%
  summarise(across(c(Control, Intervention, Total), sum)) %>%
  mutate(SEX_lab = "Total")

Table_Sex_Pos_ByArm <- bind_rows(Sex_Pos_ByArm, Sex_Pos_OverallRow) %>%
  select(Sex = SEX_lab, Control, Intervention, Total)

cat("\n=== Malaria positives by Sex and arm (counts) ===\n")
print(Table_Sex_Pos_ByArm, row.names = FALSE)

# 4.8.5 Calculate malaria positivity by sex and arm ----
# 2B) By arm: PREVALENCE by Sex (n/N, %)
# Denominators per Sex × arm
den <- dat %>%
  filter(Survey_Group %in% c("1","2")) %>%
  count(SEX_lab, Survey_Group, name = "N")

# Numerators (positives) per Sex × arm
num <- dat %>%
  filter(Survey_Group %in% c("1","2"), FinalMal_cat == "Positive") %>%
  count(SEX_lab, Survey_Group, name = "n")

# Join & format cells
prev_long <- den %>%
  left_join(num, by = c("SEX_lab","Survey_Group")) %>%
  mutate(n = tidyr::replace_na(n, 0L),
         pct = ifelse(N > 0, 100 * n / N, NA_real_),
         cell = sprintf("%s/%s (%.2f%%)", format(n, big.mark=","), format(N, big.mark=","), pct))

# Wide table with Control / Intervention columns
prev_wide <- prev_long %>%
  select(SEX_lab, Survey_Group, cell) %>%
  pivot_wider(names_from = Survey_Group, values_from = cell, values_fill = "0/0 (NA)") %>%
  rename(`Control: n/N (%)` = `1`, `Intervention: n/N (%)` = `2`) %>%
  arrange(SEX_lab)

# Overall column per sex
overall_sex <- den %>%
  group_by(SEX_lab) %>% summarise(N = sum(N), .groups = "drop") %>%
  left_join(num %>% group_by(SEX_lab) %>% summarise(n = sum(n), .groups = "drop"), by = "SEX_lab") %>%
  mutate(n = tidyr::replace_na(n, 0L),
         pct = ifelse(N > 0, 100 * n / N, NA_real_),
         Overall = sprintf("%s/%s (%.2f%%)", format(n, big.mark=","), format(N, big.mark=","), pct)) %>%
  select(SEX_lab, Overall)

Table_Sex_FinalMal_Prev <- prev_wide %>%
  left_join(overall_sex, by = "SEX_lab") %>%
  rename(Sex = SEX_lab)

# Add total row across sexes
den_c  <- den %>% filter(Survey_Group=="1") %>% summarise(N=sum(N)) %>% pull(N)
den_i  <- den %>% filter(Survey_Group=="2") %>% summarise(N=sum(N)) %>% pull(N)
num_c  <- num %>% filter(Survey_Group=="1") %>% summarise(n=sum(n)) %>% pull(n)
num_i  <- num %>% filter(Survey_Group=="2") %>% summarise(n=sum(n)) %>% pull(n)
den_all <- sum(den_c, den_i, na.rm=TRUE)
num_all <- sum(num_c, num_i, na.rm=TRUE)

Table_Sex_FinalMal_Prev <- bind_rows(
  Table_Sex_FinalMal_Prev,
  tibble(
    Sex = "Total",
    `Control: n/N (%)`      = sprintf("%s/%s (%.2f%%)", format(num_c, big.mark=","), format(den_c, big.mark=","), 100*num_c/den_c),
    `Intervention: n/N (%)` = sprintf("%s/%s (%.2f%%)", format(num_i, big.mark=","), format(den_i, big.mark=","), 100*num_i/den_i),
    Overall                  = sprintf("%s/%s (%.2f%%)", format(num_all, big.mark=","), format(den_all, big.mark=","), 100*num_all/den_all)
  )
)

cat("\n=== Malaria prevalence by Sex and arm (n/N, %) ===\n")
print(Table_Sex_FinalMal_Prev, row.names = FALSE)




# 4.8.6 Tabulate malaria status by age group ----



library(dplyr)
library(tidyr)
library(stringr)

# 4.8.7 Create age-band and malaria-status variables ----
dat <- mergeData2 %>%
  mutate(
    Survey_Group = as.character(Survey_Group),   # "1"=Control, "2"=Intervention
    
    # Normalize Age_Group into 3 bins + explicit Missing
    Age_chr = as.character(Age_group),
    Age_std = str_to_lower(str_trim(Age_chr)),
    Age_std = str_replace_all(Age_std, "[–—-]", "-"),   # unify dash types
    
    Age_cat3 = case_when(
      
      Age_std %in% c("<5","<5y","<5yr","under 5","0-4","0-4y","0-4yr")     ~ "<5y",
      Age_std %in% c("5-14","5-14y","5 to 14","5–14","5–14y")              ~ "5–14y",
      Age_std %in% c("15+","15 plus","15 and above",">=15","15-","15-99")  ~ "15+",
      TRUE ~ "Missing age"
    ),
    Age_cat3 = factor(Age_cat3, levels = c("<5y","5–14y","15+","Missing age")),
    
    # Final malaria category (binary, keep Missing)
    FINAL_MAL_STR = str_to_lower(str_trim(as.character(FINAL_MALARIA_NUM1))),
    FinalMal_cat = case_when(
      !is.na(FINAL_MALARIA_NUM1) & FINAL_MALARIA_NUM1 == 1 ~ "Positive",
      !is.na(FINAL_MALARIA_NUM1) & FINAL_MALARIA_NUM1 == 0 ~ "Negative",
      FINAL_MAL_STR %in% c("positive","pos","yes","1")   ~ "Positive",
      FINAL_MAL_STR %in% c("negative","neg","no","0")    ~ "Negative",
      TRUE                                               ~ "Missing"
    ),
    FINAL_MALARIA_NUM1 = suppressWarnings(as.numeric(FINAL_MALARIA_NUM1))
  )

# Use only Control/Intervention groups (keep Missing age)
dat_age <- dat %>% filter(Survey_Group %in% c("1","2"))

final_levels <- c("Positive","Negative","Missing","Total")

# 4.8.8 Cross-tabulate age group and malaria status ----
Tab_Final_by_Age <- dat_age %>%
  count(Age_cat3, FinalMal_cat, Survey_Group, name = "n") %>%
  complete(Age_cat3, FinalMal_cat, Survey_Group = c("1","2"), fill = list(n = 0)) %>%
  pivot_wider(names_from = Survey_Group, values_from = n, values_fill = 0) %>%
  rename(Control = `1`, Intervention = `2`) %>%
  mutate(Total = Control + Intervention)

age_totals_A <- Tab_Final_by_Age %>%
  group_by(Age_cat3) %>%
  summarise(Control = sum(Control), Intervention = sum(Intervention),
            Total = sum(Total), .groups = "drop") %>%
  mutate(FinalMal_cat = "Total")

Tab_Final_by_Age <- bind_rows(Tab_Final_by_Age, age_totals_A) %>%
  mutate(FinalMal_cat = factor(FinalMal_cat, levels = final_levels)) %>%
  arrange(Age_cat3, FinalMal_cat)

cat("\n=== A) Final malaria (no species) by Age band and Survey_Group (counts) ===\n")
print(Tab_Final_by_Age, row.names = FALSE)

# 4.8.9 Summarise malaria-positive observations by age ----
Tab_Pos_by_Age <- dat_age %>%
  filter(FINAL_MALARIA_NUM1 == 1) %>%
  count(Age_cat3, Survey_Group, name = "n") %>%
  complete(Age_cat3, Survey_Group = c("1","2"), fill = list(n = 0)) %>%
  pivot_wider(names_from = Survey_Group, values_from = n, values_fill = 0) %>%
  rename(Control = `1`, Intervention = `2`) %>%
  mutate(Total = Control + Intervention) %>%
  arrange(Age_cat3)

overall_pos <- Tab_Pos_by_Age %>%
  summarise(Age_cat3 = "Total",
            Control = sum(Control), Intervention = sum(Intervention),
            Total = sum(Total))

Tab_Pos_by_Age <- bind_rows(Tab_Pos_by_Age, overall_pos)

cat("\n=== B) Malaria positives by Age band and Survey_Group (counts) ===\n")
print(Tab_Pos_by_Age, row.names = FALSE)

# 4.8.10 Calculate positivity proportions by age group ----
Age_den <- dat_age %>%
  count(Age_cat3, Survey_Group, name = "N") %>%
  complete(Age_cat3, Survey_Group = c("1","2"), fill = list(N = 0))

Age_num <- dat_age %>%
  filter(FINAL_MALARIA_NUM1 == 1) %>%
  count(Age_cat3, Survey_Group, name = "n") %>%
  complete(Age_cat3, Survey_Group = c("1","2"), fill = list(n = 0))

Tab_Prev_by_Age <- Age_den %>%
  left_join(Age_num, by = c("Age_cat3","Survey_Group")) %>%
  mutate(pct = ifelse(N > 0, 100 * n / N, NA_real_),
         cell = sprintf("%s/%s (%.2f%%)",
                        format(n, big.mark=","), format(N, big.mark=","), pct)) %>%
  select(Age_cat3, Survey_Group, cell) %>%
  pivot_wider(names_from = Survey_Group, values_from = cell, values_fill = "0/0 (NA)") %>%
  rename(`Control: n/N (%)` = `1`, `Intervention: n/N (%)` = `2`)

overall_prev <- Age_den %>%
  group_by(Age_cat3) %>% summarise(N = sum(N), .groups = "drop") %>%
  left_join(Age_num %>% group_by(Age_cat3) %>% summarise(n = sum(n), .groups = "drop"),
            by = "Age_cat3") %>%
  mutate(pct = ifelse(N > 0, 100 * n / N, NA_real_),
         Overall = sprintf("%s/%s (%.2f%%)",
                           format(n, big.mark=","), format(N, big.mark=","), pct)) %>%
  select(Age_cat3, Overall)

Tab_Prev_by_Age <- Tab_Prev_by_Age %>%
  left_join(overall_prev, by = "Age_cat3") %>%
  arrange(Age_cat3)

den_ctrl <- Age_den %>% filter(Survey_Group=="1") %>% summarise(N=sum(N)) %>% pull(N)
den_int  <- Age_den %>% filter(Survey_Group=="2") %>% summarise(N=sum(N)) %>% pull(N)
num_ctrl <- Age_num %>% filter(Survey_Group=="1") %>% summarise(n=sum(n)) %>% pull(n)
num_int  <- Age_num %>% filter(Survey_Group=="2") %>% summarise(n=sum(n)) %>% pull(n)
den_all  <- sum(den_ctrl, den_int, na.rm = TRUE)
num_all  <- sum(num_ctrl, num_int, na.rm = TRUE)

row_total <- tibble(
  Age_cat3 = "Total",
  `Control: n/N (%)` = sprintf("%s/%s (%.2f%%)", format(num_ctrl, big.mark=","), format(den_ctrl, big.mark=","), 100*num_ctrl/den_ctrl),
  `Intervention: n/N (%)` = sprintf("%s/%s (%.2f%%)", format(num_int,  big.mark=","), format(den_int,  big.mark=","), 100*num_int/den_int),
  Overall = sprintf("%s/%s (%.2f%%)", format(num_all, big.mark=","), format(den_all, big.mark=","), 100*num_all/den_all)
)

Tab_Prev_by_Age <- bind_rows(Tab_Prev_by_Age, row_total)

cat("\n=== C) Malaria prevalence by Age band and Survey_Group (n/N, %) ===\n")
print(Tab_Prev_by_Age, row.names = FALSE)


# 4.8.11 Estimate age- and sex-specific incidence ----
## Malaria incidence per 1,000 person-years by sex and age

library(dplyr)
library(stringr)
library(tidyr)

# 4.8.12 Prepare tested participant-round records ----

df_core <- mergeData2 %>%
  mutate(
    person_key   = as.character(Participant_unique_identifier),
    Survey_Group = as.character(Survey_Group),
    Survey_Number = suppressWarnings(
      as.integer(str_extract(as.character(`Survey_Number(6-17)`), "\\d+"))
    ),
    malaria_pos = case_when(
      FINAL_MALARIA_NUM1 %in% c(1L, 1, "1") ~ 1L,
      FINAL_MALARIA_NUM1 %in% c(0L, 0, "0") ~ 0L,
      TRUE                                 ~ NA_integer_
    )
  ) %>%
  filter(
    !is.na(person_key),
    !is.na(Survey_Number),
    Survey_Number >= 6,
    Survey_Number <= 17
  )

person_round <- df_core %>%
  group_by(Survey_Group, person_key, Survey_Number) %>%
  summarise(
    any_pos = as.integer(any(malaria_pos == 1L, na.rm = TRUE)),
    tested  = as.integer(any(!is.na(malaria_pos))),
    .groups = "drop"
  ) %>%
  filter(tested == 1)

# 4.8.13 Attach sex and age information to person-round records ----

person_info <- mergeData2 %>%
  mutate(
    person_key   = as.character(Participant_unique_identifier),
    Survey_Group = as.character(Survey_Group),
    
    ## Sex label
    SEX_lab = case_when(
      str_to_lower(as.character(SEX)) %in% c("0","male","m")   ~ "Male",
      str_to_lower(as.character(SEX)) %in% c("1","female","f") ~ "Female",
      TRUE                                                     ~ "Unknown"
    ),
    
    ## Age groups: <5y, 5–14y, 15+, Missing
    Age_chr = as.character(Age_group),
    Age_std = str_to_lower(str_trim(Age_chr)),
    Age_std = str_replace_all(Age_std, "[–—-]", "-"),
    Age_cat3 = case_when(
      Age_std %in% c("<5","<5y","<5yr","under 5","0-4","0-4y","0-4yr")     ~ "<5y",
      Age_std %in% c("5-14","5-14y","5 to 14","5–14","5–14y")              ~ "5–14y",
      Age_std %in% c("15+","15 plus","15 and above",">=15","15-","15-99")  ~ "15+",
      TRUE                                                                 ~ "Missing age"
    )
  ) %>%
  distinct(Survey_Group, person_key, SEX_lab, Age_cat3)

## Attach sex and age to each person-round
person_round2 <- person_round %>%
  left_join(person_info, by = c("Survey_Group","person_key"))

# 4.8.14 Calculate incidence by sex and study arm ----

interval_days <- 14  # bi-weekly interval

inc_by_sex <- person_round2 %>%
  group_by(Survey_Group, SEX_lab) %>%
  summarise(
    n_individuals    = n_distinct(person_key),
    events           = sum(any_pos, na.rm = TRUE),
    n_person_rounds  = n(),
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,
      NA_real_
    ),
    .groups = "drop"
  ) %>%
  mutate(
    Study_arm = recode(Survey_Group, "1" = "Control", "2" = "Intervention")
  ) %>%
  select(Study_arm, Sex = SEX_lab,
         n_individuals, person_time_years, events, inc_per_1000_py)

## Add overall (both arms) row per sex
inc_by_sex_overall <- person_round2 %>%
  group_by(SEX_lab) %>%
  summarise(
    Study_arm        = "Overall",
    n_individuals    = n_distinct(person_key),
    events           = sum(any_pos, na.rm = TRUE),
    n_person_rounds  = n(),
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,
      NA_real_
    ),
    .groups = "drop"
  ) %>%
  rename(Sex = SEX_lab)

inc_by_sex_all <- bind_rows(inc_by_sex, inc_by_sex_overall) %>%
  arrange(Sex, factor(Study_arm, levels = c("Control","Intervention","Overall"))) %>%
  mutate(
    person_time_years = round(person_time_years, 1),
    inc_per_1000_py   = round(inc_per_1000_py, 1)
  )

cat("\n=== Malaria incidence per 1,000 person-years by sex and study arm ===\n")
print(inc_by_sex_all, row.names = FALSE)

# 4.8.15 Calculate incidence by age and study arm ----

inc_by_age <- person_round2 %>%
  group_by(Survey_Group, Age_cat3) %>%
  summarise(
    n_individuals    = n_distinct(person_key),
    events           = sum(any_pos, na.rm = TRUE),
    n_person_rounds  = n(),
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,
      NA_real_
    ),
    .groups = "drop"
  ) %>%
  mutate(
    Study_arm = recode(Survey_Group, "1" = "Control", "2" = "Intervention")
  ) %>%
  select(Study_arm, Age_group = Age_cat3,
         n_individuals, person_time_years, events, inc_per_1000_py)

## Overall across arms, by age group
inc_by_age_overall <- person_round2 %>%
  group_by(Age_cat3) %>%
  summarise(
    Study_arm        = "Overall",
    n_individuals    = n_distinct(person_key),
    events           = sum(any_pos, na.rm = TRUE),
    n_person_rounds  = n(),
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,
      NA_real_
    ),
    .groups = "drop"
  ) %>%
  rename(Age_group = Age_cat3)

inc_by_age_all <- bind_rows(inc_by_age, inc_by_age_overall) %>%
  arrange(Age_group, factor(Study_arm, levels = c("Control","Intervention","Overall"))) %>%
  mutate(
    person_time_years = round(person_time_years, 1),
    inc_per_1000_py   = round(inc_per_1000_py, 1)
  )

cat("\n=== Malaria incidence per 1,000 person-years by age group and study arm ===\n")
print(inc_by_age_all, row.names = FALSE)

# 4.8.16 Organise incidence estimates into reporting tables ----

Table_inc_sex  <- inc_by_sex_all %>%
  select(Sex, Study_arm,
         Individuals = n_individuals,
         `Person-years` = person_time_years,
         `Malaria episodes` = events,
         `Incidence per 1,000 person-years` = inc_per_1000_py)

Table_inc_age  <- inc_by_age_all %>%
  select(`Age group` = Age_group, Study_arm,
         Individuals = n_individuals,
         `Person-years` = person_time_years,
         `Malaria episodes` = events,
         `Incidence per 1,000 person-years` = inc_per_1000_py)

cat("\n\n=== PUBLICATION-READY: Incidence per 1,000 person-years by sex ===\n")
print(Table_inc_sex, row.names = FALSE)

cat("\n\n=== PUBLICATION-READY: Incidence per 1,000 person-years by age group ===\n")
print(Table_inc_age, row.names = FALSE)



# 4.8.17 Restrict publication tables to defined sex and age groups ----



##  - remove Unknown / Missing age
##  - order rows systematically

# 4.8.18 Prepare the sex-specific incidence table ----

# Keep only Female / Male, order: Female then Male, and within each:
# Control, Intervention, Overall
Table_inc_sex_pub <- Table_inc_sex %>%
  dplyr::filter(Sex %in% c("Female", "Male")) %>%
  dplyr::mutate(
    Sex       = factor(Sex, levels = c("Female", "Male")),
    Study_arm = factor(Study_arm,
                       levels = c("Control", "Intervention", "Overall"))
  ) %>%
  dplyr::arrange(Sex, Study_arm)

cat("\n=== Publication-ready: malaria incidence per 1,000 person-years by sex ===\n")
print(Table_inc_sex_pub, row.names = FALSE)


# 4.8.19 Prepare the age-specific incidence table ----

# Drop the "Missing age" category; keep <5y, 5–14y, 15+, plus the Total row
# (rename Total -> All ages for clarity)
Table_inc_age_pub <- Table_inc_age %>%
  dplyr::filter(`Age group` != "Missing age") %>%
  dplyr::mutate(
    `Age group` = dplyr::recode(
      `Age group`,
      "Total" = "All ages",
      .default = `Age group`
    ),
    `Age group` = factor(`Age group`,
                         levels = c("<5y", "5–14y", "15+", "All ages")),
    Study_arm   = factor(Study_arm,
                         levels = c("Control", "Intervention", "Overall"))
  ) %>%
  dplyr::arrange(`Age group`, Study_arm)

cat("\n=== Publication-ready: malaria incidence per 1,000 person-years by age group ===\n")
print(Table_inc_age_pub, row.names = FALSE)



# 4.8.20 Analyse malaria positivity across transmission levels ----

# FINAL_MALARIA_NUM1 ~ Transmission level + Survey group
library(dplyr)
library(tidyr)
library(stringr)

# 4.8.21 Harmonise transmission and outcome variables ----
# Edit `tl_candidates` if your transmission column has a different name
tl_candidates <- c("Transmission_level","transmission_level","TRANS_LEVEL","TransLevel","TL","transmission")
tl_col <- intersect(tl_candidates, names(mergeData2))[1]
stopifnot(length(tl_col) == 1)

dat <- mergeData2 %>%
  mutate(
    # Outcome: 1 = positive, 0 = negative, NA otherwise
    mal_chr = toupper(str_squish(as.character(FINAL_MALARIA_NUM1))),
    y = case_when(
      suppressWarnings(as.numeric(mal_chr)) == 1 ~ 1L,
      suppressWarnings(as.numeric(mal_chr)) == 0 ~ 0L,
      mal_chr %in% c("POS","POSITIVE","YES","1","1.0") ~ 1L,
      mal_chr %in% c("NEG","NEGATIVE","NO","0","0.0")  ~ 0L,
      TRUE ~ NA_integer_
    ),
    # Transmission level: 1/2/3
    tl = factor(.data[[tl_col]], levels = c(1,2,3),
                labels = c("Level 1","Level 2","Level 3")),
    # Survey group: "1"=Control, "2"=Intervention
    grp = factor(as.character(Survey_Group), levels = c("1","2"),
                 labels = c("Control","Intervention"))
  ) %>%
  filter(!is.na(y), !is.na(tl), !is.na(grp)) %>%
  droplevels()

# 4.8.22 Calculate positivity by transmission and arm ----
prev_tbl <- dat %>%
  group_by(tl, grp) %>%
  summarise(n_pos = sum(y == 1L), N = n(), .groups = "drop") %>%
  mutate(pct = 100 * n_pos / N,
         cell = sprintf("%s/%s (%.2f%%)",
                        format(n_pos, big.mark=","), format(N, big.mark=","),
                        pct)) %>%
  select(`Transmission level` = tl, Group = grp, `n/N (%)` = cell) %>%
  pivot_wider(names_from = Group, values_from = `n/N (%)`) %>%
  arrange(`Transmission level`)
print(prev_tbl)

# Optional overall across groups
prev_overall <- dat %>%
  group_by(tl) %>%
  summarise(n_pos = sum(y==1L), N = n(), .groups="drop") %>%
  mutate(Overall = sprintf("%s/%s (%.2f%%)",
                           format(n_pos, big.mark=","), format(N, big.mark=","),
                           100*n_pos/N)) %>%
  select(`Transmission level` = tl, Overall)
print(left_join(prev_tbl, prev_overall, by = "Transmission level"))

# 4.8.23 Perform chi-square and stratified association tests ----
# (a) Within each group: y vs Transmission
by_grp <- lapply(split(dat, dat$grp), function(d) chisq.test(table(d$y, d$tl)))
cat("\nChi-square by group (2×3):\n")
for (g in names(by_grp)) {
  ch <- by_grp[[g]]
  cat(sprintf("  %s: X^2=%.3f, df=%d, p=%.3g\n",
              g, unname(ch$statistic), unname(ch$parameter), ch$p.value))
}

# (b) Cochran–Mantel–Haenszel test (adjusting for group)
# Build a 2 (y) × 3 (tl) × 2 (grp) table
cmh_tab <- with(dat, table(y, tl, grp))
cmh <- mantelhaen.test(cmh_tab)  # common association of y~tl across grp strata
cat(sprintf("\nCMH test (adjusted for group): MH X^2=%.3f, df=%d, p=%.3g\n",
            unname(cmh$statistic), unname(cmh$parameter), cmh$p.value))

# 4.8.24 Fit a transmission-adjusted logistic model ----
fit <- glm(y ~ tl + grp, data = dat, family = binomial())
co  <- coef(summary(fit))
OR  <- exp(co[, "Estimate"])
LCI <- exp(co[, "Estimate"] - 1.96*co[, "Std. Error"])
UCI <- exp(co[, "Estimate"] + 1.96*co[, "Std. Error"])
or_tbl <- data.frame(
  Term   = rownames(co),
  OR     = round(OR, 2),
  CI     = sprintf("%.2f–%.2f", LCI, UCI),
  p      = signif(co[, "Pr(>|z|)"], 3),
  row.names = NULL
)
cat("\nLogistic model (ref: Level 1, Control):\n")
print(or_tbl)

# 4.8.25 Test the transmission-by-arm interaction ----
fit_int <- glm(y ~ tl * grp, data = dat, family = binomial())
lrt <- anova(fit, fit_int, test = "LRT")
cat("\nInteraction LRT (tl*grp):\n"); print(lrt)

# 4.8.26 Transmission-specific incidence: first calculation ----
## Incidence per 1,000 person-years by Transmission level & Study arm

library(dplyr)
library(stringr)

# 4.8.27 Identify the transmission classification field ----
tl_candidates <- c("Transmission_level","transmission_level","TRANS_LEVEL",
                   "TransLevel","TL","transmission")
tl_col <- intersect(tl_candidates, names(mergeData2))[1]
stopifnot(length(tl_col) == 1)

# 4.8.28 Prepare transmission-level incidence records ----
df_inc <- mergeData2 %>%
  mutate(
    person_key    = as.character(Participant_unique_identifier),
    Survey_Group  = as.character(Survey_Group),           # "1"=Control, "2"=Intervention
    
    # Survey round number (6–17)
    Survey_Number = suppressWarnings(
      as.integer(str_extract(as.character(`Survey_Number(6-17)`), "\\d+"))
    ),
    
    # Binary malaria outcome for each record (MALARIA_COMBINED3)
    malaria_pos = case_when(
      MALARIA_COMBINED3 %in% c(1L, 1, "1") ~ 1L,
      MALARIA_COMBINED3 %in% c(0L, 0, "0") ~ 0L,
      TRUE                                 ~ NA_integer_
    ),
    
    # Transmission level as factor (1,2,3 → Low/Medium/High, adjust labels if needed)
    tl = factor(.data[[tl_col]],
                levels = c(1, 2, 3),
                labels = c("Low", "Medium", "High"))
  ) %>%
  # Restrict to valid IDs, rounds, and non-missing tl
  filter(
    !is.na(person_key),
    !is.na(Survey_Number),
    Survey_Number >= 6,
    Survey_Number <= 17,
    !is.na(tl),
    Survey_Group %in% c("1","2")
  )

# 4.8.29 Aggregate person-rounds within transmission strata ----
person_round_tl <- df_inc %>%
  group_by(tl, Survey_Group, person_key, Survey_Number) %>%
  summarise(
    any_pos = as.integer(any(malaria_pos == 1L, na.rm = TRUE)),  # 1 if ≥1 positive in that round
    tested  = as.integer(any(!is.na(malaria_pos))),              # 1 if actually tested
    .groups = "drop"
  ) %>%
  filter(tested == 1)   # keep only rounds where person was tested

# 4.8.30 Estimate incidence by transmission level and arm ----

interval_days <- 14  # bi-weekly follow-up interval

inc_transmission_py <- person_round_tl %>%
  group_by(tl, Survey_Group) %>%
  summarise(
    events            = sum(any_pos, na.rm = TRUE),          # malaria episodes
    n_person_rounds   = n(),                                 # tested person-rounds
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,                     # cases per 1,000 person-years
      NA_real_
    ),
    n_individuals     = n_distinct(person_key),
    .groups = "drop"
  ) %>%
  mutate(
    Study_arm = recode(
      Survey_Group,
      "1" = "Control",
      "2" = "Intervention",
      .default = Survey_Group
    )
  ) %>%
  select(
    `Transmission level` = tl,
    Study_arm,
    Individuals          = n_individuals,
    `Person-years`       = person_time_years,
    `Malaria episodes`   = events,
    `Incidence per 1,000 person-years` = inc_per_1000_py
  ) %>%
  arrange(`Transmission level`, Study_arm)

print(inc_transmission_py)

# 4.8.31 Add pooled transmission-level estimates ----
inc_transmission_overall <- person_round_tl %>%
  group_by(tl) %>%
  summarise(
    events            = sum(any_pos, na.rm = TRUE),
    n_person_rounds   = n(),
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,
      NA_real_
    ),
    n_individuals     = n_distinct(person_key),
    .groups = "drop"
  ) %>%
  mutate(
    Study_arm = "Overall"
  ) %>%
  select(
    `Transmission level` = tl,
    Study_arm,
    Individuals          = n_individuals,
    `Person-years`       = person_time_years,
    `Malaria episodes`   = events,
    `Incidence per 1,000 person-years` = inc_per_1000_py
  )

# Bind arm-specific + overall
inc_transmission_full <- bind_rows(inc_transmission_py, inc_transmission_overall) %>%
  arrange(`Transmission level`, factor(Study_arm, levels = c("Control","Intervention","Overall")))

print(inc_transmission_full)

# 4.8.32 Transmission-specific incidence: second calculation ----
## Incidence per 1,000 person-years by Transmission level & Study arm

library(dplyr)
library(stringr)

# 4.8.33 Identify the original transmission variable ----
tl_candidates <- c("Transmission_level","transmission_level","TRANS_LEVEL",
                   "TransLevel","TL","transmission")
tl_col <- intersect(tl_candidates, names(mergeData2))[1]
stopifnot(length(tl_col) == 1)

# 4.8.34 Rebuild individual-level incidence records ----
df_inc <- mergeData2 %>%
  mutate(
    person_key    = as.character(Participant_unique_identifier),
    Survey_Group  = as.character(Survey_Group),  # "1" = Control, "2" = Intervention
    
    # Survey round number (6–17)
    Survey_Number = suppressWarnings(
      as.integer(str_extract(as.character(`Survey_Number(6-17)`), "\\d+"))
    ),
    
    # Binary malaria outcome for each record
    malaria_pos = case_when(
      MALARIA_COMBINED3 %in% c(1L, 1, "1") ~ 1L,
      MALARIA_COMBINED3 %in% c(0L, 0, "0") ~ 0L,
      TRUE                                 ~ NA_integer_
    ),
    
    # Transmission level as factor (adjust labels if needed)
    tl = factor(.data[[tl_col]],
                levels = c(1, 2, 3),
                labels = c("Low", "Medium", "High"))
  ) %>%
  filter(
    !is.na(person_key),
    !is.na(Survey_Number),
    Survey_Number >= 6, Survey_Number <= 17,
    !is.na(tl),
    Survey_Group %in% c("1","2")
  )

# 4.8.35 Count tested person-rounds by transmission level ----
person_round_tl <- df_inc %>%
  group_by(tl, Survey_Group, person_key, Survey_Number) %>%
  summarise(
    any_pos = as.integer(any(malaria_pos == 1L, na.rm = TRUE)),  # 1 if ≥1 positive that round
    tested  = as.integer(any(!is.na(malaria_pos))),              # 1 if tested that round
    .groups = "drop"
  ) %>%
  filter(tested == 1)

# 4.8.36 Recalculate rates within transmission strata ----
interval_days <- 14  # bi-weekly interval

inc_transmission_py <- person_round_tl %>%
  group_by(tl, Survey_Group) %>%
  summarise(
    events            = sum(any_pos, na.rm = TRUE),
    n_person_rounds   = n(),
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,
      NA_real_
    ),
    n_individuals     = n_distinct(person_key),
    .groups = "drop"
  ) %>%
  mutate(
    Study_arm = dplyr::recode(
      Survey_Group,
      "1" = "Control",
      "2" = "Intervention",
      .default = Survey_Group
    )
  ) %>%
  transmute(
    `Transmission level`              = tl,
    Study_arm,
    Individuals                       = n_individuals,
    `Person-years`                    = person_time_years,
    `Malaria episodes`                = events,
    `Incidence per 1,000 person-years` = inc_per_1000_py
  ) %>%
  arrange(`Transmission level`, Study_arm)

print(inc_transmission_py)

# 4.8.37 Append pooled estimates by transmission stratum ----
inc_transmission_overall <- person_round_tl %>%
  group_by(tl) %>%
  summarise(
    events            = sum(any_pos, na.rm = TRUE),
    n_person_rounds   = n(),
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,
      NA_real_
    ),
    n_individuals     = n_distinct(person_key),
    .groups = "drop"
  ) %>%
  transmute(
    `Transmission level`              = tl,
    Study_arm                         = "Overall",
    Individuals                       = n_individuals,
    `Person-years`                    = person_time_years,
    `Malaria episodes`                = events,
    `Incidence per 1,000 person-years` = inc_per_1000_py
  )

inc_transmission_full <- bind_rows(inc_transmission_py, inc_transmission_overall) %>%
  arrange(`Transmission level`,
          factor(Study_arm, levels = c("Control","Intervention","Overall")))

print(inc_transmission_full)





# 4.9 Exploratory comparisons and intervention incidence models ----
# 4.9.1 Cross-tabulate malaria status by clinical and net-use factors ----
library(scales)
library(dplyr)
library(ggplot2)
#library(janitor)


# Convert necessary variables to factor
mergeData2 <- mergeData2 %>%
  mutate(
    Malaria_Pos = as.factor(FINAL_MALARIA_NUM1),  # or use FINAL_MALARIA_NUM1
    Survey_Group = recode(as.character(Survey_Group), "1" = "Control", "2" = "Intervention"),
    Survey_Group = factor(Survey_Group, levels = c("Control", "Intervention")),
    Fever_in_past_2wks = as.factor(Fever_in_past_2wks),
    Fever_on_day_of_visit = as.factor(Fever_on_day_of_visit),
    Do_you_use_the_net = as.factor(Do_you_use_the_net)
  )

# 4.9.2 Summarise covariate associations by study arm ----
analyze_by_group <- function(varname) {
  cat("\n🔍 Analysis for:", varname, "\n")
  for (grp in levels(mergeData2$Survey_Group)) {
    subset_data <- mergeData2 %>% filter(Survey_Group == grp)
    tbl <- table(subset_data[[varname]], subset_data$Malaria_Pos)
    prop <- prop.table(tbl, margin = 1) * 100
    cat("\nSurvey Group:", grp, "\n")
    print(addmargins(tbl))
    print(round(prop, 1))
    print(chisq.test(tbl))
  }
}

# Analyze relationships
vars <- c("Fever_in_past_2wks", "Fever_on_day_of_visit", "Do_you_use_the_net")
lapply(vars, analyze_by_group)

# 4.9.3 Plot factor-specific malaria proportions ----
# PLOTS: Faceted barplots by Survey_Group
for (var in vars) {
  ggplot(mergeData2, aes_string(x = var, fill = "Malaria_Pos")) +
    geom_bar(position = "fill") +
    facet_wrap(~ Survey_Group) +
    scale_y_continuous(labels = percent_format()) +
    scale_fill_manual(values = c("0" = "#2c7fb8", "1" = "#d95f0e"), name = "Malaria") +
    labs(
      title = paste("Malaria Infection by", var, "and Survey Group"),
      x = var, y = "Proportion of individuals (%)"
    ) +
    theme_minimal(base_size = 14) +
    theme(legend.position = "top") -> p
  
  print(p)
}

# 4.9.4 Crude incidence and Poisson regression: first workflow ----
library(tidyverse)
library(broom)

# 4.9.5 Prepare individual-level case observations ----

df <- mergeData2 %>%
  mutate(
    # Unique person ID
    person_key = as.character(Participant_unique_identifier),
    
    # Group (1 = Control, 2 = Intervention)
    Survey_Group = as.character(Survey_Group),
    
    # Extract round number from Survey_Number(6-17)
    Survey_Number = suppressWarnings(
      as.integer(stringr::str_extract(as.character(`Survey_Number(6-17)`), "\\d+"))
    ),
    
    # Clean malaria outcome from MALARIA_COMBINED3 (0/1/NA)
    malaria_pos = dplyr::case_when(
      MALARIA_COMBINED3 %in% c(1L, 1, "1") ~ 1L,
      MALARIA_COMBINED3 %in% c(0L, 0, "0") ~ 0L,
      TRUE                                 ~ NA_integer_
    )
  ) %>%
  # Keep valid IDs and intervention rounds only
  filter(
    !is.na(person_key),
    !is.na(Survey_Number),
    Survey_Number >= 6,
    Survey_Number <= 17
  )

# 4.9.6 Collapse to one record per person-round ----

person_round <- df %>%
  group_by(Survey_Group, person_key, Survey_Number) %>%
  summarise(
    # 1 if this person had any positive malaria result in that round
    any_pos = as.integer(any(malaria_pos == 1L, na.rm = TRUE)),
    # 1 if they were tested / had a result in that round
    tested  = as.integer(any(!is.na(malaria_pos))),
    .groups = "drop"
  ) %>%
  # keep only rounds where the person was actually tested
  filter(tested == 1)

# 4.9.7 Estimate incidence by intervention arm ----

interval_days <- 14  # bi-weekly interval

incidence_rate_py <- person_round %>%
  group_by(Survey_Group) %>%
  summarise(
    events            = sum(any_pos, na.rm = TRUE),          # malaria cases
    n_person_rounds   = n(),                                 # tested person-rounds
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,                    # cases per 1,000 person-years
      NA_real_
    ),
    .groups = "drop"
  ) %>%
  mutate(
    GroupLabel = dplyr::recode(
      Survey_Group,
      "1" = "Control",
      "2" = "Intervention",
      .default = Survey_Group
    )
  ) %>%
  select(GroupLabel, events, person_time_years, inc_per_1000_py)

print(incidence_rate_py)

# 4.9.8 Fit a Poisson model for the incidence rate ratio ----

# Make sure GroupLabel is a factor with "Control" as reference
incidence_for_model <- incidence_rate_py %>%
  mutate(
    GroupLabel = factor(GroupLabel, levels = c("Control", "Intervention"))
  )

# Fit Poisson regression with log(person-time) as offset
fit_pois <- glm(
  events ~ GroupLabel,
  offset = log(person_time_years),
  family = poisson(link = "log"),
  data   = incidence_for_model
)

# Tidy output: exponentiated coefficients = rate ratios
irr_tidy <- broom::tidy(
  fit_pois,
  exponentiate = TRUE,
  conf.int    = TRUE
)

print(irr_tidy)

# 4.9.9 Extract the incidence rate ratio and confidence limits ----

irr_row <- irr_tidy %>%
  filter(term == "GroupLabelIntervention") %>%
  transmute(
    comparison = "Intervention vs Control",
    IRR        = estimate,
    CI_lower   = conf.low,
    CI_upper   = conf.high,
    p_value    = p.value
  )

print(irr_row)

# 4.9.10 Combine incidence and IRR results ----

incidence_rate_py
irr_row


final_table2 <- incidence_rate_py %>%
  mutate(
    person_time_years = round(person_time_years, 1),
    inc_per_1000_py   = round(inc_per_1000_py, 1),
    IRR     = if_else(GroupLabel == "Intervention", irr_row$IRR, NA_real_),
    CI_lower = if_else(GroupLabel == "Intervention", irr_row$CI_lower, NA_real_),
    CI_upper = if_else(GroupLabel == "Intervention", irr_row$CI_upper, NA_real_),
    p_value  = if_else(GroupLabel == "Intervention", irr_row$p_value, NA_real_)
  )

final_table2


# 4.9.11 Crude incidence and Poisson regression: second workflow ----
library(tidyverse)
library(broom)

# 4.9.12 Prepare survey-level individual observations ----

df <- mergeData2 %>%
  mutate(
    # Unique person ID
    person_key = as.character(Participant_unique_identifier),
    
    # Group (1 = Control, 2 = Intervention)
    Survey_Group = as.character(Survey_Group),
    
    # Extract round number from Survey_Number(6-17)
    Survey_Number = suppressWarnings(
      as.integer(stringr::str_extract(as.character(`Survey_Number(6-17)`), "\\d+"))
    ),
    
    # Clean malaria outcome from MALARIA_COMBINED3 (0/1/NA)
    malaria_pos = dplyr::case_when(
      MALARIA_COMBINED3 %in% c(1L, 1, "1") ~ 1L,
      MALARIA_COMBINED3 %in% c(0L, 0, "0") ~ 0L,
      TRUE                                 ~ NA_integer_
    )
  ) %>%
  # Keep valid IDs and intervention rounds only
  filter(
    !is.na(person_key),
    !is.na(Survey_Number),
    Survey_Number >= 6,
    Survey_Number <= 17
  )

# 4.9.13 Summarise tested participant-rounds ----

person_round <- df %>%
  group_by(Survey_Group, person_key, Survey_Number) %>%
  summarise(
    # 1 if this person had any positive malaria result in that round
    any_pos = as.integer(any(malaria_pos == 1L, na.rm = TRUE)),
    # 1 if they were tested / had a result in that round
    tested  = as.integer(any(!is.na(malaria_pos))),
    .groups = "drop"
  ) %>%
  # keep only rounds where the person was actually tested
  filter(tested == 1)

# 4.9.14 Compute arm-specific and pooled incidence ----

interval_days <- 14  # bi-weekly interval

# 3a) By study arm (Control / Intervention)
incidence_by_group <- person_round %>%
  group_by(Survey_Group) %>%
  summarise(
    events            = sum(any_pos, na.rm = TRUE),     # malaria episodes
    n_person_rounds   = n(),                            # tested person-rounds
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,               # cases per 1,000 person-years
      NA_real_
    ),
    n_individuals     = n_distinct(person_key),         # total people in each arm
    .groups = "drop"
  ) %>%
  mutate(
    GroupLabel = dplyr::recode(
      Survey_Group,
      "1" = "Control",
      "2" = "Intervention",
      .default = Survey_Group
    )
  ) %>%
  select(GroupLabel, n_individuals, events, person_time_years, inc_per_1000_py)

# 3b) Overall (both arms combined)
overall_incidence <- person_round %>%
  summarise(
    GroupLabel        = "Overall",
    events            = sum(any_pos, na.rm = TRUE),
    n_person_rounds   = n(),
    person_time_years = n_person_rounds * interval_days / 365,
    inc_per_1000_py   = if_else(
      person_time_years > 0,
      events / person_time_years * 1000,
      NA_real_
    ),
    n_individuals     = n_distinct(person_key),
    .groups           = "drop"
  ) %>%
  select(GroupLabel, n_individuals, events, person_time_years, inc_per_1000_py)

# 3c) Combine
incidence_rate_py <- bind_rows(incidence_by_group, overall_incidence)

print(incidence_rate_py)
# Columns now: GroupLabel, n_individuals, events, person_time_years, inc_per_1000_py

# 4.9.15 Estimate the crude incidence rate ratio ----

# Use only Control & Intervention for IRR
incidence_for_model <- incidence_rate_py %>%
  filter(GroupLabel %in% c("Control", "Intervention")) %>%
  mutate(
    GroupLabel = factor(GroupLabel, levels = c("Control", "Intervention"))
  )

fit_pois <- glm(
  events ~ GroupLabel,
  offset = log(person_time_years),
  family = poisson(link = "log"),
  data   = incidence_for_model
)

irr_tidy <- broom::tidy(
  fit_pois,
  exponentiate = TRUE,
  conf.int    = TRUE
)

print(irr_tidy)

irr_row <- irr_tidy %>%
  filter(term == "GroupLabelIntervention") %>%
  transmute(
    comparison = "Intervention vs Control",
    IRR        = estimate,
    CI_lower   = conf.low,
    CI_upper   = conf.high,
    p_value    = p.value
  )

print(irr_row)

# 4.9.16 Prepare the final incidence comparison table ----

final_table2 <- incidence_rate_py %>%
  mutate(
    person_time_years = round(person_time_years, 1),
    inc_per_1000_py   = round(inc_per_1000_py, 1),
    IRR      = if_else(GroupLabel == "Intervention", irr_row$IRR, NA_real_),
    CI_lower = if_else(GroupLabel == "Intervention", irr_row$CI_lower, NA_real_),
    CI_upper = if_else(GroupLabel == "Intervention", irr_row$CI_upper, NA_real_),
    p_value  = if_else(GroupLabel == "Intervention", irr_row$p_value, NA_real_)
  )

final_table2





# 4.9.17 Estimate adjusted IRRs using village-clustered Poisson GEE ----
#population-averaged incidence rate ratios for ITN allocation

library(dplyr)
library(lubridate)
library(geepack)

# 4.9.18 Clean dates and construct model predictors ----

CRT_GEE2_clean <- CRT_GEE %>%
  mutate(
    Date_of_the_survey = as.Date(
      parse_date_time(Date_of_the_survey, orders = c("dmy", "mdy", "ymd"))
    ),
    
    FINAL_MALARIA_NUM1 = as.integer(as.character(FINAL_MALARIA_NUM1)),
    
    Locality_code = as.factor(Locality_code),
    Participant_unique_identifier = as.factor(Participant_unique_identifier),
    Survey_Group_code = as.factor(Survey_Group_code),
    Age_group = as.factor(Age_group),
    SEX = as.factor(SEX),
    Transmission_level_code = as.factor(Transmission_level_code)
  )

# 4.9.19 Verify survey-date parsing ----

if (any(is.na(CRT_GEE2_clean$Date_of_the_survey))) {
  stop("ERROR: Some survey dates could not be parsed.")
}

# 4.9.20 Calculate observed intervisit person-time ----

CRT_GEE2_clean <- CRT_GEE2_clean %>%
  arrange(Participant_unique_identifier, Date_of_the_survey) %>%
  group_by(Participant_unique_identifier) %>%
  mutate(
    person_time_days = as.numeric(
      Date_of_the_survey - lag(Date_of_the_survey)
    ),
    person_time_years = person_time_days / 365.25
  ) %>%
  ungroup()

# 4.9.21 Select complete cases required for GEE ----
# This removes rows only if they are missing variables needed
# for the Poisson GEE model.

CRT_GEE2_analysis <- CRT_GEE2_clean %>%
  filter(
    !is.na(FINAL_MALARIA_NUM1),
    !is.na(person_time_years),
    person_time_years > 0,
    !is.na(Locality_code),
    !is.na(Survey_Group_code),
    !is.na(Age_group),
    !is.na(SEX),
    !is.na(Transmission_level_code)
  )

# 4.9.22 Summarise cases and person-time before aggregation ----

CRT_GEE2_analysis %>%
  summarise(
    rows = n(),
    malaria_cases = sum(FINAL_MALARIA_NUM1 == 1, na.rm = TRUE),
    person_years = sum(person_time_years, na.rm = TRUE)
  )

CRT_GEE2_analysis %>%
  group_by(Survey_Group_code) %>%
  summarise(
    rows = n(),
    malaria_cases = sum(FINAL_MALARIA_NUM1 == 1, na.rm = TRUE),
    person_years = sum(person_time_years, na.rm = TRUE),
    .groups = "drop"
  )

# 4.9.23 Aggregate to village and covariate groups ----

CRT_village <- CRT_GEE2_analysis %>%
  group_by(
    Locality_code,
    Survey_Group_code,
    Age_group,
    SEX,
    Transmission_level_code
  ) %>%
  summarise(
    Cases = sum(FINAL_MALARIA_NUM1 == 1, na.rm = TRUE),
    Person_time = sum(person_time_years, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  filter(
    !is.na(Cases),
    !is.na(Person_time),
    Person_time > 0,
    !is.na(Locality_code),
    !is.na(Survey_Group_code),
    !is.na(Age_group),
    !is.na(SEX),
    !is.na(Transmission_level_code)
  ) %>%
  arrange(Locality_code)

# 4.9.24 Validate the village-level model dataset ----

cat("\nTotal cases used in GEE:\n")
print(sum(CRT_village$Cases, na.rm = TRUE))

cat("\nCases by study arm:\n")
print(
  CRT_village %>%
    group_by(Survey_Group_code) %>%
    summarise(
      Cases = sum(Cases, na.rm = TRUE),
      Person_time = sum(Person_time, na.rm = TRUE),
      .groups = "drop"
    )
)

cat("\nMissing values in GEE dataset:\n")
print(
  CRT_village %>%
    summarise(
      missing_cases = sum(is.na(Cases)),
      missing_person_time = sum(is.na(Person_time)),
      missing_locality = sum(is.na(Locality_code)),
      missing_group = sum(is.na(Survey_Group_code)),
      missing_age = sum(is.na(Age_group)),
      missing_sex = sum(is.na(SEX)),
      missing_transmission = sum(is.na(Transmission_level_code))
    )
)

# 4.9.25 Fit the village-clustered Poisson GEE ----

gee_pois <- geeglm(
  Cases ~ Survey_Group_code +
    Age_group +
    SEX +
    Transmission_level_code,
  id = Locality_code,
  data = CRT_village,
  family = poisson(link = "log"),
  offset = log(Person_time),
  corstr = "independence"
)

summary(gee_pois)

# 4.9.26 Format adjusted incidence rate ratios ----

pois_irr_table <- function(model, digits = 2) {
  
  sm <- summary(model)$coefficients
  
  est <- sm[, "Estimate"]
  se  <- sm[, "Std.err"]
  p   <- sm[, "Pr(>|W|)"]
  
  IRR <- exp(est)
  LCL <- exp(est - 1.96 * se)
  UCL <- exp(est + 1.96 * se)
  
  out <- data.frame(
    Predictor = rownames(sm),
    IRR = sprintf(paste0("%.", digits, "f"), IRR),
    CI_95 = sprintf("%.2f–%.2f", LCL, UCL),
    p_value = ifelse(
      p < 0.001,
      "<0.001",
      sprintf("%.3f", p)
    )
  )
  
  out <- out[out$Predictor != "(Intercept)", ]
  rownames(out) <- NULL
  
  return(out)
}

Table_IRR <- pois_irr_table(gee_pois)

print(Table_IRR)



# 4.9.27 Describe incidence using observed follow-up intervals ----
# Actual time between participant survey visits

library(dplyr)
library(lubridate)
library(stringr)

# 4.9.28 Prepare participant-level incidence input ----

incidence_data <- CRT_GEE %>%
  mutate(
    Participant_unique_identifier =
      as.character(Participant_unique_identifier),
    
    Survey_Group_code =
      as.character(Survey_Group_code),
    
    Survey_Number = suppressWarnings(
      as.integer(
        str_extract(
          as.character(`Survey_Number(6-17)`),
          "\\d+"
        )
      )
    ),
    
    Date_of_the_survey = as.Date(
      parse_date_time(
        as.character(Date_of_the_survey),
        orders = c("dmy", "mdy", "ymd")
      )
    ),
    
    FINAL_MALARIA_NUM1 =
      as.integer(as.character(FINAL_MALARIA_NUM1)),
    
    `Study arm` = case_when(
      Survey_Group_code == "0" ~ "Control",
      Survey_Group_code == "1" ~ "Intervention",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(
    Survey_Number >= 6,
    Survey_Number <= 17,
    !is.na(Participant_unique_identifier),
    Participant_unique_identifier != "",
    !is.na(`Study arm`),
    !is.na(Date_of_the_survey),
    !is.na(FINAL_MALARIA_NUM1)
  )

# 4.9.29 Collapse observations within participant and survey ----

person_round <- incidence_data %>%
  group_by(
    `Study arm`,
    Participant_unique_identifier,
    Survey_Number
  ) %>%
  summarise(
    Date_of_the_survey = min(Date_of_the_survey),
    
    malaria_event = as.integer(
      any(FINAL_MALARIA_NUM1 == 1, na.rm = TRUE)
    ),
    
    .groups = "drop"
  )

# 4.9.30 Calculate actual time between survey visits ----

person_round <- person_round %>%
  arrange(
    `Study arm`,
    Participant_unique_identifier,
    Date_of_the_survey
  ) %>%
  group_by(
    `Study arm`,
    Participant_unique_identifier
  ) %>%
  mutate(
    previous_date = lag(Date_of_the_survey),
    
    interval_days = as.numeric(
      Date_of_the_survey - previous_date
    )
  ) %>%
  ungroup()

# 4.9.31 Audit malaria episode counts ----

person_round %>%
  group_by(`Study arm`) %>%
  summarise(
    malaria_episodes = sum(malaria_event, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  print()

person_round %>%
  summarise(
    total_malaria_episodes =
      sum(malaria_event, na.rm = TRUE)
  ) %>%
  print()

# Expected:
# Control = 246
# Intervention = 112
# Overall = 358

# 4.9.32 Assign exposure time to each observation ----
#
# The first observed intervention survey has no preceding date.
# Assign 14 days to that first survey interval so that Survey 6
# events are retained. Subsequent rounds use actual intervals.

person_round_time <- person_round %>%
  group_by(
    `Study arm`,
    Participant_unique_identifier
  ) %>%
  mutate(
    interval_days = if_else(
      is.na(interval_days),
      14,
      interval_days
    )
  ) %>%
  ungroup() %>%
  filter(
    interval_days > 0
  )

# 4.9.33 Summarise incidence by randomised arm ----

study_arm_summary <- person_round_time %>%
  group_by(`Study arm`) %>%
  summarise(
    `Participants number` =
      n_distinct(Participant_unique_identifier),
    
    `Malaria episodes` =
      sum(malaria_event, na.rm = TRUE),
    
    `Person-years of follow-up` =
      sum(interval_days, na.rm = TRUE) / 365.25,
    
    `Incidence per 1,000 person-years` =
      `Malaria episodes` /
      `Person-years of follow-up` * 1000,
    
    .groups = "drop"
  ) %>%
  mutate(
    `Person-years of follow-up` =
      round(`Person-years of follow-up`, 1),
    
    `Incidence per 1,000 person-years` =
      round(`Incidence per 1,000 person-years`, 1)
  )

# 4.9.34 Assemble combined-arm incidence table ----
# Study arms + Overall

final_incidence_table <- bind_rows(
  study_arm_summary,
  total_incidence_summary
) %>%
  select(
    `Study arm`,
    `Participants number`,
    `Malaria episodes`,
    `Person-years of follow-up`,
    `Incidence per 1,000 person-years`
  )

print(final_incidence_table, n = Inf)

View(final_incidence_table)

print(total_incidence_summary)
View(total_incidence_summary)







print(study_arm_summary, n = Inf)
view(study_arm_summary)

# 4.9.35 Validate total episode counts ----

study_arm_summary %>%
  summarise(
    total_episodes = sum(`Malaria episodes`)
  ) %>%
  print()

view(study_arm_summary)


# 4.9.36 Inspect final malaria outcome frequencies ----
table(CRT_GEE$FINAL_MALARIA_NUM1, useNA = "ifany")


table(mergeData2$FINAL_MALARIA_NUM1, useNA = "ifany")

CRT_GEE2$FINAL_MALARIA_NUM1


library(dplyr)

table(mergeData2$FINAL_MALARIA_NUM1, useNA = "ifany")




# 4.10 Round-specific crude intervention comparisons ----
# 4.10.1 Visualise intervention-to-control IRRs by survey round ----
# Intervention vs Control
# IRR < 1 = protective

# 4.10.2 Select survey-round incidence data ----
if (exists("rate_table_common")) {
  irr_source <- rate_table_common
} else if (exists("counts_person_rate_py_12_fixed")) {
  irr_source <- counts_person_rate_py_12_fixed
} else {
  stop("No corrected rate table found. Expected rate_table_common or counts_person_rate_py_12_fixed.")
}

# 4.10.3 Compute arm-specific rates and crude IRRs ----
irr_dat <- irr_source %>%
  mutate(
    GroupLabel = as.character(GroupLabel),
    Round_Index = as.numeric(Round_Index)
  ) %>%
  filter(
    Round_Index >= 1,
    Round_Index <= 12,
    GroupLabel %in% c("Control", "Intervention")
  ) %>%
  select(
    GroupLabel,
    Round_Index,
    positives_indiv,
    person_time_years
  ) %>%
  pivot_wider(
    names_from = GroupLabel,
    values_from = c(positives_indiv, person_time_years),
    names_sep = "_"
  ) %>%
  arrange(Round_Index) %>%
  mutate(
    # Incidence rates
    rate_control = positives_indiv_Control / person_time_years_Control,
    rate_intervention = positives_indiv_Intervention / person_time_years_Intervention,
    
    # Crude incidence rate ratio: Intervention vs Control
    IRR = rate_intervention / rate_control,
    
    # Standard error of log(IRR)
    # If any round has zero cases, use a small continuity correction
    cases_control_cc = if_else(positives_indiv_Control == 0, 0.5, positives_indiv_Control),
    cases_intervention_cc = if_else(positives_indiv_Intervention == 0, 0.5, positives_indiv_Intervention),
    
    se_log_irr = sqrt((1 / cases_intervention_cc) + (1 / cases_control_cc)),
    
    lcl = exp(log(IRR) - 1.96 * se_log_irr),
    ucl = exp(log(IRR) + 1.96 * se_log_irr),
    
    Direction = if_else(IRR < 1, "Protective", "No effect/Harmful")
  )

# 4.10.4 Check IRR and confidence-limit calculations ----
print(
  irr_dat %>%
    select(
      Round_Index,
      positives_indiv_Control,
      person_time_years_Control,
      positives_indiv_Intervention,
      person_time_years_Intervention,
      IRR,
      lcl,
      ucl,
      Direction
    ),
  n = Inf
)

# 4.10.5 Plot crude IRRs by survey round ----
p_irr_rounds <- ggplot(
  irr_dat,
  aes(
    x = Round_Index,
    y = IRR,
    ymin = lcl,
    ymax = ucl,
    colour = Direction
  )
) +
  geom_hline(
    yintercept = 1,
    linetype = "dashed",
    colour = "grey50"
  ) +
  geom_errorbar(
    width = 0.12,
    linewidth = 0.7,
    colour = "#1f77b4"
  ) +
  geom_point(size = 3) +
  scale_y_log10(
    breaks = c(0.03, 0.10, 0.30, 1.00, 3.00),
    labels = c("0.03", "0.10", "0.30", "1.00", "3.00")
  ) +
  scale_x_continuous(
    breaks = 1:12,
    limits = c(1, 12)
  ) +
  scale_colour_manual(
    values = c(
      "Protective" = "#2ca02c",
      "No effect/Harmful" = "#d62728"
    )
  ) +
  labs(
    x = "Intervention round",
    y = "IRR (log scale)",
    colour = "Direction"
  ) +
  theme_classic(base_size = 13) +
  theme(
    legend.position = "right",
    panel.grid = element_blank()
  )

print(p_irr_rounds)


library(dplyr)
library(tidyr)
library(ggplot2)

# 4.10.6 Repeat round-specific IRR calculation and plotting ----
# IRR = Intervention incidence rate / Control incidence rate
# IRR < 1 = lower malaria incidence in intervention arm

# 4.10.7 Select the incidence-rate dataset ----

if (exists("rate_table_common")) {
  irr_source <- rate_table_common
} else if (exists("counts_person_rate_py_12_fixed")) {
  irr_source <- counts_person_rate_py_12_fixed
} else {
  stop("No corrected rate table found. Expected 'rate_table_common' or 'counts_person_rate_py_12_fixed'.")
}

# 4.10.8 Calculate crude IRRs and Poisson-style intervals ----
# Required columns:
# GroupLabel, Round_Index, positives_indiv, person_time_years

irr_dat <- irr_source %>%
  mutate(
    GroupLabel = as.character(GroupLabel),
    Round_Index = as.numeric(Round_Index)
  ) %>%
  filter(
    Round_Index >= 1,
    Round_Index <= 12,
    GroupLabel %in% c("Control", "Intervention")
  ) %>%
  select(
    GroupLabel,
    Round_Index,
    positives_indiv,
    person_time_years
  ) %>%
  pivot_wider(
    names_from = GroupLabel,
    values_from = c(positives_indiv, person_time_years),
    names_sep = "_"
  ) %>%
  arrange(Round_Index) %>%
  mutate(
    # Incidence rates per person-year
    rate_control = positives_indiv_Control / person_time_years_Control,
    rate_intervention = positives_indiv_Intervention / person_time_years_Intervention,
    
    # Incidence rate ratio: Intervention vs Control
    IRR = rate_intervention / rate_control,
    
    # Continuity correction for CI calculation if any round has zero cases
    cases_control_cc = if_else(positives_indiv_Control == 0, 0.5, positives_indiv_Control),
    cases_intervention_cc = if_else(positives_indiv_Intervention == 0, 0.5, positives_indiv_Intervention),
    
    # Standard error and 95% CI on log scale
    se_log_irr = sqrt((1 / cases_intervention_cc) + (1 / cases_control_cc)),
    lcl = exp(log(IRR) - 1.96 * se_log_irr),
    ucl = exp(log(IRR) + 1.96 * se_log_irr),
    
    # Direction based on point estimate
    Direction = if_else(IRR < 1, "Protective", "No effect/Harmful")
  )

# 4.10.9 Review derived IRR estimates ----

print(
  irr_dat %>%
    select(
      Round_Index,
      positives_indiv_Control,
      person_time_years_Control,
      positives_indiv_Intervention,
      person_time_years_Intervention,
      rate_control,
      rate_intervention,
      IRR,
      lcl,
      ucl,
      Direction
    ),
  n = Inf
)

# 4.10.10 Plot IRRs on a logarithmic scale ----

p_irr_rounds <- ggplot(
  irr_dat,
  aes(
    x = Round_Index,
    y = IRR,
    ymin = lcl,
    ymax = ucl,
    colour = Direction
  )
) +
  geom_hline(
    yintercept = 1,
    linetype = "dashed",
    colour = "grey50"
  ) +
  geom_errorbar(
    width = 0.12,
    linewidth = 0.7,
    colour = "#1f77b4"
  ) +
  geom_point(size = 3) +
  scale_y_log10(
    breaks = c(0.03, 0.10, 0.30, 1.00, 3.00),
    labels = c("0.03", "0.10", "0.30", "1.00", "3.00")
  ) +
  scale_x_continuous(
    breaks = 1:12,
    limits = c(1, 12)
  ) +
  scale_colour_manual(
    values = c(
      "Protective" = "#2ca02c",
      "No effect/Harmful" = "#d62728"
    )
  ) +
  labs(
    x = "Intervention round",
    y = "Incidence rate ratio: Intervention vs Control",
    colour = "Direction"
  ) +
  theme_classic(base_size = 13) +
  theme(
    legend.position = "right",
    panel.grid = element_blank(),
    plot.title = element_text(face = "bold")
  )

print(p_irr_rounds)


# 4.10.11 Summarise adjusted GEE case counts ----
sum(CRT_village$Cases, na.rm = TRUE)

CRT_village %>%
  group_by(Survey_Group_code) %>%
  summarise(
    Cases = sum(Cases, na.rm = TRUE),
    Person_time = sum(Person_time, na.rm = TRUE),
    .groups = "drop"
  )
# 4.10.12 Audit exclusions due to missing covariates ----

dat_ps <- dat_survey %>%
  mutate(
    complete_for_gee = !is.na(Study_arm) &
      !is.na(Age_group_label) &
      !is.na(Sex_label) &
      !is.na(Transmission_label) &
      !is.na(Locality_code)
  )

dat_ps %>%
  filter(malaria_survey == 1) %>%
  summarise(
    positive_person_survey_records = n(),
    complete_for_gee = sum(complete_for_gee),
    excluded_from_gee = sum(!complete_for_gee)
  )

dat_ps %>%
  filter(malaria_survey == 1, !complete_for_gee) %>%
  summarise(
    missing_study_arm = sum(is.na(Study_arm)),
    missing_age = sum(is.na(Age_group_label)),
    missing_sex = sum(is.na(Sex_label)),
    missing_transmission = sum(is.na(Transmission_label)),
    missing_locality = sum(is.na(Locality_code))
  )
# 4.11 Descriptive temporal and seasonal incidence ----


# 4.11.1 Calculate survey-round incidence time series ----
# Time series of malaria positivity rate per 1,000 person-years
# Surveys 6–17 | X-axis: 1=S6, 2=S7, …, 12=S17
# Includes observed point at Survey 6

library(dplyr)
library(ggplot2)
library(lubridate)



# 4.11.2 Prepare dates, outcomes and allocation for plotting ----
df <- mergeData2 %>%
  mutate(
    Date_of_the_survey = as.Date(Date_of_the_survey, format = "%m/%d/%Y"),
    Survey_Group = factor(Survey_Group,
                          levels = c("Control", "Intervention")),
    positive = as.integer(FINAL_MALARIA_NUM1 == 1)
  ) %>%
  filter(Survey_Number %in% 6:17) %>%
  droplevels()

# 4.11.3 Calculate survey dates and follow-up intervals ----
survey_dates <- df %>%
  group_by(Survey_Number) %>%
  summarise(
    survey_date = median(Date_of_the_survey, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(Survey_Number) %>%
  mutate(
    interval_days  = as.numeric(survey_date - lag(survey_date)),
    interval_years = interval_days / 365.25
  ) %>%
  # Use S6→S7 interval for Survey 6 so S6 can be plotted
  mutate(
    interval_years = ifelse(is.na(interval_years),
                            lead(interval_years),
                            interval_years)
  )

# 4.11.4 Aggregate survey-round cases and persons ----
ts_dat <- df %>%
  group_by(Survey_Group, Survey_Number) %>%
  summarise(
    persons = n(),
    cases   = sum(positive, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(survey_dates, by = "Survey_Number")

# 4.11.5 Calculate incidence per 1,000 person-years ----
ts_dat <- ts_dat %>%
  mutate(
    person_years = persons * interval_years,
    rate_1000py  = (cases / person_years) * 1000,
    survey_index = Survey_Number - 5   # 1=S6, 2=S7, …, 12=S17
  )

# 4.11.6 Calculate Poisson confidence intervals ----
ts_dat <- ts_dat %>%
  rowwise() %>%
  mutate(
    lcl_1000py = (qchisq(0.025, 2 * cases) / (2 * person_years)) * 1000,
    ucl_1000py = (qchisq(0.975, 2 * (cases + 1)) / (2 * person_years)) * 1000
  ) %>%
  ungroup()

# 4.11.7 Plot observed incidence with LOESS trends ----
p <- ggplot(
  ts_dat,
  aes(
    x = survey_index,
    y = rate_1000py,
    color = Survey_Group,
    shape = Survey_Group
  )
) +
  geom_point(size = 2.6) +
  geom_errorbar(
    aes(ymin = lcl_1000py, ymax = ucl_1000py),
    width = 0.15,
    linewidth = 0.6
  ) +
  geom_smooth(
    method = "loess",
    se = FALSE,
    linewidth = 1.2
  ) +
  scale_x_continuous(
    breaks = 1:12,
    labels = 1:12
  ) +
  scale_color_manual(
    values = c("Control" = "red", "Intervention" = "blue")
  ) +
  scale_shape_manual(
    values = c("Control" = 16, "Intervention" = 17)
  ) +
  labs(
    x = "Survey index",
    y = "Malaria incidence rate (per 1,000 person-years)",
    color = "Arm",
    shape = "Arm",
    title = "Malaria incidence rate per 1,000 person-years by survey round",
    subtitle = "Points = observed rates; bars = 95% CI; line = LOESS trend"
  ) +
  theme_classic(base_size = 14) +
  theme(
    legend.position = "bottom",
    plot.title = element_text(face = "bold")
  )
print(p)

# 4.11.8 Monthly incidence estimates for May through October ----
## Monthly malaria incidence (per 1,000 person-years)
## Plot restricted to May–October


# 4.11.9 Prepare monthly analysis variables ----

library(dplyr)
library(ggplot2)
library(lubridate)

dat <- df %>%
  mutate(
    Date_of_the_survey = parse_date_time(
      Date_of_the_survey,
      orders = c("mdy", "dmy", "ymd")
    ),
    
    month_num = month(Date_of_the_survey),
    
    Survey_Group1 = case_when(
      as.character(Survey_Group) %in% c("1", "Control", "0") ~ "Control",
      as.character(Survey_Group) %in% c("2", "Intervention", "1") ~ "Intervention",
      TRUE ~ NA_character_
    ) %>% factor(levels = c("Control", "Intervention")),
    
    case = as.integer(FINAL_MALARIA_NUM1 == 1)
  ) %>%
  filter(
    !is.na(Date_of_the_survey),
    !is.na(Survey_Group1)
  )

# 4.11.10 Check representation of both study arms ----
table(dat$Survey_Group1)

# 4.11.11 Aggregate malaria incidence by month ----
monthly_incidence <- dat %>%
  group_by(Survey_Group, month_num) %>%
  summarise(
    cases = sum(case, na.rm = TRUE),
    person_months = n(),
    person_years = person_months / 12,
    incidence_1000py = if_else(
      person_years > 0,
      (cases / person_years) * 1000,
      NA_real_
    ),
    .groups = "drop"
  )

# 4.11.12 Select May–October calendar months ----
may_oct_incidence <- monthly_incidence %>%
  filter(month_num %in% 5:10) %>%
  mutate(
    month_lbl = factor(
      month.abb[month_num],
      levels = month.abb[5:10],
      ordered = TRUE
    )
  )

# 4.11.13 Plot monthly incidence by study arm ----
p <- ggplot(
  may_oct_incidence,
  aes(
    x = month_lbl,
    y = incidence_1000py,
    color = Survey_Group,
    group = Survey_Group
  )
) +
  geom_line(linewidth = 1.4) +
  geom_point(size = 3) +
  scale_color_manual(
    values = c("Control" = "#d62728",
               "Intervention" = "#1f77b4")
  ) +
  scale_y_continuous(
    limits = c(0, NA),
    expand = expansion(mult = c(0, 0.05))
  ) +
  labs(
    title = "Monthly malaria incidence (Intervention period)",
    subtitle = "Rates per 1,000 person-years, pooled across years",
    x = "Month (May–October)",
    y = "Malaria incidence (per 1,000 person-years)",
    color = "Study arm"
  ) +
  theme_classic(base_size = 14)

print(p)





# 4.11.14 Seasonal incidence by calendar month ----
## Seasonal monthly malaria incidence during the intervention period
## Rates per 1,000 person-years aggregated by calendar month
## Purpose: show seasonal pattern (calendar month), distinct from
## survey-round trends shown elsewhere

library(dplyr)
library(ggplot2)
library(lubridate)

# 4.11.15 Prepare the seasonal incidence dataset ----
dat <- df %>%
  mutate(
    Date_of_the_survey = parse_date_time(
      Date_of_the_survey,
      orders = c("mdy", "dmy", "ymd")
    ),
    
    # Restrict to intervention phase if survey-round variable exists
    survey_round = suppressWarnings(as.numeric(`Survey_Number(6-17)`)),
    
    month_num = month(Date_of_the_survey),
    month_lbl = factor(month.abb[month_num], levels = month.abb[5:10], ordered = TRUE),
    
    Study_arm = case_when(
      as.character(Survey_Group) %in% c("0", "1", "Control") ~ "Control",
      as.character(Survey_Group) %in% c("2", "Intervention") ~ "Intervention",
      TRUE ~ NA_character_
    ) %>% factor(levels = c("Control", "Intervention")),
    
    malaria_case = as.integer(FINAL_MALARIA_NUM1 == 1)
  ) %>%
  filter(
    !is.na(Date_of_the_survey),
    !is.na(Study_arm),
    month_num %in% 5:10
  )

# If survey rounds are coded separately, keep intervention rounds only
if ("Survey_Number(6-17)" %in% names(df)) {
  dat <- dat %>%
    filter(!is.na(survey_round))
}

# Check arm balance
table(dat$Study_arm, useNA = "ifany")

# 4.11.16 Compute calendar-month incidence rates ----
# Assumption:
# each observation contributes approximately one person-survey record.
# Person-time is approximated as person-months / 12 to obtain person-years.

monthly_incidence <- dat %>%
  group_by(Study_arm, month_num, month_lbl) %>%
  summarise(
    cases = sum(malaria_case, na.rm = TRUE),
    person_observations = n(),
    person_years = person_observations / 12,
    incidence_1000py = if_else(
      person_years > 0,
      (cases / person_years) * 1000,
      NA_real_
    ),
    .groups = "drop"
  )

print(monthly_incidence)

# 4.11.17 Plot seasonal patterns of malaria incidence ----
p <- ggplot(
  monthly_incidence,
  aes(
    x = month_lbl,
    y = incidence_1000py,
    color = Study_arm,
    group = Study_arm
  )
) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 3) +
  scale_color_manual(
    values = c("Control" = "#d62728", "Intervention" = "#1f77b4")
  ) +
  scale_y_continuous(
    limits = c(0, NA),
    expand = expansion(mult = c(0, 0.05))
  ) +
  labs(
    title = "Seasonal pattern of monthly malaria incidence during the intervention period",
    subtitle = "Rates per 1,000 person-years aggregated by calendar month (May–October)",
    x = "Calendar month",
    y = "Malaria incidence (per 1,000 person-years)",
    color = "Study arm",
    caption = "This figure summarizes seasonal variation by calendar month and is distinct from survey-round analyses."
  ) +
  theme_classic(base_size = 14) +
  theme(
    legend.position = "right",
    plot.title = element_text(face = "bold"),
    plot.caption = element_text(size = 10)
  )

print(p)




















# 5.1 Kaplan–Meier estimation of time to first malaria infection ----
# 5.1.1 Set up first-event survival analyses ----
# Time to first malaria infection
# Kaplan–Meier cumulative incidence (1 − S(t))

# 5.1.2 Load survival analysis packages ----
library(dplyr)
library(survival)
library(survminer)
library(ggplot2)




# 5.1.3 Prepare Kaplan–Meier data from merged survey observations ----
# Kaplan-Meier: time to first malaria infection after S6
# Using mergeData2 directly

# 5.1.4 Load packages used for the Kaplan–Meier workflow ----
library(dplyr)
library(lubridate)
library(survival)
library(survminer)
library(ggplot2)

# 5.1.5 Parse dates and harmonise malaria outcome and arm ----

mergeData2 <- mergeData2 %>%
  mutate(
    Date_of_the_survey = as.Date(
      parse_date_time(
        as.character(Date_of_the_survey),
        orders = c("dmy", "mdy", "ymd", "dmy HMS", "mdy HMS", "ymd HMS")
      )
    ),
    
    FINAL_MALARIA_NUM1 = as.integer(as.character(FINAL_MALARIA_NUM1)),
    
    survey_round = as.numeric(as.character(`Survey_Number(6-17)`)),
    
    Survey_Group_code = as.character(Survey_Group_code),
    
    Survey_Group = case_when(
      Survey_Group_code %in% c("0", "Control", "control") ~ "Control",
      Survey_Group_code %in% c("1", "Intervention", "intervention") ~ "Intervention",
      TRUE ~ NA_character_
    ),
    
    Survey_Group = factor(
      Survey_Group,
      levels = c("Control", "Intervention")
    )
  )

# 5.1.6 Check date conversion ----

str(mergeData2$Date_of_the_survey)

if (any(is.na(mergeData2$Date_of_the_survey))) {
  stop("ERROR: Some Date_of_the_survey values could not be converted to Date.")
}

# 5.1.7 Restrict to surveys S6–S17 ----

postS6 <- mergeData2 %>%
  filter(
    survey_round %in% 6:17,
    !is.na(Participant_unique_identifier),
    !is.na(Date_of_the_survey),
    !is.na(FINAL_MALARIA_NUM1),
    !is.na(Survey_Group)
  )

# 5.1.8 Identify the earliest recorded baseline visit ----
# Baseline = first available record from S6 onwards

baseline <- postS6 %>%
  arrange(Participant_unique_identifier, Date_of_the_survey) %>%
  group_by(Participant_unique_identifier) %>%
  slice(1) %>%
  ungroup() %>%
  transmute(
    Participant_unique_identifier,
    date_enrol = as.Date(Date_of_the_survey),
    Survey_Group
  )

# 5.1.9 Find the first positive test following baseline ----

first_pos <- postS6 %>%
  inner_join(
    baseline %>%
      select(Participant_unique_identifier, date_enrol),
    by = "Participant_unique_identifier"
  ) %>%
  filter(
    FINAL_MALARIA_NUM1 == 1L,
    Date_of_the_survey > date_enrol
  ) %>%
  group_by(Participant_unique_identifier) %>%
  summarise(
    first_inf_date = as.Date(min(Date_of_the_survey, na.rm = TRUE)),
    .groups = "drop"
  )

# 5.1.10 Determine last-observed follow-up dates ----

last_fu <- postS6 %>%
  group_by(Participant_unique_identifier) %>%
  summarise(
    last_date = as.Date(max(Date_of_the_survey, na.rm = TRUE)),
    .groups = "drop"
  )

# 5.1.11 Construct the first-event survival dataset ----

survival_data <- baseline %>%
  left_join(first_pos, by = "Participant_unique_identifier") %>%
  left_join(last_fu, by = "Participant_unique_identifier") %>%
  mutate(
    date_enrol = as.Date(date_enrol),
    first_inf_date = as.Date(first_inf_date),
    last_date = as.Date(last_date),
    
    event = if_else(!is.na(first_inf_date), 1L, 0L),
    
    end_date = coalesce(first_inf_date, last_date),
    end_date = as.Date(end_date),
    
    follow_up_days = as.numeric(end_date - date_enrol)
  ) %>%
  filter(
    !is.na(follow_up_days),
    follow_up_days >= 0,
    !is.na(Survey_Group)
  )

# 5.1.12 Audit censoring and follow-up duration ----

str(survival_data$date_enrol)
str(survival_data$end_date)
summary(survival_data$follow_up_days)

table(survival_data$Survey_Group, survival_data$event)

# 5.1.13 Fit Kaplan–Meier survival curves ----

dat_plot <- survival_data %>%
  mutate(
    time = follow_up_days,
    event_window = event
  )

km_fit <- survfit(
  Surv(time, event_window) ~ Survey_Group,
  data = dat_plot
)

# 5.1.14 Plot cumulative incidence and numbers at risk ----

p_km <- ggsurvplot(
  km_fit,
  data = dat_plot,
  fun = "event",
  conf.int = TRUE,
  censor = TRUE,
  risk.table = TRUE,
  xlim = c(0, 100),
  break.time.by = 20,
  ylim = c(0, 0.025),
  xlab = "Days since baseline",
  ylab = "Cumulative probability of first malaria infection",
  legend.title = "Study arm",
  legend.labs = c("Control", "Intervention"),
  palette = c("red", "blue"),
  ggtheme = theme_classic(base_size = 14),
  risk.table.height = 0.25
)

print(p_km)












# 5.1.15 Extract daily cumulative incidence through day 100 ----

days_wanted <- 0:100

km_summary_daily <- summary(
  km_fit,
  times = days_wanted,
  extend = TRUE
)

km_table_daily <- data.frame(
  time_days = km_summary_daily$time,
  arm = km_summary_daily$strata,
  n_risk = km_summary_daily$n.risk,
  n_event = km_summary_daily$n.event,
  survival_probability = km_summary_daily$surv,
  survival_lower_95CI = km_summary_daily$lower,
  survival_upper_95CI = km_summary_daily$upper
) %>%
  mutate(
    arm = gsub("Survey_Group_code=", "", arm),
    cumulative_infection_probability = 1 - survival_probability,
    cumulative_infection_lower_95CI = 1 - survival_upper_95CI,
    cumulative_infection_upper_95CI = 1 - survival_lower_95CI,
    cumulative_infection_percent = cumulative_infection_probability * 100,
    cumulative_infection_lower_95CI_percent = cumulative_infection_lower_95CI * 100,
    cumulative_infection_upper_95CI_percent = cumulative_infection_upper_95CI * 100
  ) %>%
  select(
    time_days,
    arm,
    n_risk,
    n_event,
    cumulative_infection_probability,
    cumulative_infection_lower_95CI,
    cumulative_infection_upper_95CI,
    cumulative_infection_percent,
    cumulative_infection_lower_95CI_percent,
    cumulative_infection_upper_95CI_percent
  )

print(km_table_daily)

write.csv(km_table_daily, "KM_cumulative_infection_by_day.csv", row.names = FALSE)

getwd()













# 5.2 Cox regression and first-event survival-data workflows ----
# 5.2.1 Construct an initial Cox first-event analysis ----
# Correct Baseline Definition

# 5.2.2 Load Cox analysis packages ----
suppressPackageStartupMessages({
  library(dplyr)
  library(survival)
})

# 5.2.3 Prepare survey dates and infection status ----
# 1️⃣ Clean dataset

CRT_GEE2 <- CRT_GEE %>%
  mutate(
    Date_of_the_survey = as.Date(Date_of_the_survey, "%m/%d/%Y"),
    infection_status   = as.numeric(FINAL_MALARIA_NUM1)
  )

postS6 <- CRT_GEE2 %>%
  filter(`Survey_Number(6-17)` %in% 6:17)

# 5.2.4 Identify baseline visits ----
# 2️⃣ Baseline = first record ≥ S6

baseline <- postS6 %>%
  arrange(Participant_unique_identifier, Date_of_the_survey) %>%
  group_by(Participant_unique_identifier) %>%
  slice(1) %>%
  ungroup()

# 5.2.5 Exclude participants positive at baseline ----
# 3️⃣ Remove those already infected at baseline

baseline <- baseline %>%
  filter(infection_status == 0)

# 5.2.6 Identify first post-baseline malaria infection ----
# 4️⃣ First infection after baseline

first_pos <- postS6 %>%
  inner_join(baseline %>%
               select(Participant_unique_identifier, Date_of_the_survey),
             by = "Participant_unique_identifier",
             suffix = c("", "_base")) %>%
  filter(
    infection_status == 1,
    Date_of_the_survey > Date_of_the_survey_base
  ) %>%
  group_by(Participant_unique_identifier) %>%
  summarise(first_inf_date = min(Date_of_the_survey),
            .groups = "drop")

# 5.2.7 Identify last recorded follow-up ----
# 5️⃣ Last follow-up

last_fu <- postS6 %>%
  inner_join(baseline %>%
               select(Participant_unique_identifier, Date_of_the_survey),
             by = "Participant_unique_identifier",
             suffix = c("", "_base")) %>%
  group_by(Participant_unique_identifier) %>%
  summarise(last_date = max(Date_of_the_survey),
            .groups = "drop")

# 5.2.8 Construct survival records with covariates ----
# 6️⃣ Build survival dataset

survival_data_full <- baseline %>%
  select(
    Participant_unique_identifier,
    date_enrol = Date_of_the_survey,
    Survey_Group_code,
    Age_group,
    Transmission_level_code,
    SEX,
    Locality_code
  ) %>%
  left_join(first_pos, by = "Participant_unique_identifier") %>%
  left_join(last_fu, by = "Participant_unique_identifier") %>%
  mutate(
    event = if_else(!is.na(first_inf_date), 1L, 0L),
    end_date = if_else(event == 1L, first_inf_date, last_date),
    follow_up_days = as.numeric(end_date - date_enrol)
  ) %>%
  filter(!is.na(follow_up_days), follow_up_days >= 0)

# 5.2.9 Audit sample size and event counts ----
# 7️⃣ Check dataset

cat("N participants:", nrow(survival_data_full), "\n")
cat("Events:", sum(survival_data_full$event), "\n")

# 5.2.10 Apply administrative censoring at day 100 ----
# 8️⃣ Administrative censoring 0–100 days

dat_100 <- survival_data_full %>%
  mutate(
    time100  = pmin(follow_up_days, 100),
    event100 = ifelse(follow_up_days <= 100 & event == 1, 1L, 0L)
  )

cat("Events within 100 days:", sum(dat_100$event100), "\n")

# 5.2.11 Fit the multivariable Cox model ----
# 9️⃣ Fit Cox model

cox_model <- coxph(
  Surv(time100, event100) ~
    Survey_Group_code +
    Age_group +
    Transmission_level_code +
    SEX +
    cluster(Locality_code),
  data = dat_100,
  ties = "efron"
)

summary(cox_model)


# 5.2.12 Inspect factor levels and refit the Cox model ----

suppressPackageStartupMessages({
  library(dplyr)
  library(survival)
  library(broom)
})

# 5.2.13 Check input data availability ----
# 1️⃣ Ensure required dataset exists


if(!exists("dat_100")){
  stop("dat_100 not found. Build survival dataset first.")
}
dat_100
# Ensure factors are correctly defined
dat_100 <- dat_100 %>%
  mutate(
    Survey_Group_code = factor(Survey_Group_code,
                               levels = c("Control","Intervention")),
    
    Age_group = factor(Age_group,
                       levels = c("<5", "5-14y", "15+")),
    
    Transmission_level_code = factor(Transmission_level_code,
                                     levels = c("Low","Medium","High")),
    SEX = factor(SEX),
    Locality_code = factor(Locality_code, ,
                           levels = c("Male","Female")))

# 5.2.14 Recode covariates and reference categories ----

dat_100 <- dat_100 %>%
  mutate(
    # Study arm: Control is reference
    Survey_Group_code = factor(
      Survey_Group_code,
      levels = c(0, 1),
      labels = c("Control", "Intervention")
    ),
    
    # Age group: <5 years is reference
    Age_group = factor(
      Age_group,
      levels = c("<5", "5–14y", "15+"),
      labels = c("<5 years", "5–14 years", "≥15 years")
    ),
    
    # Transmission level: Low is reference
    Transmission_level_code = factor(
      Transmission_level_code,
      levels = c(0, 1, 2),
      labels = c("Low", "Medium", "High")
    ),
    
    # Sex: Male is reference
    SEX = factor(
      SEX,
      levels = c(1, 2),
      labels = c("Male", "Female")
    ),
    
    Locality_code = factor(Locality_code)
  )

# Check the corrected levels
levels(dat_100$Survey_Group_code)
levels(dat_100$Age_group)
levels(dat_100$Transmission_level_code)
levels(dat_100$SEX)

table(dat_100$Survey_Group_code, useNA = "ifany")
table(dat_100$Age_group, useNA = "ifany")
table(dat_100$Transmission_level_code, useNA = "ifany")
table(dat_100$SEX, useNA = "ifany")

# 5.2.15 Refit the multivariable Cox model ----
cox_model <- coxph(
  Surv(time100, event100) ~
    Survey_Group_code +
    Age_group +
    Transmission_level_code +
    SEX +
    cluster(Locality_code),
  data = dat_100,
  ties = "efron"
)

summary(cox_model)
# 5.2.16 Repeat the clustered Cox fit for reporting ----
# 2️⃣ Fit multivariable Cox model (cluster-robust)

cox_model <- coxph(
  Surv(time100, event100) ~
    Survey_Group_code +
    Age_group +
    Transmission_level_code +
    SEX +
    cluster(Locality_code),
  data = dat_100,
  ties = "efron"
)

cat("\n================ COX MODEL RESULTS =================\n")
print(summary(cox_model))

# 5.2.17 Construct a hazard-ratio summary table ----
# 3️⃣ Create formatted Hazard Ratio table

cox_sum <- summary(cox_model)

coef_table <- as.data.frame(cox_sum$coefficients)
ci_table   <- as.data.frame(cox_sum$conf.int)

cox_table <- data.frame(
  Covariate = rownames(coef_table),
  `Hazard Ratio (HR)` = round(ci_table$`exp(coef)`, 2),
  `95% CI Lower` = round(ci_table$`lower .95`, 2),
  `95% CI Upper` = round(ci_table$`upper .95`, 2),
  `p-value` = signif(coef_table$`Pr(>|z|)`, 3),
  row.names = NULL
)

# Clean covariate labels
cox_table$Covariate <- gsub("Survey_Group_code", "Study arm: ", cox_table$Covariate)
cox_table$Covariate <- gsub("Age_group", "Age group: ", cox_table$Covariate)
cox_table$Covariate <- gsub("Transmission_level_code", "Transmission level: ", cox_table$Covariate)
cox_table$Covariate <- gsub("SEX", "Sex: ", cox_table$Covariate)

cat("\n================ FORMATTED COX TABLE =================\n")
print(cox_table)



# 5.2.18 Reconstruct the complete-case Cox analysis dataset ----
# RESTORE dat_100 + CORRECT FACTOR LEVELS + REFIT COX MODEL

library(dplyr)
library(survival)

# 5.2.19 Restore follow-up data from the original cohort ----
# This removes the incorrect factor conversion

dat_100 <- survival_data_full %>%
  mutate(
    time100  = pmin(follow_up_days, 100),
    event100 = ifelse(
      follow_up_days <= 100 & event == 1,
      1L,
      0L
    )
  )

# 5.2.20 Harmonise intervention and adjustment variables ----

dat_100 <- dat_100 %>%
  mutate(
    Survey_Group_code = case_when(
      as.character(Survey_Group_code) %in%
        c("0", "Control", "control") ~ "Control",
      
      as.character(Survey_Group_code) %in%
        c("1", "Intervention", "intervention") ~ "Intervention",
      
      TRUE ~ NA_character_
    ),
    
    Age_group = case_when(
      as.character(Age_group) %in%
        c("<5", "<5 years", "Under 5") ~ "<5 years",
      
      as.character(Age_group) %in%
        c("5-14y", "5–14y", "5-14 years", "5–14 years") ~
        "5–14 years",
      
      as.character(Age_group) %in%
        c("15+", "≥15", "15+ years", "≥15 years") ~
        "≥15 years",
      
      TRUE ~ NA_character_
    ),
    
    Transmission_level_code = case_when(
      as.character(Transmission_level_code) %in%
        c("0", "Low", "low") ~ "Low",
      
      as.character(Transmission_level_code) %in%
        c("1", "Medium", "medium") ~ "Medium",
      
      as.character(Transmission_level_code) %in%
        c("2", "High", "high") ~ "High",
      
      TRUE ~ NA_character_
    ),
    
    SEX = case_when(
      as.character(SEX) %in%
        c("1", "Male", "male", "M", "m") ~ "Male",
      
      as.character(SEX) %in%
        c("2", "Female", "female", "F", "f") ~ "Female",
      
      TRUE ~ NA_character_
    )
  ) %>%
  mutate(
    Survey_Group_code = factor(
      Survey_Group_code,
      levels = c("Control", "Intervention")
    ),
    
    Age_group = factor(
      Age_group,
      levels = c("<5 years", "5–14 years", "≥15 years")
    ),
    
    Transmission_level_code = factor(
      Transmission_level_code,
      levels = c("Low", "Medium", "High")
    ),
    
    SEX = factor(
      SEX,
      levels = c("Male", "Female")
    ),
    
    Locality_code = factor(Locality_code)
  )

# 5.2.21 Check subgroup labels and missing values ----

cat("\nStudy arm:\n")
print(table(dat_100$Survey_Group_code, useNA = "ifany"))

cat("\nAge group:\n")
print(table(dat_100$Age_group, useNA = "ifany"))

cat("\nTransmission level:\n")
print(table(dat_100$Transmission_level_code, useNA = "ifany"))

cat("\nSex:\n")
print(table(dat_100$SEX, useNA = "ifany"))

# 5.2.22 Restrict to model-complete observations ----

dat_100_model <- dat_100 %>%
  filter(
    !is.na(time100),
    !is.na(event100),
    !is.na(Survey_Group_code),
    !is.na(Age_group),
    !is.na(Transmission_level_code),
    !is.na(SEX),
    !is.na(Locality_code)
  )

cat(
  "\nObservations available for Cox model:",
  nrow(dat_100_model),
  "\n"
)

cat(
  "Events available for Cox model:",
  sum(dat_100_model$event100),
  "\n"
)

if (nrow(dat_100_model) == 0) {
  stop(
    "No observations remain. Check the original coding using ",
    "unique(survival_data_full$SEX), ",
    "unique(survival_data_full$Transmission_level_code), and ",
    "unique(survival_data_full$Survey_Group_code)."
  )
}

# 5.2.23 Fit Cox regression on the updated cohort ----

cox_model <- coxph(
  Surv(time100, event100) ~
    Survey_Group_code +
    Age_group +
    Transmission_level_code +
    SEX +
    cluster(Locality_code),
  data = dat_100_model,
  ties = "efron"
)

summary(cox_model)

# Confirm expected model terms
rownames(summary(cox_model)$coefficients)
# 5.2.24 Independent complete-case first-event Cox workflow ----
# Multivariable Cox proportional-hazards model
# Community-clustered robust standard errors

suppressPackageStartupMessages({
  library(dplyr)
  library(survival)
  library(tibble)
})

# 5.2.25 Inspect original demographic and intervention coding ----

cat("\nStudy arm:\n")
print(table(CRT_GEE$Survey_Group_code, useNA = "ifany"))

cat("\nAge group:\n")
print(table(CRT_GEE$Age_group, useNA = "ifany"))

cat("\nTransmission level:\n")
print(table(
  CRT_GEE$Transmission_level_code,
  useNA = "ifany"
))

cat("\nSex:\n")
print(table(CRT_GEE$SEX, useNA = "ifany"))

cat("\nMalaria status:\n")
print(table(
  CRT_GEE$FINAL_MALARIA_NUM1,
  useNA = "ifany"
))


# 5.2.26 Clean dates and derive model covariates ----

CRT_GEE2 <- CRT_GEE %>%
  mutate(
    
    date_character = as.character(Date_of_the_survey),
    
    Date_of_the_survey = coalesce(
      as.Date(date_character, format = "%m/%d/%Y"),
      as.Date(date_character, format = "%Y-%m-%d")
    ),
    
    survey_number = suppressWarnings(
      as.integer(as.character(`Survey_Number(6-17)`))
    ),
    
    infection_status = suppressWarnings(
      as.integer(as.character(FINAL_MALARIA_NUM1))
    ),
    
    arm_raw = trimws(as.character(Survey_Group_code)),
    age_raw = trimws(as.character(Age_group)),
    transmission_raw = trimws(
      as.character(Transmission_level_code)
    ),
    sex_raw = trimws(as.character(SEX))
  ) %>%
  
  mutate(
    
    # Study arm
    Study_arm = case_when(
      arm_raw %in% c("0", "Control") ~ "Control",
      arm_raw %in% c("1", "Intervention") ~ "Intervention",
      TRUE ~ NA_character_
    ),
    
    # Age group
    Age_group_model = case_when(
      age_raw %in% c(
        "1", "<5", "<5y", "<5 years",
        "0-4", "0–4", "Under 5"
      ) ~ "<5 years",
      
      age_raw %in% c(
        "2", "5-14", "5–14",
        "5-14y", "5–14y",
        "5-14 years", "5–14 years"
      ) ~ "5–14 years",
      
      age_raw %in% c(
        "3", "15+", "15+y",
        "15+ years", ">=15", "≥15"
      ) ~ "≥15 years",
      
      TRUE ~ NA_character_
    ),
    
    # Transmission level
    # CORRECT CODING:
    # 0 = Low
    # 1 = Medium
    # 2 = High
    Transmission_level = case_when(
      transmission_raw == "0" ~ "Low",
      transmission_raw == "1" ~ "Medium",
      transmission_raw == "2" ~ "High",
      TRUE ~ NA_character_
    ),
    
    # Sex
    Sex_model = case_when(
      sex_raw %in% c(
        "1", "Male", "MALE", "male", "M"
      ) ~ "Male",
      
      sex_raw %in% c(
        "2", "Female", "FEMALE", "female", "F"
      ) ~ "Female",
      
      TRUE ~ NA_character_
    )
  ) %>%
  
  mutate(
    
    Study_arm = factor(
      Study_arm,
      levels = c(
        "Control",
        "Intervention"
      )
    ),
    
    Age_group_model = factor(
      Age_group_model,
      levels = c(
        "<5 years",
        "5–14 years",
        "≥15 years"
      )
    ),
    
    Transmission_level = factor(
      Transmission_level,
      levels = c(
        "Low",
        "Medium",
        "High"
      )
    ),
    
    Sex_model = factor(
      Sex_model,
      levels = c(
        "Male",
        "Female"
      )
    ),
    
    Locality_code = factor(Locality_code)
  ) %>%
  
  select(-date_character)

# 5.2.27 Identify unrecognised covariate values ----

cat("\nUnrecognised study-arm values:\n")
print(
  CRT_GEE2 %>%
    filter(is.na(Study_arm)) %>%
    count(arm_raw)
)

cat("\nUnrecognised age-group values:\n")
print(
  CRT_GEE2 %>%
    filter(is.na(Age_group_model)) %>%
    count(age_raw)
)

cat("\nUnrecognised transmission-level values:\n")
print(
  CRT_GEE2 %>%
    filter(is.na(Transmission_level)) %>%
    count(transmission_raw)
)

cat("\nSex codes excluded from the model:\n")
print(
  CRT_GEE2 %>%
    filter(is.na(Sex_model)) %>%
    count(sex_raw)
)


# 5.2.28 Select surveys S6–S17 ----

postS6 <- CRT_GEE2 %>%
  filter(
    survey_number %in% 6:17,
    !is.na(Participant_unique_identifier),
    !is.na(Date_of_the_survey),
    infection_status %in% c(0L, 1L)
  )


# 5.2.29 Set the first eligible baseline record ----

baseline <- postS6 %>%
  arrange(
    Participant_unique_identifier,
    Date_of_the_survey,
    survey_number
  ) %>%
  group_by(Participant_unique_identifier) %>%
  slice_head(n = 1) %>%
  ungroup()


# 5.2.30 Exclude participants infected at baseline ----

baseline_negative <- baseline %>%
  filter(infection_status == 0L)

cat(
  "\nParticipants with an observation from S6-S17:",
  n_distinct(postS6$Participant_unique_identifier),
  "\n"
)

cat(
  "Participants negative at baseline:",
  nrow(baseline_negative),
  "\n"
)

cat(
  "Participants excluded as positive at baseline:",
  sum(baseline$infection_status == 1L, na.rm = TRUE),
  "\n"
)


# 5.2.31 Locate the first positive follow-up observation ----
#    after baseline

first_pos <- postS6 %>%
  inner_join(
    baseline_negative %>%
      select(
        Participant_unique_identifier,
        baseline_date = Date_of_the_survey
      ),
    by = "Participant_unique_identifier"
  ) %>%
  filter(
    infection_status == 1L,
    Date_of_the_survey > baseline_date
  ) %>%
  group_by(Participant_unique_identifier) %>%
  summarise(
    first_inf_date = min(Date_of_the_survey),
    .groups = "drop"
  )


# 5.2.32 Identify last observed follow-up ----

last_fu <- postS6 %>%
  inner_join(
    baseline_negative %>%
      select(
        Participant_unique_identifier,
        baseline_date = Date_of_the_survey
      ),
    by = "Participant_unique_identifier"
  ) %>%
  filter(Date_of_the_survey >= baseline_date) %>%
  group_by(Participant_unique_identifier) %>%
  summarise(
    last_date = max(Date_of_the_survey),
    .groups = "drop"
  )


# 5.2.33 Construct the participant-level survival dataset ----

survival_data_full <- baseline_negative %>%
  select(
    Participant_unique_identifier,
    date_enrol = Date_of_the_survey,
    Study_arm,
    Age_group_model,
    Transmission_level,
    Sex_model,
    Locality_code
  ) %>%
  left_join(
    first_pos,
    by = "Participant_unique_identifier"
  ) %>%
  left_join(
    last_fu,
    by = "Participant_unique_identifier"
  ) %>%
  mutate(
    
    event = if_else(
      !is.na(first_inf_date),
      1L,
      0L
    ),
    
    end_date = coalesce(
      first_inf_date,
      last_date
    ),
    
    follow_up_days = as.numeric(
      end_date - date_enrol
    )
  ) %>%
  filter(
    !is.na(follow_up_days),
    follow_up_days >= 0
  )


# 5.2.34 Apply 100-day administrative censoring ----

dat_100 <- survival_data_full %>%
  mutate(
    
    time100 = pmin(
      follow_up_days,
      100
    ),
    
    event100 = if_else(
      event == 1L &
        follow_up_days <= 100,
      1L,
      0L
    )
  )


# 5.2.35 Select complete-case participants for modelling ----

model_dat <- dat_100 %>%
  filter(
    complete.cases(
      time100,
      event100,
      Study_arm,
      Age_group_model,
      Transmission_level,
      Sex_model,
      Locality_code
    )
  ) %>%
  droplevels()


cat("\n====================================\n")
cat("MODEL DATASET\n")
cat("====================================\n")

cat("Participants:", nrow(model_dat), "\n")
cat(
  "First malaria infections within 100 days:",
  sum(model_dat$event100),
  "\n"
)

cat(
  "Communities:",
  n_distinct(model_dat$Locality_code),
  "\n"
)

cat(
  "Participants excluded because of missing covariates:",
  nrow(dat_100) - nrow(model_dat),
  "\n"
)


# 5.2.36 Tabulate events across covariates ----

cat("\nStudy arm distribution:\n")
print(
  model_dat %>%
    count(Study_arm, event100)
)

cat("\nAge-group distribution:\n")
print(
  model_dat %>%
    count(Age_group_model, event100)
)

cat("\nTransmission-level distribution:\n")
print(
  model_dat %>%
    count(Transmission_level, event100)
)

cat("\nSex distribution:\n")
print(
  model_dat %>%
    count(Sex_model, event100)
)


# 5.2.37 Fit village-clustered multivariable Cox regression ----

cox_model <- coxph(
  Surv(time100, event100) ~
    Study_arm +
    Age_group_model +
    Transmission_level +
    Sex_model +
    cluster(Locality_code),
  
  data = model_dat,
  ties = "efron",
  x = TRUE,
  model = TRUE
)

summary(cox_model)


# 5.2.38 Format adjusted hazard ratios and confidence intervals ----

beta <- coef(cox_model)

# Uses cluster-robust covariance matrix
robust_se <- sqrt(diag(vcov(cox_model)))

HR <- exp(beta)

CI_lower <- exp(
  beta - qnorm(0.975) * robust_se
)

CI_upper <- exp(
  beta + qnorm(0.975) * robust_se
)

p_value <- 2 * pnorm(
  abs(beta / robust_se),
  lower.tail = FALSE
)


cox_table <- tibble(
  term = names(beta),
  HR,
  CI_lower,
  CI_upper,
  p_value
) %>%
  mutate(
    
    Covariate = case_when(
      
      term == "Study_armIntervention" ~
        "Study arm: Intervention vs Control",
      
      grepl(
        "^Age_group_model5",
        term
      ) ~
        "Age group: 5–14 vs <5 years",
      
      grepl(
        "^Age_group_model≥15",
        term
      ) ~
        "Age group: ≥15 vs <5 years",
      
      term == "Transmission_levelMedium" ~
        "Transmission level: Medium vs Low",
      
      term == "Transmission_levelHigh" ~
        "Transmission level: High vs Low",
      
      term == "Sex_modelFemale" ~
        "Sex: Female vs Male",
      
      TRUE ~ term
    ),
    
    subgroup_order = case_when(
      term == "Study_armIntervention" ~ 1L,
      
      grepl(
        "^Age_group_model5",
        term
      ) ~ 2L,
      
      grepl(
        "^Age_group_model≥15",
        term
      ) ~ 3L,
      
      term == "Transmission_levelMedium" ~ 4L,
      
      term == "Transmission_levelHigh" ~ 5L,
      
      term == "Sex_modelFemale" ~ 6L,
      
      TRUE ~ 99L
    ),
    
    `Adjusted HR (95% CI)` = sprintf(
      "%.2f (%.2f–%.2f)",
      HR,
      CI_lower,
      CI_upper
    ),
    
    `p-value` = case_when(
      p_value < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", p_value)
    )
  ) %>%
  arrange(subgroup_order) %>%
  select(
    Covariate,
    `Adjusted HR (95% CI)`,
    `p-value`
  )


cat("\n====================================\n")
cat("FINAL COX REGRESSION TABLE\n")
cat("====================================\n")

print(cox_table, n = Inf)





# 5.3 Exploratory recurrent-event and community-level models ----
## Ixcan cRCT – Individual + Community Effects

library(dplyr)
library(survival)
library(lubridate)
library(broom)

# 5.3.1 Prepare longitudinal malaria and ITN observations ----

dat <- mergeData2 %>%
  mutate(
    survey_date = as.Date(Date_of_the_survey, "%m/%d/%Y"),
    infection   = as.integer(FINAL_MALARIA_NUM1 == 1),
    itn_use     = as.integer(Do_you_use_the_net == 1)
  ) %>%
  filter(
    !is.na(survey_date),
    !is.na(Locality_code),
    !is.na(Participant_unique_identifier)
  ) %>%
  arrange(Participant_unique_identifier, survey_date)

# 5.3.2 Identify negative-to-positive transitions ----

dat <- dat %>%
  group_by(Participant_unique_identifier) %>%
  mutate(
    prev_status = lag(infection, default = 0),
    new_event   = if_else(infection == 1 & prev_status == 0, 1, 0)
  ) %>%
  ungroup()

# 5.3.3 Create participant-level counting-process intervals ----

dat_indiv <- dat %>%
  group_by(Participant_unique_identifier) %>%
  mutate(
    tstart = as.numeric(
      lag(survey_date, default = first(survey_date)) -
        first(survey_date)
    ),
    tstop  = as.numeric(
      survey_date - first(survey_date)
    )
  ) %>%
  ungroup() %>%
  filter(tstop > tstart)

# 5.3.4 Fit the participant-clustered recurrent-event Cox model ----
## Andersen–Gill formulation (clustered by participant)

fit_individual <- coxph(
  Surv(tstart, tstop, new_event) ~
    Survey_Group_code +
    Age_group +
    SEX +
    Transmission_level +
    cluster(Participant_unique_identifier),
  data = dat_indiv,
  ties = "efron"
)

# 5.3.5 Calculate lagged village-level net coverage ----

comm_cov <- dat %>%
  group_by(Locality_code, survey_date) %>%
  summarise(
    coverage = mean(itn_use, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(Locality_code, survey_date) %>%
  group_by(Locality_code) %>%
  mutate(
    lag_coverage = lag(coverage, 1)
  ) %>%
  ungroup()

# 5.3.6 Join village coverage to individual records ----

dat_comm <- dat_indiv %>%
  left_join(
    comm_cov,
    by = c("Locality_code", "survey_date")
  ) %>%
  filter(!is.na(lag_coverage))

# 5.3.7 Fit the model for lagged community coverage ----

fit_community <- coxph(
  Surv(tstart, tstop, new_event) ~
    scale(lag_coverage) +
    Age_group +
    SEX +
    Transmission_level +
    cluster(Locality_code),
  data = dat_comm,
  ties = "efron"
)

# 5.3.8 Summarise recurrent-event and village-level estimates ----

extract_results <- function(fit, model_name) {
  tidy(fit, exponentiate = TRUE, conf.int = TRUE) %>%
    transmute(
      Model = model_name,
      Term  = term,
      HR    = round(estimate, 2),
      CI    = paste0("(", round(conf.low, 2), "–", round(conf.high, 2), ")"),
      p     = signif(p.value, 3)
    )
}

results_table <- bind_rows(
  extract_results(fit_individual, "Individual Recurrent Model"),
  extract_results(fit_community, "Community Lagged Model")
)

print(results_table)


# 5.4 Piecewise Cox and Andersen–Gill cohort preparation ----
# 5.4.1 Specify follow-up intervals and comparison workflow ----
#
#
# Follow-up periods:
#     0-30 days
#     30-60 days
#     >60 days
#
# Produces:
#   1. Participant/data audit
#   2. Standalone piecewise first-event Cox
#   3. Global test of time variation for Cox
#   4. Andersen-Gill recurrent-event model
#   5. Global test of time variation for AG
#   6. Side-by-side Cox vs AG comparison
#   7. Event/person-time table
#   8. Internal check proving that Cox values in standalone and
#      comparison sections are EXACTLY the same
#
# IMPORTANT:
# Both Cox and AG are generated from ONE MASTER ANALYTIC COHORT.
#
# Required dataset:
#     CRT_GEE
#


# 5.4.2 Load packages for first-event and recurrent-event analyses ----

suppressPackageStartupMessages({
  library(dplyr)
  library(survival)
})


# 5.4.3 Validate required source fields ----

if (!exists("CRT_GEE")) {
  stop("CRT_GEE is not loaded.")
}


required_vars <- c(
  "Participant_unique_identifier",
  "Date_of_the_survey",
  "Survey_Number(6-17)",
  "FINAL_MALARIA_NUM1",
  "Survey_Group_code",
  "Age_group",
  "Transmission_level_code",
  "SEX",
  "Locality_code"
)


missing_vars <- setdiff(
  required_vars,
  names(CRT_GEE)
)


if (length(missing_vars) > 0) {
  
  stop(
    "Missing required variables: ",
    paste(missing_vars, collapse = ", ")
  )
}


# 5.4.4 Define the study-date parser ----
#
# Trial dates are interpreted as month/day/year.
#
# Example:
# 5/15/2001 = 15 May 2001
#

parse_trial_date <- function(x) {
  
  if (inherits(x, "Date")) {
    return(x)
  }
  
  if (inherits(x, "POSIXt")) {
    return(as.Date(x))
  }
  
  x <- trimws(as.character(x))
  
  
  out <- as.Date(
    x,
    format = "%m/%d/%Y"
  )
  
  
  # Also permit ISO format if present
  missing_date <- is.na(out)
  
  if (any(missing_date)) {
    
    out[missing_date] <- as.Date(
      x[missing_date],
      format = "%Y-%m-%d"
    )
  }
  
  out
}


# 5.4.5 Standardise original surveillance records ----

dat0 <- CRT_GEE %>%
  
  transmute(
    
    id =
      trimws(
        as.character(
          Participant_unique_identifier
        )
      ),
    
    date =
      parse_trial_date(
        Date_of_the_survey
      ),
    
    round =
      suppressWarnings(
        as.numeric(
          as.character(
            `Survey_Number(6-17)`
          )
        )
      ),
    
    malaria =
      suppressWarnings(
        as.numeric(
          as.character(
            FINAL_MALARIA_NUM1
          )
        )
      ),
    
    arm_raw =
      trimws(
        as.character(
          Survey_Group_code
        )
      ),
    
    village_raw =
      trimws(
        as.character(
          Locality_code
        )
      ),
    
    age_raw =
      trimws(
        as.character(
          Age_group
        )
      ),
    
    transmission_raw =
      trimws(
        as.character(
          Transmission_level_code
        )
      ),
    
    sex_raw =
      trimws(
        as.character(
          SEX
        )
      )
  )


cat("\n============================================================\n")
cat("RAW DATA AUDIT\n")
cat("============================================================\n\n")

cat("Raw rows:", nrow(dat0), "\n")

cat(
  "Unique participant IDs:",
  n_distinct(dat0$id),
  "\n"
)


# 5.4.6 Retain eligible survey-round observations ----

dat <- dat0 %>%
  
  filter(
    round %in% 6:17,
    !is.na(id),
    id != "",
    !is.na(date),
    malaria %in% c(0, 1),
    !is.na(village_raw),
    village_raw != ""
  )


# 5.4.7 Recode documented sex categories ----
#
# CURRENT RULE:
#
#   SEX 1 and 2 are retained.
#
#   Blank, 3, 4, NA and all other undocumented values
#   are treated as missing.
#
# IMPORTANT:
# If the original codebook establishes valid meanings for
# codes 3 or 4, modify this section before final publication.
#

dat <- dat %>%
  
  mutate(
    
    sex_clean =
      case_when(
        
        sex_raw == "1" ~ "1",
        
        sex_raw == "2" ~ "2",
        
        TRUE ~ NA_character_
      )
  )


# 5.4.8 Determine village-level treatment allocation ----
#
# Randomization occurred at village level.
#
# Determine the dominant recorded arm within each village.
#

village_arm_map <- dat %>%
  
  filter(
    arm_raw != "",
    !is.na(arm_raw)
  ) %>%
  
  mutate(
    
    arm_standard =
      case_when(
        
        arm_raw %in%
          c(
            "0",
            "Control",
            "control",
            "CONTROL"
          ) ~ "Control",
        
        arm_raw %in%
          c(
            "1",
            "Intervention",
            "intervention",
            "INTERVENTION"
          ) ~ "Intervention",
        
        TRUE ~ NA_character_
      )
  ) %>%
  
  filter(
    !is.na(arm_standard)
  ) %>%
  
  count(
    village_raw,
    arm_standard,
    name = "n"
  ) %>%
  
  group_by(
    village_raw
  ) %>%
  
  arrange(
    desc(n),
    arm_standard,
    .by_group = TRUE
  ) %>%
  
  slice_head(
    n = 1
  ) %>%
  
  ungroup() %>%
  
  transmute(
    
    village =
      village_raw,
    
    randomized_arm =
      arm_standard
  )


# 5.4.9 Assign each participant to a fixed village ----
#
# Modal observed village.
#
# Earliest date breaks ties.
#
# If you obtain the authoritative randomization roster later,
# that should supersede this pragmatic reconstruction.
#

participant_village <- dat %>%
  
  group_by(
    id,
    village_raw
  ) %>%
  
  summarise(
    
    n_records =
      n(),
    
    first_date =
      min(
        date,
        na.rm = TRUE
      ),
    
    .groups =
      "drop"
  ) %>%
  
  arrange(
    id,
    desc(n_records),
    first_date,
    village_raw
  ) %>%
  
  group_by(id) %>%
  
  slice_head(
    n = 1
  ) %>%
  
  ungroup() %>%
  
  transmute(
    
    id,
    
    village =
      village_raw
  )


# 5.4.10 Assign intervention status from village allocation ----

participant_assignment <- participant_village %>%
  
  left_join(
    village_arm_map,
    by = "village"
  )


if (anyNA(
  participant_assignment$randomized_arm
)) {
  
  stop(
    "At least one participant could not be assigned ",
    "to a randomized arm."
  )
}


# 5.4.11 Join assigned village and intervention arm ----

dat <- dat %>%
  
  select(
    -village_raw
  ) %>%
  
  left_join(
    participant_assignment,
    by = "id"
  )


# 5.4.12 Consolidate repeat observations on the same date ----

visits <- dat %>%
  
  arrange(
    id,
    date
  ) %>%
  
  group_by(
    id,
    date
  ) %>%
  
  summarise(
    
    malaria =
      first(
        malaria
      ),
    
    arm =
      first(
        randomized_arm
      ),
    
    village =
      first(
        village
      ),
    
    age =
      first(
        age_raw
      ),
    
    transmission =
      first(
        transmission_raw
      ),
    
    sex =
      first(
        sex_clean
      ),
    
    .groups =
      "drop"
  ) %>%
  
  arrange(
    id,
    date
  )


# 5.4.13 Identify participant baseline status ----

baseline_all <- visits %>%
  
  group_by(id) %>%
  
  slice_head(
    n = 1
  ) %>%
  
  ungroup()


cat("\n============================================================\n")
cat("BASELINE AUDIT\n")
cat("============================================================\n\n")

cat(
  "Participants with a baseline record:",
  nrow(baseline_all),
  "\n"
)

cat(
  "Baseline malaria positive:",
  sum(
    baseline_all$malaria == 1,
    na.rm = TRUE
  ),
  "\n"
)

cat(
  "Baseline malaria negative:",
  sum(
    baseline_all$malaria == 0,
    na.rm = TRUE
  ),
  "\n"
)

cat(
  "Baseline missing/undefined SEX:",
  sum(
    is.na(baseline_all$sex)
  ),
  "\n"
)


# 5.4.14 Establish a shared analytic cohort ----
#
# Requirements:
#
#   baseline malaria negative
#   valid treatment arm
#   valid age
#   valid transmission category
#   valid SEX
#   valid village
#
# SAME COHORT WILL BE USED FOR COX AND AG.
#

baseline <- baseline_all %>%
  
  filter(
    malaria == 0,
    !is.na(arm),
    arm != "",
    !is.na(age),
    age != "",
    !is.na(transmission),
    transmission != "",
    !is.na(sex),
    sex != "",
    !is.na(village),
    village != ""
  ) %>%
  
  mutate(
    
    origin =
      date,
    
    arm =
      factor(
        arm,
        levels =
          c(
            "Control",
            "Intervention"
          )
      ),
    
    age =
      factor(age),
    
    transmission =
      factor(transmission),
    
    sex =
      factor(
        sex,
        levels =
          c(
            "1",
            "2"
          )
      ),
    
    village =
      factor(village)
  )


cat("\n============================================================\n")
cat("MASTER ANALYTIC COHORT\n")
cat("============================================================\n\n")

cat(
  "Eligible baseline-negative complete-case participants:",
  nrow(baseline),
  "\n"
)


print(
  baseline %>%
    count(
      arm,
      name = "Participants"
    )
)


# 5.4.15 Define follow-up intervals and incident episodes ----
#
# An incident malaria episode is:
#
# documented negative observation
#            followed by
# documented positive observation
#

all_intervals <- visits %>%
  
  select(
    id,
    date,
    malaria
  ) %>%
  
  inner_join(
    
    baseline %>%
      select(
        id,
        origin,
        arm,
        age,
        transmission,
        sex,
        village
      ),
    
    by =
      "id"
  ) %>%
  
  arrange(
    id,
    date
  ) %>%
  
  group_by(id) %>%
  
  mutate(
    
    tstop =
      as.numeric(
        date - origin
      ),
    
    tstart =
      lag(tstop),
    
    previous_status =
      lag(malaria),
    
    event =
      as.integer(
        previous_status == 0 &
          malaria == 1
      )
  ) %>%
  
  ungroup() %>%
  
  filter(
    !is.na(tstart),
    !is.na(tstop),
    tstop > tstart
  )


# 5.4.16 Construct Andersen–Gill at-risk intervals ----
#
# Participant contributes an at-risk interval only when the
# preceding observed malaria status is negative.
#
# After a positive observation, participant does not become
# at risk again until a documented negative observation.
#

ag_intervals <- all_intervals %>%
  
  filter(
    previous_status == 0
  )


# 5.4.17 Construct first-event Cox at-risk intervals ----
#
# CRITICAL:
#
# First-event Cox is constructed DIRECTLY from the SAME
# recurrent-event interval dataset.
#
# This guarantees identical eligibility/episode definitions.
#
# Once first event occurs, later intervals are removed.
#

cox_intervals <- ag_intervals %>%
  
  arrange(
    id,
    tstart,
    tstop
  ) %>%
  
  group_by(id) %>%
  
  mutate(
    
    events_before =
      lag(
        cumsum(event),
        default = 0
      )
  ) %>%
  
  filter(
    events_before == 0
  ) %>%
  
  ungroup() %>%
  
  select(
    -events_before
  )


cat("\n============================================================\n")
cat("EVENT AUDIT BEFORE PIECEWISE SPLITTING\n")
cat("============================================================\n\n")

cat(
  "Participants contributing Cox follow-up:",
  n_distinct(cox_intervals$id),
  "\n"
)

cat(
  "First events in Cox:",
  sum(cox_intervals$event),
  "\n"
)

cat(
  "Recurrent-event episodes in AG:",
  sum(ag_intervals$event),
  "\n"
)

cat(
  "Additional recurrent episodes in AG:",
  sum(ag_intervals$event) -
    sum(cox_intervals$event),
  "\n"
)


# 5.4.18 Define a function to split time intervals ----

split_one_period <- function(
    data,
    lower,
    upper,
    label
) {
  
  x <- data
  
  x$original_tstop <-
    x$tstop
  
  x$original_event <-
    x$event
  
  
  x$tstart <-
    pmax(
      x$tstart,
      lower
    )
  
  
  x$tstop <-
    pmin(
      x$tstop,
      upper
    )
  
  
  x <- x[
    x$tstop > x$tstart,
    ,
    drop = FALSE
  ]
  
  
  if (nrow(x) == 0) {
    return(x)
  }
  
  
  x$event <-
    as.integer(
      
      x$original_event == 1 &
        
        abs(
          x$tstop -
            x$original_tstop
        ) < 1e-10
    )
  
  
  x$period <-
    label
  
  
  x
}


# 5.4.19 Split follow-up at the predefined periods ----

make_piecewise <- function(data) {
  
  bind_rows(
    
    split_one_period(
      data,
      lower = 0,
      upper = 30,
      label = "0-30 days"
    ),
    
    split_one_period(
      data,
      lower = 30,
      upper = 60,
      label = "30-60 days"
    ),
    
    split_one_period(
      data,
      lower = 60,
      upper = Inf,
      label = ">60 days"
    )
    
  ) %>%
    
    mutate(
      
      period =
        factor(
          period,
          levels =
            c(
              "0-30 days",
              "30-60 days",
              ">60 days"
            )
        ),
      
      ITN =
        as.integer(
          arm ==
            "Intervention"
        ),
      
      ITN_0_30 =
        ITN *
        as.integer(
          period ==
            "0-30 days"
        ),
      
      ITN_30_60 =
        ITN *
        as.integer(
          period ==
            "30-60 days"
        ),
      
      ITN_gt60 =
        ITN *
        as.integer(
          period ==
            ">60 days"
        )
    )
}


# 5.4.20 Build period-specific Cox and Andersen–Gill datasets ----

cox_piecewise <-
  make_piecewise(
    cox_intervals
  )


ag_piecewise <-
  make_piecewise(
    ag_intervals
  )


# 5.4.21 Audit person-time and events by follow-up period ----

audit_piecewise <- function(data, model_name) {
  
  data %>%
    
    group_by(
      period,
      arm
    ) %>%
    
    summarise(
      
      Participants_at_risk =
        n_distinct(id),
      
      Events =
        sum(event),
      
      Person_days =
        sum(
          tstop - tstart
        ),
      
      Person_years =
        Person_days /
        365.25,
      
      Incidence_per_1000_PY =
        Events /
        Person_years *
        1000,
      
      .groups =
        "drop"
    ) %>%
    
    mutate(
      Model =
        model_name,
      .before = 1
    )
}


Cox_Audit <-
  audit_piecewise(
    cox_piecewise,
    "First-event Cox"
  )


AG_Audit <-
  audit_piecewise(
    ag_piecewise,
    "Andersen-Gill"
  )


cat("\n============================================================\n")
cat("EVENT AND PERSON-TIME AUDIT\n")
cat("============================================================\n\n")

print(
  bind_rows(
    Cox_Audit,
    AG_Audit
  ),
  n = Inf
)


# 5.5 Piecewise model estimation and global tests ----
# 5.5.1 Fit the first-event Cox model with period-specific effects ----

Piecewise_Cox <- coxph(
  
  Surv(
    tstart,
    tstop,
    event
  ) ~
    
    ITN_0_30 +
    ITN_30_60 +
    ITN_gt60 +
    
    age +
    transmission +
    sex +
    
    cluster(village),
  
  data =
    cox_piecewise,
  
  ties =
    "efron",
  
  robust =
    TRUE,
  
  model =
    TRUE,
  
  x =
    TRUE
)


# 5.5.2 Fit the Andersen–Gill recurrent-event model ----

Andersen_Gill <- coxph(
  
  Surv(
    tstart,
    tstop,
    event
  ) ~
    
    ITN_0_30 +
    ITN_30_60 +
    ITN_gt60 +
    
    age +
    transmission +
    sex +
    
    cluster(village),
  
  data =
    ag_piecewise,
  
  ties =
    "efron",
  
  robust =
    TRUE,
  
  model =
    TRUE,
  
  x =
    TRUE
)


# 5.5.3 Extract period-specific hazard ratios and uncertainty ----

extract_period_results <- function(model) {
  
  terms_itn <- c(
    "ITN_0_30",
    "ITN_30_60",
    "ITN_gt60"
  )
  
  
  beta <-
    coef(model)[
      terms_itn
    ]
  
  
  V <-
    vcov(model)[
      terms_itn,
      terms_itn,
      drop = FALSE
    ]
  
  
  SE <-
    sqrt(
      diag(V)
    )
  
  
  HR <-
    exp(beta)
  
  
  lower <-
    exp(
      beta -
        1.96 * SE
    )
  
  
  upper <-
    exp(
      beta +
        1.96 * SE
    )
  
  
  p <-
    2 *
    pnorm(
      -abs(
        beta / SE
      )
    )
  
  
  data.frame(
    
    Period =
      c(
        "0-30 days",
        "30-60 days",
        ">60 days"
      ),
    
    HR =
      as.numeric(HR),
    
    Lower =
      as.numeric(lower),
    
    Upper =
      as.numeric(upper),
    
    P =
      as.numeric(p),
    
    Reduction_percent =
      100 *
      (
        1 -
          as.numeric(HR)
      ),
    
    stringsAsFactors =
      FALSE
  )
}


# 5.5.4 Obtain first-event and recurrent-event estimates ----

Cox_Results <-
  extract_period_results(
    Piecewise_Cox
  )


AG_Results <-
  extract_period_results(
    Andersen_Gill
  )


# 5.5.5 Create the period-specific Cox reporting table ----

Standalone_Piecewise_Cox <- data.frame(
  
  `Follow-up interval` =
    Cox_Results$Period,
  
  `Adjusted HR (95% CI)` =
    sprintf(
      "%.2f (%.2f-%.2f)",
      Cox_Results$HR,
      Cox_Results$Lower,
      Cox_Results$Upper
    ),
  
  `Relative hazard reduction, %` =
    sprintf(
      "%.1f",
      Cox_Results$Reduction_percent
    ),
  
  `P-value for intervention effect` =
    format.pval(
      Cox_Results$P,
      digits = 3,
      eps = 0.001
    ),
  
  check.names =
    FALSE
)


# 5.5.6 Define the global Wald test of effect heterogeneity ----
#
# Null hypothesis:
#
# beta(0-30) = beta(30-60) = beta(>60)
#
# 2 df Wald test
#

global_time_test <- function(model) {
  
  terms_itn <- c(
    "ITN_0_30",
    "ITN_30_60",
    "ITN_gt60"
  )
  
  
  beta <-
    coef(model)[
      terms_itn
    ]
  
  
  V <-
    vcov(model)[
      terms_itn,
      terms_itn,
      drop = FALSE
    ]
  
  
  # Two independent contrasts
  #
  # beta_30_60 - beta_0_30
  # beta_gt60  - beta_0_30
  
  L <- rbind(
    
    c(
      -1,
      1,
      0
    ),
    
    c(
      -1,
      0,
      1
    )
  )
  
  
  difference <-
    L %*%
    beta
  
  
  difference_variance <-
    L %*%
    V %*%
    t(L)
  
  
  Wald <-
    drop(
      
      t(difference) %*%
        
        solve(
          difference_variance
        ) %*%
        
        difference
    )
  
  
  df <-
    2
  
  
  p <-
    pchisq(
      Wald,
      df = df,
      lower.tail = FALSE
    )
  
  
  data.frame(
    
    Wald_ChiSquare =
      Wald,
    
    df =
      df,
    
    P_value =
      p
  )
}


# 5.5.7 Apply the global test to first-event Cox ----

Cox_Global <-
  global_time_test(
    Piecewise_Cox
  )


# 5.5.8 Apply the global test to Andersen–Gill ----

AG_Global <-
  global_time_test(
    Andersen_Gill
  )


# 5.5.9 Assemble global tests for both models ----
Global_Test_Table <- data.frame(
  
  Model =
    c(
      "First-event Cox",
      "Andersen-Gill"
    ),
  
  `Wald chi-square` =
    c(
      Cox_Global$Wald_ChiSquare,
      AG_Global$Wald_ChiSquare
    ),
  
  df =
    c(
      Cox_Global$df,
      AG_Global$df
    ),
  
  `P-value` =
    c(
      Cox_Global$P_value,
      AG_Global$P_value
    ),
  
  check.names =
    FALSE
)


# 5.5.10 Compare period-specific Cox and Andersen–Gill estimates ----

Cox_AG_Comparison <- data.frame(
  
  Period =
    Cox_Results$Period,
  
  Cox_HR =
    Cox_Results$HR,
  
  Cox_lower =
    Cox_Results$Lower,
  
  Cox_upper =
    Cox_Results$Upper,
  
  Cox_p =
    Cox_Results$P,
  
  Cox_reduction_percent =
    Cox_Results$Reduction_percent,
  
  AG_HR =
    AG_Results$HR,
  
  AG_lower =
    AG_Results$Lower,
  
  AG_upper =
    AG_Results$Upper,
  
  AG_p =
    AG_Results$P,
  
  AG_reduction_percent =
    AG_Results$Reduction_percent,
  
  AG_to_Cox_HR_ratio =
    AG_Results$HR /
    Cox_Results$HR
)


# 5.5.11 Format the cross-model comparison table ----

Publication_Comparison <- data.frame(
  
  `Follow-up interval` =
    Cox_Results$Period,
  
  `First-event Cox aHR (95% CI)` =
    sprintf(
      "%.2f (%.2f-%.2f)",
      Cox_Results$HR,
      Cox_Results$Lower,
      Cox_Results$Upper
    ),
  
  `Cox reduction, %` =
    sprintf(
      "%.1f",
      Cox_Results$Reduction_percent
    ),
  
  `Cox P-value` =
    format.pval(
      Cox_Results$P,
      digits = 3,
      eps = 0.001
    ),
  
  `Andersen-Gill aHR (95% CI)` =
    sprintf(
      "%.2f (%.2f-%.2f)",
      AG_Results$HR,
      AG_Results$Lower,
      AG_Results$Upper
    ),
  
  `AG reduction, %` =
    sprintf(
      "%.1f",
      AG_Results$Reduction_percent
    ),
  
  `AG P-value` =
    format.pval(
      AG_Results$P,
      digits = 3,
      eps = 0.001
    ),
  
  check.names =
    FALSE
)


# 5.6 Cross-model comparisons, reporting and checks ----
# 5.6.1 Verify Cox results are consistent across outputs ----
#
# There is deliberately NO second Cox model in the comparison.
#
# The comparison table takes its Cox estimates directly from
# Piecewise_Cox.
#
# Therefore the standalone Cox estimates and comparison Cox
# estimates MUST be identical.
#

Standalone_HR <-
  Cox_Results$HR


Comparison_HR <-
  Cox_AG_Comparison$Cox_HR


Cox_values_identical <-
  isTRUE(
    all.equal(
      Standalone_HR,
      Comparison_HR,
      tolerance = 0
    )
  )


if (!Cox_values_identical) {
  
  stop(
    "ERROR: Standalone Cox and comparison Cox values differ."
  )
}


# 5.6.2 Display first-event Cox estimates ----

cat("\n\n")
cat("============================================================\n")
cat("STANDALONE PIECEWISE FIRST-EVENT COX\n")
cat("============================================================\n\n")


print(
  Standalone_Piecewise_Cox,
  row.names = FALSE
)


cat("\nModel intervals:",
    Piecewise_Cox$n,
    "\n")

cat(
  "First events:",
  Piecewise_Cox$nevent,
  "\n"
)


# 5.6.3 Report the global Cox time-variation test ----

cat("\n")
cat("============================================================\n")
cat("GLOBAL TEST OF TIME VARIATION: FIRST-EVENT COX\n")
cat("============================================================\n\n")


cat(
  "Wald chi-square =",
  round(
    Cox_Global$Wald_ChiSquare,
    3
  ),
  "\n"
)


cat(
  "df =",
  Cox_Global$df,
  "\n"
)


cat(
  "P-value =",
  format.pval(
    Cox_Global$P_value,
    digits = 4,
    eps = 0.001
  ),
  "\n"
)


# 5.6.4 Display Cox and Andersen–Gill comparison ----

cat("\n")
cat("============================================================\n")
cat("FIRST-EVENT COX vs ANDERSEN-GILL\n")
cat("============================================================\n\n")


print(
  Publication_Comparison,
  row.names = FALSE
)


# 5.6.5 Display numeric model comparisons ----

cat("\n")
cat("============================================================\n")
cat("NUMERIC COX vs AG COMPARISON\n")
cat("============================================================\n\n")


print(
  Cox_AG_Comparison,
  row.names = FALSE
)


# 5.6.6 Report both global heterogeneity tests ----

cat("\n")
cat("============================================================\n")
cat("GLOBAL TESTS OF TIME VARIATION\n")
cat("============================================================\n\n")


print(
  Global_Test_Table,
  row.names = FALSE
)


# 5.6.7 Confirm equality of first-event Cox estimates ----

cat("\n")
cat("============================================================\n")
cat("COX CONSISTENCY CHECK\n")
cat("============================================================\n\n")


cat(
  "Standalone Cox and comparison Cox values identical:",
  Cox_values_identical,
  "\n"
)


cat("\nStandalone Cox HRs:\n")

print(
  round(
    Standalone_HR,
    6
  )
)


cat("\nComparison Cox HRs:\n")

print(
  round(
    Comparison_HR,
    6
  )
)


# 5.6.8 Summarise the recurrent-event distribution ----

Recurrent_Event_Distribution <- ag_intervals %>%
  
  group_by(
    id,
    arm
  ) %>%
  
  summarise(
    
    Events =
      sum(event),
    
    .groups =
      "drop"
  ) %>%
  
  count(
    arm,
    Events,
    name =
      "Participants"
  ) %>%
  
  arrange(
    arm,
    Events
  )


cat("\n")
cat("============================================================\n")
cat("RECURRENT EVENT DISTRIBUTION\n")
cat("============================================================\n\n")


print(
  Recurrent_Event_Distribution,
  n = Inf
)


# 5.6.9 Verify event counts in the two models ----

cat("\n")
cat("============================================================\n")
cat("FINAL EVENT COUNT CHECK\n")
cat("============================================================\n\n")


cat(
  "Cox first events =",
  sum(
    cox_piecewise$event
  ),
  "\n"
)


cat(
  "AG recurrent events =",
  sum(
    ag_piecewise$event
  ),
  "\n"
)


cat(
  "Additional events included by AG =",
  sum(
    ag_piecewise$event
  ) -
    sum(
      cox_piecewise$event
    ),
  "\n"
)


# 5.6.10 Report the global test interpretation ----

cat("\n")
cat("============================================================\n")
cat("GLOBAL TEST INTERPRETATION\n")
cat("============================================================\n\n")


if (
  Cox_Global$P_value < 0.05
) {
  
  cat(
    "FIRST-EVENT COX:\n",
    "Evidence that the intervention effect differs across ",
    "the three follow-up periods.\n",
    "Global Wald P = ",
    format.pval(
      Cox_Global$P_value,
      digits = 3,
      eps = 0.001
    ),
    "\n\n",
    sep = ""
  )
  
} else {
  
  cat(
    "FIRST-EVENT COX:\n",
    "Insufficient statistical evidence that the intervention ",
    "effect differs across the three follow-up periods.\n",
    "Global Wald P = ",
    format.pval(
      Cox_Global$P_value,
      digits = 3,
      eps = 0.001
    ),
    "\n\n",
    sep = ""
  )
}


if (
  AG_Global$P_value < 0.05
) {
  
  cat(
    "ANDERSEN-GILL:\n",
    "Evidence that the intervention effect differs across ",
    "the three follow-up periods.\n",
    "Global Wald P = ",
    format.pval(
      AG_Global$P_value,
      digits = 3,
      eps = 0.001
    ),
    "\n",
    sep = ""
  )
  
} else {
  
  cat(
    "ANDERSEN-GILL:\n",
    "Insufficient statistical evidence that the intervention ",
    "effect differs across the three follow-up periods.\n",
    "Global Wald P = ",
    format.pval(
      AG_Global$P_value,
      digits = 3,
      eps = 0.001
    ),
    "\n",
    sep = ""
  )
}


# 5.6.11 Display complete model summaries ----

cat("\n\n")
cat("============================================================\n")
cat("FULL FIRST-EVENT COX MODEL\n")
cat("============================================================\n\n")

print(
  summary(
    Piecewise_Cox
  )
)


cat("\n\n")
cat("============================================================\n")
cat("FULL ANDERSEN-GILL MODEL\n")
cat("============================================================\n\n")

print(
  summary(
    Andersen_Gill
  )
)


cat("\n\n")
cat("============================================================\n")
cat("ANALYSIS COMPLETE\n")
cat("============================================================\n")



# 5.7 Additional survey-round output retained from the source script ----
# 5.7.1 Retain the original survey-round results assignment ----
Lower_95CI =
      lower,
    
    Upper_95CI =
      upper,
    
    P_value =
      p_value
  )
}


sr_results <- bind_rows(
  
  lapply(
    sr_round_levels,
    sr_get_irr
  )
)


# 5.7.2 Format adjusted survey-round effect estimates ----

sr_results_formatted <- sr_results %>%
  
  mutate(
    
    `Adjusted rate ratio (95% CI)` =
      sprintf(
        "%.2f (%.2f–%.2f)",
        IRR,
        Lower_95CI,
        Upper_95CI
      ),
    
    `P value` =
      case_when(
        
        P_value < 0.001 ~
          "<0.001",
        
        TRUE ~
          sprintf(
            "%.3f",
            P_value
          )
      )
  ) %>%
  
  select(
    Survey_round,
    `Adjusted rate ratio (95% CI)`,
    `P value`
  )


cat("\n=====================================================\n")
cat("ROUND-SPECIFIC INTERVENTION EFFECTS\n")
cat("=====================================================\n")

print(
  sr_results_formatted,
  row.names = FALSE
)


# 5.7.3 Report the survey-round heterogeneity interpretation ----

cat("\n=====================================================\n")
cat("INTERPRETATION\n")
cat("=====================================================\n")


if (
  sr_p < 0.05
) {
  
  cat(
    "There was statistical evidence of heterogeneity in ",
    "the intervention effect across active-surveillance ",
    "rounds S7-S15 (global intervention-by-survey-round ",
    "interaction: Wald chi-square = ",
    round(sr_wald, 2),
    ", df = ",
    sr_df,
    ", P = ",
    format.pval(
      sr_p,
      digits = 4
    ),
    ").\n",
    sep = ""
  )
  
} else {
  
  cat(
    "There was insufficient statistical evidence of ",
    "heterogeneity in the intervention effect across ",
    "active-surveillance rounds S7-S15 (global ",
    "intervention-by-survey-round interaction: Wald ",
    "chi-square = ",
    round(sr_wald, 2),
    ", df = ",
    sr_df,
    ", P = ",
    format.pval(
      sr_p,
      digits = 4
    ),
    "). Numerical differences between individual round-",
    "specific estimates should therefore be interpreted ",
    "descriptively rather than as statistically established ",
    "time variation in the intervention effect.\n",
    sep = ""
  )
}


# END


# 5.8 Survey-round interaction analysis using Poisson GEE ----
# 5.8.1 Define the survey-round intervention effect analysis ----
#during active surveillance#

suppressPackageStartupMessages({
  library(dplyr)
  library(geepack)
})


# 5.8.2 Clear previous survey-round result objects ----

sr_old <- c(
  "sr_dat0",
  "sr_round_dates",
  "sr_dat",
  "sr_counts",
  "sr_fit",
  "sr_beta",
  "sr_V",
  "sr_interaction_names",
  "sr_beta_int",
  "sr_V_int",
  "sr_wald",
  "sr_df",
  "sr_p",
  "sr_results",
  "sr_results_formatted"
)

rm(
  list = intersect(
    sr_old,
    ls()
  )
)


# 5.8.3 Check required input data ----

if (!exists("CRT_GEE")) {
  stop("CRT_GEE is not available in the current R environment.")
}


required_vars <- c(
  "Survey_Group_code",
  "Survey_Number(6-17)",
  "Transmission_level_code",
  "Participant_unique_identifier",
  "Locality_code",
  "SEX",
  "Age_group",
  "FINAL_MALARIA_NUM1",
  "Date_of_the_survey"
)


missing_vars <- setdiff(
  required_vars,
  names(CRT_GEE)
)


if (length(missing_vars) > 0) {
  stop(
    paste(
      "Missing required variables:",
      paste(missing_vars, collapse = ", ")
    )
  )
}


# 5.8.4 Harmonise source variables and covariates ----

sr_dat0 <- CRT_GEE %>%
  mutate(
    
    # Survey number
    
    survey_number = suppressWarnings(
      as.integer(
        as.character(
          .data[["Survey_Number(6-17)"]]
        )
      )
    ),
    
    
    # Malaria outcome
    
    infection_status = suppressWarnings(
      as.integer(
        as.character(
          FINAL_MALARIA_NUM1
        )
      )
    ),
    
    
    # Study arm
    # 0 = Control
    # 1 = Intervention
    
    arm_raw = trimws(
      as.character(
        Survey_Group_code
      )
    ),
    
    Survey_Group_code = case_when(
      
      arm_raw %in% c(
        "0",
        "Control",
        "control"
      ) ~ "Control",
      
      arm_raw %in% c(
        "1",
        "Intervention",
        "intervention"
      ) ~ "Intervention",
      
      TRUE ~ NA_character_
    ),
    
    
    # Age group
    
    age_raw = trimws(
      as.character(
        Age_group
      )
    ),
    
    Age_group = case_when(
      
      age_raw %in% c(
        "<5y",
        "<5",
        "<5 years"
      ) ~ "<5 years",
      
      age_raw %in% c(
        "5–14y",
        "5-14y",
        "5–14 years",
        "5-14 years"
      ) ~ "5–14 years",
      
      age_raw %in% c(
        "15+",
        "15+y",
        "≥15",
        ">=15",
        "≥15 years",
        "15+ years"
      ) ~ "≥15 years",
      
      TRUE ~ NA_character_
    ),
    
    
    # Transmission level
    # 0 = Low
    # 1 = Medium
    # 2 = High
    
    transmission_raw = trimws(
      as.character(
        Transmission_level_code
      )
    ),
    
    Transmission_level_code = case_when(
      
      transmission_raw %in%
        c("0", "Low", "low") ~ "Low",
      
      transmission_raw %in%
        c("1", "Medium", "medium") ~ "Medium",
      
      transmission_raw %in%
        c("2", "High", "high") ~ "High",
      
      TRUE ~ NA_character_
    ),
    
    
    # Sex
    # 1 = Male
    # 2 = Female
    #
    # Rare codes 3/4, blanks and NA are excluded.
    
    sex_raw = trimws(
      as.character(
        SEX
      )
    ),
    
    SEX = case_when(
      
      sex_raw %in% c(
        "1",
        "Male",
        "male",
        "M"
      ) ~ "Male",
      
      sex_raw %in% c(
        "2",
        "Female",
        "female",
        "F"
      ) ~ "Female",
      
      TRUE ~ NA_character_
    ),
    
    
    # Date
    
    date_raw =
      as.character(
        Date_of_the_survey
      ),
    
    survey_date_clean = coalesce(
      
      suppressWarnings(
        as.Date(
          date_raw,
          format = "%Y-%m-%d"
        )
      ),
      
      suppressWarnings(
        as.Date(
          date_raw,
          format = "%m/%d/%Y"
        )
      ),
      
      suppressWarnings(
        as.Date(
          date_raw,
          format = "%d/%m/%Y"
        )
      )
    )
  ) %>%
  
  mutate(
    
    Survey_Group_code = factor(
      Survey_Group_code,
      levels = c(
        "Control",
        "Intervention"
      )
    ),
    
    Age_group = factor(
      Age_group,
      levels = c(
        "<5 years",
        "5–14 years",
        "≥15 years"
      )
    ),
    
    Transmission_level_code = factor(
      Transmission_level_code,
      levels = c(
        "Low",
        "Medium",
        "High"
      )
    ),
    
    SEX = factor(
      SEX,
      levels = c(
        "Male",
        "Female"
      )
    ),
    
    Locality_code = factor(
      Locality_code
    )
  )


# 5.8.5 Inspect harmonised values ----

cat("\n=====================================================\n")
cat("VARIABLE CHECK\n")
cat("=====================================================\n")

cat("\nStudy arm:\n")
print(
  table(
    sr_dat0$Survey_Group_code,
    useNA = "ifany"
  )
)

cat("\nAge group:\n")
print(
  table(
    sr_dat0$Age_group,
    useNA = "ifany"
  )
)

cat("\nTransmission level:\n")
print(
  table(
    sr_dat0$Transmission_level_code,
    useNA = "ifany"
  )
)

cat("\nSex:\n")
print(
  table(
    sr_dat0$SEX,
    useNA = "ifany"
  )
)

cat("\nSurvey number:\n")
print(
  table(
    sr_dat0$survey_number,
    useNA = "ifany"
  )
)

cat("\nMalaria outcome:\n")
print(
  table(
    sr_dat0$infection_status,
    useNA = "ifany"
  )
)


# 5.8.6 Calculate dates and intervals for each survey ----
#
# S6 retained here ONLY to calculate the S6 -> S7
# exposure interval.

sr_round_dates <- sr_dat0 %>%
  
  filter(
    survey_number %in% 6:15,
    !is.na(survey_date_clean)
  ) %>%
  
  group_by(
    survey_number
  ) %>%
  
  summarise(
    
    survey_date = median(
      survey_date_clean,
      na.rm = TRUE
    ),
    
    .groups = "drop"
  ) %>%
  
  arrange(
    survey_number
  ) %>%
  
  mutate(
    
    interval_days = as.numeric(
      survey_date -
        lag(survey_date)
    ),
    
    interval_years =
      interval_days /
      365.25
  )


cat("\n=====================================================\n")
cat("SURVEY DATES AND INTERVAL LENGTHS\n")
cat("=====================================================\n")

print(
  sr_round_dates
)


# 5.8.7 Select the S7–S15 analysis dataset ----

formal_rounds <- 7:15


sr_dat <- sr_dat0 %>%
  
  left_join(
    sr_round_dates,
    by = "survey_number"
  ) %>%
  
  filter(
    
    survey_number %in%
      formal_rounds,
    
    infection_status %in%
      c(0L, 1L),
    
    !is.na(
      Survey_Group_code
    ),
    
    !is.na(
      Age_group
    ),
    
    !is.na(
      Transmission_level_code
    ),
    
    !is.na(
      SEX
    ),
    
    !is.na(
      Locality_code
    ),
    
    !is.na(
      interval_years
    ),
    
    interval_years > 0
  ) %>%
  
  mutate(
    
    survey_round = factor(
      paste0(
        "S",
        survey_number
      ),
      levels = paste0(
        "S",
        formal_rounds
      )
    )
  ) %>%
  
  arrange(
    Locality_code,
    survey_number
  ) %>%
  
  droplevels()


# 5.8.8 Validate model eligibility and survey-round coverage ----

if (nrow(sr_dat) == 0) {
  stop(
    "The S7-S15 analysis dataset contains zero observations."
  )
}


if (nlevels(sr_dat$survey_round) != 9) {
  stop(
    paste(
      "Expected 9 survey-round levels but found",
      nlevels(sr_dat$survey_round)
    )
  )
}


if (nlevels(sr_dat$Survey_Group_code) != 2) {
  stop(
    "Both Control and Intervention arms are not present."
  )
}


cat("\n=====================================================\n")
cat("FINAL S7-S15 ANALYSIS DATA\n")
cat("=====================================================\n")

cat(
  "Person-round observations: ",
  nrow(sr_dat),
  "\n",
  sep = ""
)

cat(
  "Villages: ",
  n_distinct(
    sr_dat$Locality_code
  ),
  "\n",
  sep = ""
)

cat(
  "Positive observations: ",
  sum(
    sr_dat$infection_status,
    na.rm = TRUE
  ),
  "\n",
  sep = ""
)


cat("\nObservations by arm and round:\n")

print(
  table(
    sr_dat$Survey_Group_code,
    sr_dat$survey_round
  )
)


# 5.8.9 Calculate observed detection rates by survey ----

sr_counts <- sr_dat %>%
  
  group_by(
    Survey_Group_code,
    survey_round
  ) %>%
  
  summarise(
    
    tested = n(),
    
    positive = sum(
      infection_status,
      na.rm = TRUE
    ),
    
    interval_days =
      first(
        interval_days
      ),
    
    person_years =
      tested *
      first(
        interval_years
      ),
    
    rate_1000py =
      positive /
      person_years *
      1000,
    
    .groups = "drop"
  )


cat("\n=====================================================\n")
cat("OBSERVED ROUND-SPECIFIC DETECTION RATES\n")
cat("=====================================================\n")

print(
  sr_counts,
  n = Inf
)


# 5.8.10 Specify intervention-by-survey Poisson GEE ----
#
# Control = reference arm
# S7      = reference survey round
#
# Robust sandwich standard errors are requested.

# 5.8.11 Aggregate records by village and model covariates ----

# Collapse observations that have identical model covariates
# within each village and survey round.

sr_dat_fast <- sr_dat %>%
  
  group_by(
    Locality_code,
    Survey_Group_code,
    survey_round,
    Age_group,
    Transmission_level_code,
    SEX,
    interval_years
  ) %>%
  
  summarise(
    
    positive = sum(
      infection_status,
      na.rm = TRUE
    ),
    
    tested = n(),
    
    person_years = sum(
      interval_years
    ),
    
    .groups = "drop"
  ) %>%
  
  arrange(
    Locality_code,
    survey_round
  ) %>%
  
  droplevels()


cat(
  "\nOriginal person-round rows:",
  nrow(sr_dat),
  "\n"
)

cat(
  "Collapsed rows:",
  nrow(sr_dat_fast),
  "\n"
)

cat(
  "Villages:",
  dplyr::n_distinct(
    sr_dat_fast$Locality_code
  ),
  "\n"
)


# 5.8.12 Fit the village-clustered interaction model ----

sr_fit <- geeglm(
  
  positive ~
    
    Survey_Group_code *
    survey_round +
    
    Age_group +
    
    Transmission_level_code +
    
    SEX +
    
    offset(
      log(
        person_years
      )
    ),
  
  id =
    Locality_code,
  
  data =
    sr_dat_fast,
  
  family =
    poisson(
      link = "log"
    ),
  
  corstr =
    "independence",
  
  std.err =
    "san.se"
)


cat(
  "\nGEE MODEL COMPLETED SUCCESSFULLY\n"
)

print(
  summary(sr_fit)
)
# 5.8.13 Extract robust model coefficients and covariance ----

sr_beta <- coef(
  sr_fit
)

sr_V <- vcov(
  sr_fit
)


cat("\nCoefficient names from NEW survey-round model:\n")

print(
  names(
    sr_beta
  )
)


# 5.8.14 Identify treatment-by-round interaction coefficients ----
#
# Because S7 is the reference, interactions correspond to:
# S8-S15 = 8 coefficients

sr_interaction_names <- grep(
  
  "Survey_Group_codeIntervention:survey_round",
  
  names(
    sr_beta
  ),
  
  value = TRUE,
  
  fixed = TRUE
)


cat("\n=====================================================\n")
cat("SURVEY-ROUND INTERACTION TERMS\n")
cat("=====================================================\n")

print(
  sr_interaction_names
)


if (length(sr_interaction_names) != 8) {
  
  stop(
    paste0(
      "Expected 8 survey-round interaction coefficients ",
      "(S8-S15), but found ",
      length(sr_interaction_names),
      ". Do not proceed with the Wald test."
    )
  )
}


# 5.8.15 Conduct the global test of intervention heterogeneity ----
#
# H0:
# Intervention rate ratio is the same across S7-S15.

sr_beta_int <-
  sr_beta[
    sr_interaction_names
  ]


sr_V_int <-
  sr_V[
    sr_interaction_names,
    sr_interaction_names,
    drop = FALSE
  ]


# Ensure covariance matrix is invertible
sr_rank <-
  qr(
    sr_V_int
  )$rank


if (
  sr_rank <
  nrow(
    sr_V_int
  )
) {
  
  stop(
    paste0(
      "Interaction covariance matrix is rank deficient: ",
      "rank ",
      sr_rank,
      " of ",
      nrow(sr_V_int),
      ". Do not report the global Wald test."
    )
  )
}


sr_wald <- as.numeric(
  
  t(
    sr_beta_int
  ) %*%
    
    solve(
      sr_V_int
    ) %*%
    
    sr_beta_int
)


sr_df <-
  length(
    sr_beta_int
  )


sr_p <- pchisq(
  
  sr_wald,
  
  df =
    sr_df,
  
  lower.tail =
    FALSE
)


cat("\n=====================================================\n")
cat("GLOBAL INTERVENTION × SURVEY-ROUND TEST\n")
cat("=====================================================\n")

cat(
  "Robust Wald chi-square = ",
  round(
    sr_wald,
    3
  ),
  "\n",
  sep = ""
)

cat(
  "Degrees of freedom = ",
  sr_df,
  "\n",
  sep = ""
)

cat(
  "P value = ",
  format.pval(
    sr_p,
    digits = 4,
    eps = 0.0001
  ),
  "\n",
  sep = ""
)


# 5.8.16 Calculate adjusted intervention IRRs by round ----
#
# Intervention / Control for each survey round

sr_main_name <-
  "Survey_Group_codeIntervention"


if (
  !sr_main_name %in%
  names(sr_beta)
) {
  
  stop(
    "Intervention main-effect coefficient not found."
  )
}


sr_round_levels <-
  paste0(
    "S",
    formal_rounds
  )


sr_get_irr <- function(
    round_name
) {
  
  L <- rep(
    0,
    length(sr_beta)
  )
  
  names(L) <-
    names(sr_beta)
  
  
  # Intervention effect at S7
  L[
    sr_main_name
  ] <- 1
  
  
  # Add interaction for S8-S15
  if (
    round_name != "S7"
  ) {
    
    int_name <- paste0(
      "Survey_Group_codeIntervention:survey_round",
      round_name
    )
    
    
    if (
      !int_name %in%
      names(sr_beta)
    ) {
      
      stop(
        paste(
          "Missing interaction coefficient:",
          int_name
        )
      )
    }
    
    
    L[
      int_name
    ] <- 1
  }
  
  
  log_irr <-
    sum(
      L *
        sr_beta
    )
  
  
  var_log_irr <-
    as.numeric(
      
      t(L) %*%
        
        sr_V %*%
        
        L
    )
  
  
  se_log_irr <-
    sqrt(
      var_log_irr
    )
  
  
  irr <-
    exp(
      log_irr
    )
  
  
  lower <-
    exp(
      log_irr -
        1.96 *
        se_log_irr
    )
  
  
  upper <-
    exp(
      log_irr +
        1.96 *
        se_log_irr
    )
  
  
  p_value <-
    2 *
    pnorm(
      -abs(
        log_irr /
          se_log_irr
      )
    )
  
  
  data.frame(
    
    Survey_round =
      round_name,
    
    IRR =
      irr,
    
    Lower_95CI =
      lower,
    
    Upper_95CI =
      upper,
    
    P_value =
      p_value
  )
}


sr_results <- bind_rows(
  
  lapply(
    sr_round_levels,
    sr_get_irr
  )
)


# 5.8.17 Format adjusted IRRs and confidence intervals ----

sr_results_formatted <- sr_results %>%
  
  mutate(
    
    `Adjusted rate ratio (95% CI)` =
      sprintf(
        "%.2f (%.2f–%.2f)",
        IRR,
        Lower_95CI,
        Upper_95CI
      ),
    
    `P value` =
      case_when(
        
        P_value < 0.001 ~
          "<0.001",
        
        TRUE ~
          sprintf(
            "%.3f",
            P_value
          )
      )
  ) %>%
  
  select(
    Survey_round,
    `Adjusted rate ratio (95% CI)`,
    `P value`
  )


cat("\n=====================================================\n")
cat("ROUND-SPECIFIC INTERVENTION EFFECTS\n")
cat("=====================================================\n")

print(
  sr_results_formatted,
  row.names = FALSE
)


# 5.8.18 Report the global test interpretation ----

cat("\n=====================================================\n")
cat("INTERPRETATION\n")
cat("=====================================================\n")


if (
  sr_p < 0.05
) {
  
  cat(
    "There was statistical evidence of heterogeneity in ",
    "the intervention effect across active-surveillance ",
    "rounds S7-S15 (global intervention-by-survey-round ",
    "interaction: Wald chi-square = ",
    round(sr_wald, 2),
    ", df = ",
    sr_df,
    ", P = ",
    format.pval(
      sr_p,
      digits = 4
    ),
    ").\n",
    sep = ""
  )
  
} else {
  
  cat(
    "There was insufficient statistical evidence of ",
    "heterogeneity in the intervention effect across ",
    "active-surveillance rounds S7-S15 (global ",
    "intervention-by-survey-round interaction: Wald ",
    "chi-square = ",
    round(sr_wald, 2),
    ", df = ",
    sr_df,
    ", P = ",
    format.pval(
      sr_p,
      digits = 4
    ),
    "). Numerical differences between individual round-",
    "specific estimates should therefore be interpreted ",
    "descriptively rather than as statistically established ",
    "time variation in the intervention effect.\n",
    sep = ""
  )
}




