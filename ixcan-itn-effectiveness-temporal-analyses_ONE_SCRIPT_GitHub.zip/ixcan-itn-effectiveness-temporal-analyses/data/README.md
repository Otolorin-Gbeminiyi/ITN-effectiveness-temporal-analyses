# Data availability and handling

No participant-level datasets or derived person-level outputs are included in this public code package.

The analysis scripts prompt for **three local files** in the following order:

1. `finmerg_deidentified` — malaria laboratory records.
2. `feball_fixed2_deidentified` — field-survey records.
3. `habitantes_query` — participant biodata.

These are descriptive source labels taken from the R script; no file extensions or publicly available download locations are asserted.

Before any public release of data, obtain the necessary permissions from the dataset owners and confirm the applicable ethics, institutional and contractual restrictions. De-identification is not sufficient by itself to establish that data may be shared publicly. The script also contains historical village names and treatment assignments, which should be assessed for disclosure permissions.

The original code writes person-level data to `CRT_GEE2.csv` and also allows a user-selected CSV export. Do **not** commit such exports to GitHub. `*.csv` is excluded through `.gitignore`, but files already committed to Git history would require separate remediation.
